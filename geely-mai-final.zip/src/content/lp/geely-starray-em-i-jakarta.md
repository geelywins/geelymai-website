---
title: "Geely Starray EM-i Jakarta: SUV Plug-in Hybrid Tanpa Cemas Jarak"
description: "Geely Starray EM-i Jakarta: plug-in hybrid dengan klaim 1.000+ km dan jarak listrik hingga 105 km. Pahami cara kerjanya, lalu coba langsung di Geely MAI."
date: 2026-10-14
tags: ["geely starray em-i jakarta", "geely starray em-i", "geely starray", "suv plug-in hybrid", "geely ev", "geely indonesia", "mobil listrik geely", "ev geely jakarta", "suv hybrid"]
model: "geely-starray-em-i"
artikel: ["spesifikasi-geely-starray-em-i-plug-in-hybrid", "konsumsi-bbm-geely-starray-em-i-dan-jarak-tempuh-1000-km", "cara-kerja-plug-in-hybrid-geely-em-i-dan-cara-mengisi-daya", "geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid", "geely-starray-em-i-suv-hybrid-yang-perlu-anda-ketahui"]
draft: false
---

Geely Starray EM-i Jakarta adalah SUV plug-in hybrid dengan klaim jarak gabungan lebih dari 1.000 km dan jarak listrik murni hingga 105 km (NEDC). Halaman ini menjelaskan cara kerjanya, siapa yang cocok memilihnya, dan bagaimana menguji sendiri di dealer Geely MAI Jakarta.

## Jalan tengah antara bensin dan listrik penuh

Tidak semua orang siap bergantung pada colokan listrik sepenuhnya. Ada yang sering bepergian jauh, ada pula yang belum punya tempat mengisi daya yang pasti. Plug-in hybrid menawarkan jalan tengah: Anda bisa memakai listrik untuk rutinitas dekat, namun tetap punya mesin bensin sebagai cadangan di perjalanan panjang.

[Geely Starray EM-i](/model/geely-starray-em-i/) dirancang dengan prinsip itu. Mobil ini dapat diisi dari colokan dan tetap bisa mengisi bensin di SPBU. Karena itu, ia sering dipertimbangkan oleh mereka yang ingin merasakan listrik tanpa harus mengubah seluruh kebiasaan perjalanan.

## Angka resmi dari e-flyer

Data berikut berasal dari e-flyer resmi. Seluruh klaim konsumsi memakai metode NEDC dan bisa berbeda di jalan nyata.

| Aspek | Keterangan |
|---|---|
| Jenis | Plug-in hybrid (PHEV), penggerak roda depan |
| Mesin bensin | 1,5 liter 4 silinder, 73 kW, 125 Nm |
| Motor listrik | 160 kW, 262 Nm |
| Baterai | LFP 18,4 kWh |
| Jarak listrik murni | Hingga 105 km (NEDC) |
| Jarak gabungan | 1.000+ km (NEDC) |
| Tangki BBM | 51 liter |
| Bagasi | 528 liter, hingga 2.065 liter jok dilipat |
| Dimensi | 4.740 x 1.905 x 1.685 mm |

Baca penjelasan tiap baris pada [spesifikasi Starray EM-i](/artikel/spesifikasi-geely-starray-em-i-plug-in-hybrid/). Perhatikan bahwa flyer bertuliskan "pre-book now", sehingga status pemesanan sebaiknya ditanyakan langsung kepada tim kami.

## Tiga mode berkendara dan artinya

Starray EM-i menyediakan mode Pure, Hybrid, dan Power. Mode Pure memakai listrik selama baterai tersedia, cocok untuk perjalanan pendek dalam kota. Mode Hybrid menggabungkan mesin dan motor secara otomatis. Mode Power mengutamakan respons tenaga.

Dengan pembagian ini, Anda tidak perlu mengatur banyak hal sendiri. Sistem memilih kombinasi yang efisien menurut kondisi. Rincian cara kerja dan cara mengisi dayanya ada di [cara kerja plug-in hybrid Geely EM-i](/artikel/cara-kerja-plug-in-hybrid-geely-em-i-dan-cara-mengisi-daya/).

## Pengisian dan konsumsi bahan bakar

Pengisian AC maksimum 6,6 kW mengisi baterai dari 25% sampai 100% dalam waktu kurang dari 3 jam. Pengisian DC maksimum 30 kW membawa baterai dari 30% ke 80% dalam kurang dari 20 menit.

Soal bahan bakar, flyer mencantumkan konsumsi 0,5 L/100 km saat baterai penuh, 1,2 L/100 km rata-rata tertimbang, dan 4,3 L/100 km saat baterai rendah. Artinya kebiasaan mengisi baterai sangat memengaruhi hasil. Kami membahas cara membacanya di [konsumsi BBM Starray EM-i dan jarak 1.000 km](/artikel/konsumsi-bbm-geely-starray-em-i-dan-jarak-tempuh-1000-km/).

## Fitur yang disebut di flyer

Layar tengah HD 15,4 inci, audio Flyme Sound 16 speaker termasuk dua di headrest, dan ADAS Level 2 dengan 14 fungsi disebut dalam flyer. Pilihan warna meliputi Snowy White, Pearl Silver, Twilight Gray, dan Marble Black, dengan Supersonic Green serta Bright Blue sebagai warna khusus yang ketentuannya ditentukan PT Geely Auto Indonesia.

Flyer juga mencantumkan bahwa gambar hanya ilustrasi. Karena itu, lihat unitnya secara langsung di [dealer Geely MAI Jakarta](/lokasi/geely-mai-jakarta/) sebelum memutuskan warna atau perlengkapan.

## Siapa yang paling cocok

Starray EM-i cocok bagi keluarga yang sering mudik atau bepergian jauh, pengguna yang tempat mengisi dayanya belum ideal, serta mereka yang ingin transisi bertahap menuju elektrifikasi. Ia kurang cocok bila Anda ingin sepenuhnya bebas dari bensin atau ingin mesin paling sederhana.

Jika masih bimbang, bandingkan dengan listrik penuh lewat [EX5 vs Starray EM-i](/artikel/geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid/) dan baca panduan [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/). Untuk gambaran model lain, lihat [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Menyiapkan test drive

Saat mencoba, ujilah perpindahan antara mode listrik dan mesin: apakah halus menurut Anda? Rasakan juga pengereman dan keheningan kabin. Bawa keluarga agar semua menilai kenyamanan jok dan ruang bagasi 528 liter.

Tanyakan kepada sales tentang jadwal pengisian, jenis colokan, dan kebutuhan instalasi di rumah. Penjelasan umum soal pengisian ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/). Hubungi kami lewat [kontak](/kontak/) untuk membuat janji.

## Kenyamanan untuk perjalanan keluarga

Dengan panjang 4.740 mm dan lebar 1.905 mm, Starray EM-i termasuk SUV berukuran menengah. Bagasi 528 liter dengan jok tegak cukup untuk barang keluarga, dan meluas hingga 2.065 liter saat jok belakang dilipat. Untuk mudik, kapasitas ini memberi kelonggaran yang tidak selalu dimiliki mobil kompak.

Kecepatan maksimum yang diklaim adalah 170 km/jam, dengan akselerasi 0-100 km/jam sekitar 8,1 detik. Angka ini menunjukkan tenaga cukup untuk menyalip di jalan tol, namun gaya mengemudi yang tenang tetap memberi hasil paling efisien. Flyer juga menyebut klaim efisiensi termal mesin 46,5%, yang merupakan klaim pabrikan dan bukan ukuran pemakaian sehari-hari.

## Hal yang perlu ditanyakan kepada sales

Karena Starray EM-i memadukan dua sumber tenaga, ada beberapa hal yang sebaiknya Anda tanyakan: jenis colokan pengisian, kebutuhan instalasi di rumah, jadwal servis berkala, dan kondisi ketersediaan unit. Jangan ragu meminta jawaban tertulis untuk hal yang menyangkut biaya.

Kami juga menyarankan Anda membandingkan skema pembiayaan dengan membaca [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/) agar tidak terkejut oleh angka saat berdiskusi. Untuk dokumen yang diperlukan, lihat [syarat dan dokumen kredit](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/). Persiapan yang baik membuat proses jauh lebih lancar.

## Pertanyaan yang sering diajukan

### Apakah Starray EM-i harus diisi listrik?

Tidak wajib, tetapi mengisi baterai membuat konsumsi bensin jauh lebih rendah.

### Berapa lama mengisi baterai?

Klaim pabrikan: AC 25-100% kurang dari 3 jam, DC 30-80% kurang dari 20 menit.

### Apakah klaim 1.000+ km pasti tercapai?

Itu klaim NEDC. Pemakaian nyata bergantung pada kondisi jalan dan kebiasaan mengisi baterai.

### Di mana melihat harga dan promo?

Lihat halaman [promo](/promo/) atau minta penawaran tertulis dari tim kami.

## Kesimpulan

Geely Starray EM-i memberi kebebasan listrik untuk harian dan cadangan bensin untuk perjalanan jauh. Pahami cara kerja modenya, cocokkan dengan kebiasaan mengisi daya Anda, lalu buktikan lewat test drive.

Jadwalkan kunjungan Anda melalui halaman [kontak](/kontak/) dan tim Geely MAI akan membantu.
