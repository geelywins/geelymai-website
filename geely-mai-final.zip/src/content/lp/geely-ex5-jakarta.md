---
title: "Geely EX5 Jakarta: SUV Listrik Lega untuk Perjalanan Keluarga"
description: "Geely EX5 Jakarta: baterai 60,22 kWh, bagasi 461 liter, pengisian DC hingga 100 kW. Pahami beda Pro dan Max, lalu atur test drive bersama Geely MAI."
date: 2026-10-14
tags: ["geely ex5 jakarta", "geely ex5", "geely ex5 pro", "geely ex5 max", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
model: "geely-ex5"
artikel: ["spesifikasi-lengkap-geely-ex5-pro-dan-max", "perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it", "jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km", "kabin-dan-bagasi-geely-ex5-461-liter", "keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas"]
draft: true
---

Geely EX5 Jakarta adalah SUV listrik berbaterai 60,22 kWh dengan bagasi 461 liter dan pengisian DC hingga 100 kW. Halaman ini membantu Anda menilai apakah EX5 cocok untuk keluarga, memahami selisih varian Pro dan Max, dan menyiapkan test drive bersama tim Geely MAI.

## Mengapa keluarga melirik SUV listrik

Keluarga biasanya punya kebutuhan yang tidak bisa ditawar: kursi yang nyaman untuk semua penumpang, bagasi yang tidak membuat Anda berkompromi saat belanja atau liburan, dan rasa aman di jalan. Pada saat yang sama, banyak yang ingin biaya energi harian lebih tenang. SUV listrik menjawab dua hal itu sekaligus, selama tempat mengisi dayanya jelas.

[Geely EX5](/model/geely-ex5/) berukuran 4.615 x 1.901 x 1.670 mm dengan jarak sumbu roda 2.750 mm. Panjang sumbu roda yang cukup besar umumnya menguntungkan ruang kaki penumpang belakang. Biar tidak sekadar membaca angka, bawalah seluruh keluarga ke dealer dan minta setiap orang duduk di posisinya sendiri.

## Data inti dari brosur resmi

Angka berikut diambil dari brosur resmi EX5. Brosur menyatakan data dapat berubah tanpa pemberitahuan, jadi konfirmasikan ulang saat Anda siap memesan.

| Aspek | Keterangan |
|---|---|
| Baterai | Short Blade LFP 60,22 kWh |
| Motor | 160 kW (218 PS), torsi 320 Nm, penggerak roda depan |
| Klaim jarak | NEDC 495 km (Pro) atau 490 km (Max); WLTP 430 km (Pro) atau 425 km (Max) |
| Pengisian | AC hingga 11 kW, DC CCS2 hingga 100 kW |
| Bagasi | 461 liter, hingga 1.877 liter jok dilipat |
| Ground clearance | 173 mm kosong, 145 mm bermuatan |
| Velg | Alloy 18 inci |

Perhatikan bahwa jarak NEDC dan WLTP berbeda cukup jauh. Cara membacanya kami jelaskan di [jarak tempuh EX5 NEDC 495 km dan WLTP 430 km](/artikel/jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km/), dan daftar lengkapnya ada di [spesifikasi EX5 Pro dan Max](/artikel/spesifikasi-lengkap-geely-ex5-pro-dan-max/).

## Kabin, bagasi, dan kenyamanan

Layar sentuh 15,4 inci dan panel instrumen 10,2 inci mengisi dashboard. Jok kulit sintetis, jok pengemudi elektrik 6 arah, serta jok depan berventilasi hadir di kedua varian. Varian Max menambahkan jok pijat, memori jok pengemudi, head-up display 13,8 inci, dan atap panoramik.

Bagasi 461 liter cukup untuk koper kabin dan belanjaan, dan bisa diperluas ketika jok belakang 60/40 dilipat. Pembahasan praktisnya ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/). Coba masukkan stroller atau koper yang biasa Anda bawa; itulah ujian yang sebenarnya.

## Keselamatan yang relevan untuk keluarga

Semua varian dibekali ABS, ESC, kontrol traksi, rem parkir elektrik dengan AutoHold, TPMS, kamera 360 derajat, serta ISOFIX di jok belakang. Brosur memuat airbag depan, samping depan, dan tirai samping, namun tidak menyebut jumlah totalnya, jadi kami tidak menuliskan angka.

Bantuan pengemudi lengkap seperti Adaptive Cruise Control, AEB, dan Lane Keeping Assist hanya ada di varian Max. Detailnya terdapat pada [keamanan EX5: airbag, ISOFIX, dan kontrol stabilitas](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/). Jika Anda membawa anak kecil, coba pasang kursi anak Anda di ISOFIX saat berkunjung.

## Pro atau Max: cara memutuskan tanpa pusing

Pro sudah mencakup tenaga, baterai, dan paket keselamatan dasar yang sama. Max menambah kenyamanan dan bantuan pengemudi. Tanyakan pada diri sendiri: seberapa sering Anda menyetir di tol atau jalur panjang? Seberapa penting jok pijat dan HUD bagi Anda?

Kalau jawabannya jarang dan tidak penting, Pro mungkin sudah cukup. Kalau sering menempuh jarak jauh, bantuan pengemudi Max bisa mengurangi lelah. Uraian tiap fitur ada di [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/).

## Mengisi daya EX5 dalam kehidupan nyata

Pengisian AC hingga 11 kW cocok untuk malam hari di rumah, sedangkan DC hingga 100 kW dipakai saat perjalanan. Brosur tidak mencantumkan lamanya pengisian, sehingga kami tidak menebak menit atau jam. Tanyakan simulasinya kepada sales sesuai kapasitas listrik Anda.

Fitur V2L memungkinkan baterai menyuplai perangkat luar, misalnya saat berkemah. Rem regeneratif dan jadwal pengisian membantu mengatur penggunaan energi. Jika Anda belum yakin tentang istilah-istilah ini, baca dulu [istilah mobil listrik](/artikel/istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen/).

## Bandingkan sebelum memutuskan

EX5 bukan satu-satunya pilihan keluarga. Jika kota adalah medan utama, [Geely EX2](/lp/geely-ex2-jakarta/) lebih ringkas. Jika Anda ragu antara listrik penuh dan plug-in hybrid, lihat [Starray EM-i](/lp/geely-starray-em-i-jakarta/) dan panduan [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/).

Datang langsung ke [dealer Geely MAI Jakarta](/lokasi/geely-mai-jakarta/) tetap cara terbaik. Dengan satu sesi test drive, Anda bisa menguji kenyamanan jok, tinggi pandang, dan respons tenaga yang tidak tertangkap dalam brosur.

## Fitur teknologi dan konektivitas yang disebut brosur

Selain ruang dan keselamatan, EX5 membawa sejumlah fitur teknologi. Brosur menyebut asisten suara, navigasi, pembaruan nirkabel (OTA), Geely Apps Store, CarbitLink untuk koneksi ponsel, dan sistem Flyme Auto. Pengisi daya nirkabel tersedia untuk ponsel, dengan dua port USB-A di depan dan dua USB-C di belakang sehingga penumpang belakang pun bisa mengisi gawainya.

Untuk hiburan, varian Pro memakai audio 6 speaker, sedangkan Max memakai 14 speaker ditambah dua speaker di headrest pengemudi. Cara kerja pembaruan dan aplikasinya kami jabarkan di [aplikasi dan konektivitas EX5](/artikel/aplikasi-dan-konektivitas-geely-ex5-ota-navigasi-dan-flyme/). Fitur-fitur semacam ini baru terasa gunanya saat dipakai, jadi sempatkan membuka menunya ketika test drive.

## Pertanyaan praktis yang biasanya muncul sebelum membeli

Banyak keluarga bertanya soal perawatan, jadwal servis, dan nilai mobil di masa depan. Untuk hal-hal yang tidak tercantum di brosur, seperti garansi dan jadwal servis, kami meminta Anda menanyakan langsung kepada sales dan meminta jawaban tertulis. Kami tidak menuliskan angka yang belum terverifikasi.

Hal lain yang kerap ditanyakan adalah kecocokan untuk perjalanan jauh. Dengan klaim NEDC 495 km pada varian Pro, Anda tetap perlu merencanakan pemberhentian pengisian untuk rute panjang. Pembahasan sudut pandang ini ada di [EX5 untuk perjalanan jauh dan mudik](/artikel/geely-ex5-untuk-perjalanan-jauh-dan-mudik/). Dengan perencanaan sederhana, perjalanan keluarga tetap nyaman.

## Pertanyaan yang sering diajukan

### Apakah EX5 punya ISOFIX?

Ya. Brosur menyebut ISOFIX dan child anchor di jok belakang untuk semua varian.

### Berapa jarak tempuh EX5?

Klaim pabrikan NEDC 495 km (Pro) atau 490 km (Max), WLTP 430 km (Pro) atau 425 km (Max). Pemakaian nyata bisa berbeda.

### Apakah EX5 bisa dites bersama keluarga?

Bisa dan dianjurkan. Buat janji lewat halaman [kontak](/kontak/).

### Di mana melihat harga dan promo?

Harga dan promo berubah, jadi lihat halaman [promo](/promo/) atau minta penawaran tertulis.

## Kesimpulan

Geely EX5 menawarkan kabin lega, bagasi 461 liter, dan data pengisian yang jelas untuk keluarga yang ingin beralih ke listrik. Tentukan varian dari fitur yang benar-benar dipakai, pastikan tempat mengisi daya, lalu uji bersama seluruh anggota keluarga.

Hubungi tim Geely MAI lewat halaman [kontak](/kontak/) untuk menjadwalkan sesi coba.
