---
title: "Geely EX2 Jakarta: Mobil Listrik Ringkas yang Siap Anda Coba"
description: "Geely EX2 Jakarta dengan baterai LFP 40,8 kWh dan klaim jarak 395 km. Kenali varian Pro dan Max, cara mengisi daya, lalu jadwalkan test drive di Geely MAI."
date: 2026-10-14
tags: ["geely ex2 jakarta", "geely ex2", "geely ex2 max", "mobil listrik geely", "geely ev", "geely indonesia", "mobil listrik kompak", "ev geely jakarta", "test drive geely ex2"]
model: "geely-ex2"
artikel: ["spesifikasi-lengkap-geely-ex2-max", "geely-ex2-max-di-macet-jakarta", "perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it", "cara-test-drive-geely", "baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama"]
draft: true
---

Geely EX2 Jakarta adalah mobil listrik kompak dengan baterai LFP 40,8 kWh dan klaim jarak tempuh 395 km (NEDC). Halaman ini merangkum siapa yang cocok memilihnya, angka resmi yang perlu Anda ketahui, perbedaan Pro dan Max, serta cara mencobanya langsung di dealer Geely MAI.

## Gambaran satu hari dengan mobil listrik kompak

Bayangkan pagi Anda: mengantar anak, menembus jalan arteri, parkir di gedung kantor, lalu pulang sore lewat jalur yang sama. Pola seperti ini berulang setiap hari dan jaraknya relatif pendek. Mobil yang ringkas membuat setiap tahap terasa lebih enteng, dari memutar di gang sempit sampai mencari celah parkir.

[Geely EX2](/model/geely-ex2/) lahir untuk ritme semacam itu. Tenaganya datang langsung dari motor listrik, tanpa jeda perpindahan gigi, sehingga berhenti dan jalan di kemacetan terasa mulus. Kami menulis pengalaman pemakaian di jalan padat secara terpisah dalam [EX2 Max di macet Jakarta](/artikel/geely-ex2-max-di-macet-jakarta/).

## Angka resmi yang bisa dipegang

Tabel berikut memuat data varian Max. Semua angka adalah klaim pabrikan, jadi gunakan sebagai pembanding antarmobil, bukan sebagai janji hasil di jalan.

| Aspek | Keterangan |
|---|---|
| Baterai | LFP 40,8 kWh |
| Motor | 85 kW, torsi 150 Nm |
| Klaim jarak | 395 km (NEDC) |
| Pengisian cepat DC | 30-80% sekitar 25 menit |
| Pengisian AC | 10-100% sekitar 6,5 jam |
| Layar tengah | 14,6 inci |
| Bagasi | 375 liter, hingga 1.320 liter, plus frunk 70 liter |
| Penumpang | 5 orang |

Untuk membaca arti tiap baris, buka [spesifikasi lengkap Geely EX2 Max](/artikel/spesifikasi-lengkap-geely-ex2-max/). Penjelasan tentang jenis baterainya ada di [baterai LFP 40,8 kWh yang aman dan tahan lama](/artikel/baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama/).

## Memilih antara Pro dan Max

Kedua varian berbagi baterai, motor, dan torsi yang sama. Selisihnya ada pada kelengkapan. Max menambahkan velg 16 inci, kamera 540 derajat, ADAS Level 2, V2L, dan kontrol lewat aplikasi, sementara Pro lebih sederhana.

Cara paling praktis memutuskan adalah mendaftar fitur yang benar-benar Anda pakai. Jika parkir sempit adalah masalah utama, kamera akan terasa berharga. Jika Anda jarang menyetir jauh, fitur bantuan pengemudi mungkin bukan prioritas. Pembahasan lengkapnya ada di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Soal mengisi daya: apa yang perlu disiapkan

Bagi banyak calon pemilik, pengisian daya adalah kekhawatiran terbesar. Faktanya, pengisian AC dari rumah membutuhkan sekitar 6,5 jam untuk 10-100%, sehingga cocok dilakukan semalaman. Pengisian cepat DC mengisi 30-80% dalam sekitar 25 menit untuk saat Anda butuh tambahan di perjalanan.

Pertanyaan yang perlu dijawab lebih dulu adalah tempat Anda parkir. Rumah dengan garasi sendiri paling mudah. Apartemen memerlukan izin pengelola. Daya listrik terpasang dan kebutuhan instalasi sebaiknya ditanyakan ke tim kami serta ke PLN, karena kami tidak menebak angka di luar data resmi.

## Cocok untuk siapa, dan kapan sebaiknya menunggu

EX2 cocok bagi Anda yang mobilitas hariannya dalam kota, punya tempat mengisi daya yang jelas, dan menyukai mobil yang mudah dikendalikan. Pemula pun relatif cepat beradaptasi karena tidak ada kopling maupun pindah gigi; kami membahasnya di [EX2 Max untuk pemula dan wanita](/artikel/geely-ex2-max-mudah-dikendarai-untuk-pemula-dan-wanita/).

Jika Anda sering menempuh perjalanan antarkota dengan keluarga besar dan banyak bagasi, bandingkan dahulu dengan [Geely EX5](/model/geely-ex5/) yang lebih lega. Memilih yang pas jauh lebih penting daripada memilih yang paling canggih.

## Cara mencoba dan langkah berikutnya

Test drive adalah penentu terbaik. Datanglah dengan rute harian Anda di kepala, ajak orang yang biasa duduk di sebelah, dan siapkan lima hal yang ingin diuji. Panduan persiapannya ada di [cara test drive Geely](/artikel/cara-test-drive-geely/).

Setelah mencoba, minta simulasi tertulis dan bandingkan dengan kebutuhan bulanan Anda. Informasi lokasi ada di halaman [dealer Geely MAI Jakarta](/lokasi/geely-mai-jakarta/). Jika Anda masih menimbang model lain, mulailah dari panduan [mobil listrik pertama](/lp/mobil-listrik-pertama/) atau [mobil listrik keluarga](/lp/mobil-listrik-keluarga/).

## Fitur kabin yang paling sering diperhatikan

Saat duduk di dalam, perhatian pertama biasanya tertuju pada layar tengah 14,6 inci. Layar sebesar ini memusatkan kontrol AC, hiburan, dan pengaturan kendaraan, sehingga tombol fisik lebih sedikit. Sebagian orang menyukainya karena tampilan bersih, sebagian lain perlu waktu untuk terbiasa. Cobalah mengaturnya saat mobil berhenti agar Anda tahu seberapa cepat menemukan menu yang dicari.

Panel instrumen berukuran 8,8 inci menampilkan informasi berkendara di depan mata pengemudi. Di bagian belakang, bagasi 375 liter dapat diperluas hingga 1.320 liter dengan melipat jok, dan frunk 70 liter di depan berguna untuk menyimpan kabel pengisi atau barang kecil agar bagasi utama tetap lapang. Ruang penyimpanan ekstra seperti ini sering menentukan kenyamanan harian, lebih dari angka tenaga.

## Menimbang biaya kepemilikan dengan cara sederhana

Daripada memikirkan angka rumit, mulailah dari tiga pertanyaan. Berapa kilometer yang Anda tempuh dalam sebulan? Di mana Anda akan mengisi daya, dan apakah perlu instalasi tambahan? Berapa lama Anda berencana memakai mobil ini? Jawaban ketiganya membentuk gambaran biaya yang jauh lebih jujur daripada perbandingan sekilas.

Setelah itu, hitung selisih biaya energi dan perawatan dengan mobil yang Anda pakai sekarang memakai data Anda sendiri. Panduannya ada di [cara menghitung biaya operasional mobil listrik](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Kami sengaja tidak menjanjikan penghematan tertentu, karena hasilnya bergantung pada kebiasaan Anda.

## Hal yang sering ditanyakan sebelum datang

Beberapa orang ingin tahu apakah bisa datang tanpa janji. Sebaiknya buat janji agar unit dan sales siap. Yang lain bertanya soal dokumen: untuk sekadar mencoba, bawa SIM yang berlaku. Untuk pembahasan kredit, tim kami akan menjelaskan kelengkapan yang diperlukan saat konsultasi.

Ada pula yang bertanya apakah angka jarak 395 km akan tercapai sehari-hari. Itu klaim pabrikan dengan metode NEDC, sehingga pemakaian nyata bisa berbeda tergantung gaya mengemudi, beban, dan kondisi jalan. Karena itu, pikirkan jarak harian Anda, bukan angka maksimumnya.

## Pertanyaan yang sering diajukan

### Berapa lama mengisi daya EX2 di rumah?

Klaim pabrikan untuk pengisian AC 10-100% adalah sekitar 6,5 jam, jadi cocok untuk semalam.

### Apakah EX2 muat untuk keluarga kecil?

EX2 menampung 5 penumpang dan bagasi 375 liter. Cobalah langsung dengan barang yang biasa Anda bawa.

### Apakah harga ditulis di halaman ini?

Tidak. Harga dan promo berubah, jadi lihat halaman [promo](/promo/) atau minta penawaran tertulis dari kami.

### Bagaimana cara mengatur test drive?

Hubungi kami lewat halaman [kontak](/kontak/) dan sebutkan model serta jam yang Anda inginkan.

## Kesimpulan

Geely EX2 adalah pilihan masuk akal untuk rutinitas kota: ringkas, tenang, dan punya data pengisian yang jelas. Pastikan dulu tempat mengisi daya Anda, tentukan varian dari fitur yang benar-benar dipakai, lalu buktikan sendiri lewat test drive.

Atur jadwal Anda lewat halaman [kontak](/kontak/) dan tim Geely MAI akan menyiapkan unitnya.
