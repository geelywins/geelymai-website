---
title: "Tukar Tambah Mobil Lama ke Mobil Listrik Geely: Alurnya"
description: "Ingin tukar tambah mobil lama ke mobil listrik Geely? Pahami dokumen, penilaian unit, dan urutan prosesnya agar lancar, lalu konsultasi di Geely MAI Jakarta."
date: 2026-10-14
tags: ["tukar tambah mobil lama", "tukar tambah geely", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "beli mobil listrik", "harga mobil listrik geely", "ganti mobil lama"]
artikel: ["alur-membeli-mobil-geely-dari-booking-sampai-serah-terima", "simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan", "tips-booking-dan-negosiasi-geely-ex2-max", "cek-mobil-baru-saat-serah-terima-checklist-pdi", "faq-geely-pertanyaan-calon-pembeli-sebelum-beli"]
draft: true
---

Tukar tambah mobil lama ke mobil listrik Geely berjalan lancar bila Anda menyiapkan dokumen, memahami cara unit dinilai, dan mengurus urutan prosesnya dengan benar. Halaman ini menjelaskan alur umum, hal yang memengaruhi penilaian, dan cara berdiskusi dengan tim Geely MAI sebelum memutuskan.

## Mengapa tukar tambah menarik bagi banyak orang

Sebagian besar calon pembeli sudah memiliki mobil. Menjual sendiri butuh waktu, tenaga, dan kesabaran menghadapi banyak penawar. Tukar tambah menggabungkan dua urusan: mobil lama pindah tangan dan mobil baru masuk garasi dalam satu proses.

Kemudahan itu punya harga, yakni Anda perlu memahami cara penilaian agar tidak kaget. Kami menyarankan Anda membandingkan penawaran tukar tambah dengan pilihan lain, lalu memutuskan dengan kepala dingin. Tidak ada keharusan menerima penawaran pertama.

## Alur umum dari awal sampai akhir

Secara garis besar, ada lima tahap. Pertama, konsultasi dan pemilihan model. Kedua, penilaian mobil lama oleh pihak yang berwenang. Ketiga, penawaran tertulis yang memuat nilai tukar dan skema pembelian mobil baru. Keempat, kesepakatan dan pemesanan. Kelima, serah terima dan pengurusan administrasi.

Detail dari booking sampai serah terima kami uraikan di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/). Urutan bisa sedikit berbeda tergantung kondisi unit dan pembiayaan Anda, jadi tanyakan jadwal tepatnya kepada tim kami.

## Hal yang memengaruhi penilaian mobil lama

Penilai biasanya memperhatikan merek dan tipe, tahun pembuatan, jarak tempuh, kondisi mesin dan bodi, serta kelengkapan surat dan riwayat servis. Mobil yang terawat dengan catatan servis rapi umumnya lebih mudah dinilai dan lebih meyakinkan.

Kami tidak menuliskan angka nilai tukar karena sangat bervariasi. Sebelum datang, bersihkan mobil, kumpulkan buku servis, dan catat kekurangan yang Anda ketahui. Kejujuran di awal mencegah perselisihan di akhir. Anda juga boleh membandingkan penilaian dari beberapa pihak.

## Dokumen yang perlu disiapkan

| Kelompok | Contoh yang umumnya diminta |
|---|---|
| Identitas pemilik | KTP dan identitas pendukung |
| Kendaraan lama | STNK, BPKB, dan faktur bila ada |
| Riwayat | Buku servis dan kunci cadangan |
| Pembiayaan baru | Dokumen sesuai ketentuan lembaga pembiayaan |

Daftar di atas hanya gambaran umum. Kelengkapan sebenarnya ditentukan oleh pihak terkait, sehingga konfirmasikan dengan tim kami. Bila mobil lama masih dalam masa cicilan, informasikan sejak awal karena ada urusan pelunasan yang perlu diatur. Rincian dokumen kredit ada di [syarat dan dokumen kredit mobil listrik](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/).

## Menyambungkan dengan skema pembelian baru

Nilai tukar mobil lama dapat berperan sebagai uang muka atau pengurang kewajiban. Bagaimana tepatnya bergantung pada kesepakatan dan skema pembiayaan Anda. Minta semua angka secara tertulis agar bisa dibandingkan dengan tenang.

Untuk memahami hubungan uang muka, tenor, dan cicilan, baca [simulasi kredit mobil listrik: DP, tenor, dan cicilan](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/). Persetujuan pembiayaan tetap mengikuti ketentuan lembaga pembiayaan, bukan keputusan dealer.

## Cara berdiskusi dan menawar dengan sopan

Datanglah dengan gambaran kebutuhan dan batas anggaran Anda. Tanyakan penjelasan atas setiap komponen penawaran: nilai tukar, biaya administrasi, dan program yang berlaku. Meminta rincian bukan tanda tidak percaya, melainkan cara menjaga transparansi.

Tips lebih rinci ada di [tips booking dan negosiasi](/artikel/tips-booking-dan-negosiasi-geely-ex2-max/). Ingat bahwa harga dan promo selalu berubah; lihat halaman [promo](/promo/) atau minta penawaran tertulis yang masih berlaku.

## Setelah sepakat: pemeriksaan saat serah terima

Saat mobil baru Anda siap, periksa unit dengan teliti sebelum menandatangani serah terima. Cek bodi, kelengkapan, fungsi layar, dan dokumen. Daftar pemeriksaan ada di [cek mobil baru saat serah terima: checklist PDI](/artikel/cek-mobil-baru-saat-serah-terima-checklist-pdi/).

Pastikan semua kunci dan kelengkapan diterima, serta jadwal servis pertama jelas. Bila ada pertanyaan yang belum terjawab, ajukan sebelum Anda pulang. Pertanyaan umum lain terjawab di [FAQ Geely untuk calon pembeli](/artikel/faq-geely-pertanyaan-calon-pembeli-sebelum-beli/).

## Pilih model yang cocok untuk menggantikan mobil lama

Tukar tambah sering dimulai dari perasaan mobil lama sudah tidak cocok: terlalu boros, terlalu kecil, atau terlalu besar. Gunakan momentum ini untuk memilih ulang dengan jernih. Mobil kompak, SUV listrik, atau plug-in hybrid tersedia sebagai pilihan.

Lihat [Geely EX2](/lp/geely-ex2-jakarta/), [Geely EX5](/lp/geely-ex5-jakarta/), atau [Starray EM-i](/lp/geely-starray-em-i-jakarta/). Semua model ada di [halaman model](/model/), dan lokasi dealer ada di [Geely MAI Jakarta](/lokasi/geely-mai-jakarta/). Datanglah dengan mobil lama bila ingin penilaian awal.

## Mengatur waktu agar tidak terburu-buru

Tukar tambah paling nyaman dilakukan ketika Anda tidak sedang dikejar waktu. Bila mobil lama adalah satu-satunya kendaraan keluarga, atur jadwal agar tidak ada hari tanpa mobil. Tanyakan perkiraan waktu serah terima unit baru, lalu sesuaikan kapan mobil lama diserahkan.

Beri juga ruang untuk hal tak terduga, seperti kekurangan dokumen atau penjadwalan penilaian yang bergeser. Dengan jeda cadangan beberapa hari, Anda tidak perlu mengambil keputusan tergesa. Komunikasi yang terbuka dengan tim kami sepanjang proses akan sangat membantu menjaga semuanya tetap tenang. Jika ada perubahan rencana di tengah jalan, kabari kami secepatnya agar jadwal penilaian, pemesanan, dan serah terima dapat disesuaikan tanpa menimbulkan biaya atau kerepotan yang tidak perlu.

## Hal yang sebaiknya tidak dilakukan

Hindari menyembunyikan kerusakan atau riwayat kecelakaan, karena penilai biasanya akan menemukannya dan kepercayaan bisa hilang. Hindari pula memutuskan di hari pertama tanpa membandingkan, atau menandatangani dokumen yang belum Anda pahami isinya. Bacalah setiap lembar dan minta penjelasan bila ada istilah yang asing.

Hindari juga mengandalkan janji lisan. Setiap nilai, biaya, dan bonus harus tertulis di penawaran. Dengan disiplin sederhana ini, proses tukar tambah berjalan jujur, jelas, dan minim kejutan bagi kedua belah pihak.

## Pertanyaan yang sering diajukan

### Apakah mobil lama harus lunas?

Tidak harus, tetapi informasikan kondisinya agar pelunasan bisa diatur.

### Berapa lama proses penilaian?

Tergantung antrean dan kelengkapan. Tanyakan jadwalnya kepada tim kami.

### Apakah nilai tukar sudah pasti?

Nilai ditentukan pada saat penilaian dan tertuang dalam penawaran tertulis.

### Bisakah saya mencoba mobil baru dulu?

Bisa. Atur test drive lewat halaman [kontak](/kontak/).

## Kesimpulan

Tukar tambah menjadi mudah bila dokumen siap, penilaian dipahami, dan semua angka tertulis. Pilih mobil baru sesuai kebutuhan, bandingkan penawaran, dan periksa unit saat serah terima.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk memulai penilaian awal.
