---
title: "Mobil Listrik Pertama: Langkah Tenang dari Ragu sampai Yakin"
description: "Baru mau beli mobil listrik pertama? Ikuti enam langkah sederhana dari mencatat kebutuhan sampai test drive Geely bersama tim Geely MAI di Jakarta."
date: 2026-10-14
tags: ["mobil listrik pertama", "mobil listrik geely", "geely ev", "geely indonesia", "beli mobil listrik", "ev geely jakarta", "mobil listrik murah", "mobil listrik kompak", "panduan mobil listrik"]
artikel: ["tips-memilih-mobil-listrik-pertama", "alur-membeli-mobil-geely-dari-booking-sampai-serah-terima", "cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu", "mitos-mobil-listrik-yang-sering-dipercaya-dan-faktanya", "istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen"]
draft: true
---

Mobil listrik pertama sebaiknya dipilih dengan tenang: catat kebutuhan Anda, pahami cara mengisi daya, kenali istilah dasar, baru uji langsung. Halaman ini memandu enam langkah sederhana agar Anda yakin sebelum memutuskan, dengan contoh data Geely yang bisa dipercaya dan ajakan mencoba di dealer Geely MAI.

## Wajar kalau masih ragu

Beralih ke mobil listrik terasa seperti melompat ke hal baru. Banyak pertanyaan muncul sekaligus: bagaimana mengisinya, apakah tahan lama, apakah sulit dirawat. Keraguan itu sehat, dan justru tanda Anda mempertimbangkan dengan serius.

Kabar baiknya, sebagian besar kekhawatiran bisa dijawab dengan langkah yang berurutan. Anda tidak perlu menjadi ahli teknik. Cukup ikuti enam langkah berikut, dan bila ada yang belum jelas, tanyakan langsung kepada tim kami.

## Langkah 1: catat kebiasaan berkendara Anda

Selama satu minggu, tulis jarak harian, tujuan, dan tempat Anda parkir. Hasilnya adalah peta kebutuhan Anda yang sebenarnya. Banyak orang terkejut karena jarak harian mereka jauh lebih pendek daripada perkiraan.

Dengan catatan itu, Anda bisa menilai apakah klaim jarak mobil sudah lebih dari cukup. Misalnya, [Geely EX2](/model/geely-ex2/) mengklaim 395 km (NEDC), sedangkan [Geely EX5](/model/geely-ex5/) mengklaim 490-495 km (NEDC). Angka ini hanya klaim pabrikan, jadi gunakan sebagai pembanding. Bacaan awal ada di [tips memilih mobil listrik pertama](/artikel/tips-memilih-mobil-listrik-pertama/).

## Langkah 2: pastikan tempat mengisi daya

Ini langkah yang paling menentukan. Rumah dengan garasi paling mudah, apartemen memerlukan izin, dan tanpa fasilitas apa pun Anda mengandalkan pengisian umum. Pahami skenario Anda sebelum jatuh hati pada sebuah model.

Gambaran umum pengisian ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/). Jika Anda tinggal di apartemen, baca [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

## Langkah 3: kenali istilah dasar

Istilah teknis sering membuat orang minder. Padahal hanya beberapa yang perlu dihafal. kWh adalah ukuran energi baterai. AC dan DC adalah dua jenis pengisian, yaitu pelan dan cepat. V2L adalah kemampuan mobil menyuplai listrik ke perangkat lain. Regen adalah rem regeneratif yang mengembalikan sebagian energi ke baterai.

Dengan empat istilah itu, Anda sudah bisa membaca sebagian besar brosur. Uraian singkat ada di [istilah mobil listrik: kWh, AC, DC, V2L, dan regen](/artikel/istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen/).

## Langkah 4: lawan mitos dengan fakta

Banyak kabar beredar tentang mobil listrik, sebagian benar dan sebagian berlebihan. Misalnya soal daya tahan baterai, banjir, atau perawatan. Daripada percaya begitu saja, bandingkan dengan sumber resmi dan pengalaman langsung.

Kami merangkum beberapa anggapan umum dalam [mitos mobil listrik yang sering dipercaya dan faktanya](/artikel/mitos-mobil-listrik-yang-sering-dipercaya-dan-faktanya/). Bila ada hal yang tidak tercantum di sumber resmi, kami akan menjawab jujur bahwa kami tidak tahu dan menyarankan Anda bertanya ke pihak yang berwenang.

## Langkah 5: pilih model yang sesuai, bukan yang paling mahal

Mobil kompak sesuai untuk rutinitas kota, SUV listrik untuk keluarga dan perjalanan jauh, sedangkan plug-in hybrid untuk mereka yang butuh fleksibilitas bensin. Tidak ada pilihan terbaik untuk semua orang.

| Kebutuhan | Pertimbangkan |
|---|---|
| Rutinitas kota, parkir sempit | [Geely EX2](/lp/geely-ex2-jakarta/) |
| Keluarga, perjalanan jauh | [Geely EX5](/lp/geely-ex5-jakarta/) |
| Fleksibel antara listrik dan bensin | [Starray EM-i](/lp/geely-starray-em-i-jakarta/) |

Bila masih bimbang antara listrik dan hybrid, baca [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/).

## Langkah 6: uji langsung dan minta penawaran tertulis

Test drive adalah penentu. Datang bersama orang yang akan sering memakai mobil, bawa daftar pertanyaan, dan coba rute yang biasa Anda lewati. Persiapannya dibahas di [cara test drive Geely](/artikel/cara-test-drive-geely/).

Setelah itu, bila tertarik, ikuti [alur membeli mobil Geely dari booking sampai serah terima](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/). Jangan terburu-buru; minta penawaran tertulis, bandingkan, dan pulang untuk berdiskusi dulu.

## Kesalahan yang sering terjadi pada pembeli pertama

Kesalahan pertama adalah memilih berdasarkan angka terbesar. Jarak tempuh tertinggi atau baterai terbesar belum tentu berguna bila kebutuhan harian Anda jauh lebih kecil. Mobil yang terlalu besar justru bisa merepotkan di parkir dan jalan sempit.

Kesalahan kedua adalah mengabaikan tempat mengisi daya sampai mobil sudah di tangan. Ini sumber kekecewaan yang paling umum, dan mudah dicegah dengan bertanya sejak awal. Kesalahan ketiga adalah memutuskan di bawah tekanan. Tidak ada alasan untuk terburu-buru; pulang, tidur dulu, dan baca ulang catatan Anda esok hari.

Kesalahan keempat adalah tidak membandingkan. Cobalah lebih dari satu model bila memungkinkan, dan catat kesan Anda dengan kriteria yang sama. Dengan begitu, keputusan Anda lahir dari pengalaman, bukan dari dorongan sesaat. Simpan juga catatan itu; beberapa bulan kemudian, Anda bisa membacanya kembali dan menilai apakah pilihan Anda sudah tepat sasaran. Kebiasaan mencatat ini membantu Anda belajar dari setiap keputusan besar, tidak hanya soal mobil. Bila Anda ingin ditemani menyusun kriteria, tim kami dengan senang hati membantu.

## Hal yang sebaiknya Anda tanyakan di dealer

Siapkan beberapa pertanyaan: ketersediaan unit, perkiraan waktu serah terima, jadwal servis berkala, dan syarat pembiayaan. Untuk informasi seperti garansi, kami meminta Anda mendapatkan jawaban tertulis, karena kami tidak mencantumkan angka yang belum terverifikasi.

Anda bisa melihat lokasi kami di [dealer Geely MAI Jakarta](/lokasi/geely-mai-jakarta/). Untuk menjadwalkan kunjungan, gunakan halaman [kontak](/kontak/) dan sebutkan model yang ingin dicoba. Semakin jelas informasi Anda, semakin tepat persiapan kami.

## Setelah mobil tiba: bulan pertama yang menyenangkan

Hari-hari awal adalah masa belajar. Biasakan diri dengan rem regeneratif, atur posisi jok dan spion sebelum berangkat, dan coba pengaturan layar saat mobil berhenti. Jangan khawatir bila belum langsung nyaman; itu proses yang wajar.

Buat rutinitas pengisian yang sederhana, misalnya mencolokkan kabel setiap pulang kerja. Setelah dua minggu, Anda akan terbiasa dan hampir tidak memikirkannya lagi. Bila ada pertanyaan, hubungi tim dealer; pertanyaan kecil sekalipun layak dijawab.

## Pertanyaan yang sering diajukan

### Apakah mobil listrik sulit dikendarai?

Tidak. Tanpa kopling dan perpindahan gigi, banyak pemula cepat beradaptasi.

### Berapa lama mengisi daya?

Tergantung model. EX2 mengklaim AC 10-100% sekitar 6,5 jam dan DC 30-80% sekitar 25 menit.

### Apakah ada promo untuk pembeli pertama?

Lihat halaman [promo](/promo/) atau tanyakan langsung kepada kami.

### Bagaimana jika masih ragu?

Datang untuk test drive tanpa kewajiban membeli.

## Kesimpulan

Memilih mobil listrik pertama tidak perlu menegangkan. Catat kebiasaan, pastikan tempat mengisi daya, pahami istilah, lawan mitos, pilih sesuai kebutuhan, dan uji langsung.

Hubungi tim Geely MAI lewat halaman [kontak](/kontak/) kapan pun Anda siap melangkah.
