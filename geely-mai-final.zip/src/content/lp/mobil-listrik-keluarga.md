---
title: "Mobil Listrik Keluarga: Menimbang Geely EX2 dan EX5 Bersama Anak"
description: "Mencari mobil listrik keluarga? Bandingkan Geely EX2 dan EX5 dari ruang kabin, bagasi, keselamatan anak, dan kebiasaan harian, lalu coba bersama keluarga."
date: 2026-10-14
tags: ["mobil listrik keluarga", "geely ex2", "geely ex5", "mobil listrik geely", "geely ev", "geely indonesia", "suv listrik keluarga", "mobil listrik kompak", "ev geely jakarta"]
artikel: ["geely-ex2-max-untuk-keluarga-muda", "kabin-dan-bagasi-geely-ex5-461-liter", "keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas", "perbandingan-geely-ex2-vs-ex5-pilih-yang-mana", "bagasi-375-liter-dan-frunk-70-liter-geely-ex2-muat-apa-saja"]
draft: false
---

Mobil listrik keluarga yang tepat ditentukan oleh ruang, rasa aman, dan kebiasaan harian, bukan semata oleh angka baterai. Halaman ini membantu Anda menimbang Geely EX2 dan EX5 dengan sudut pandang keluarga, lalu mengajak seluruh anggota keluarga mencobanya langsung di dealer Geely MAI.

## Mulai dari siapa saja yang naik

Sebelum membandingkan model, tuliskan daftar penumpang tetap Anda. Berapa orang dewasa, berapa anak, adakah balita yang memakai kursi khusus, atau orang tua yang butuh akses mudah? Daftar ini sering mengubah pilihan Anda lebih banyak daripada spesifikasi apa pun.

Setelah itu, catat barang yang hampir selalu ikut: stroller, tas sekolah, perlengkapan olahraga, atau belanjaan mingguan. Ruang bagasi yang cukup membuat keluarga tidak perlu berkompromi setiap kali berangkat. Kedua pertimbangan inilah yang kami pakai sebagai dasar perbandingan di halaman ini.

## EX2: ringkas untuk keluarga kecil

[Geely EX2](/model/geely-ex2/) menampung 5 penumpang dengan bagasi 375 liter yang bisa membesar hingga 1.320 liter, ditambah frunk 70 liter di depan. Ukuran ringkas memudahkan manuver di perumahan dan parkir sekolah. Untuk keluarga muda dengan satu atau dua anak, ini bisa terasa cukup.

Kami membahas skenario penggunaannya di [EX2 Max untuk keluarga muda](/artikel/geely-ex2-max-untuk-keluarga-muda/) dan isi bagasinya di [bagasi 375 liter dan frunk 70 liter](/artikel/bagasi-375-liter-dan-frunk-70-liter-geely-ex2-muat-apa-saja/). Cobalah memasukkan stroller dan tas Anda ketika berkunjung agar penilaiannya nyata.

## EX5: lega untuk perjalanan lebih jauh

[Geely EX5](/model/geely-ex5/) berukuran 4.615 x 1.901 x 1.670 mm dengan bagasi 461 liter, meluas hingga 1.877 liter saat jok belakang 60/40 dilipat. Kabinnya lebih lega, dan baterai 60,22 kWh memberi klaim jarak NEDC 490-495 km.

Keluarga yang sering bepergian jauh atau membawa banyak barang biasanya merasakan manfaatnya. Pembahasan ruang ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/). Karena ukurannya lebih besar, parkir di tempat sempit tentu memerlukan perhatian lebih.

## Perbandingan ringkas

| Aspek | EX2 | EX5 |
|---|---|---|
| Bagasi | 375 liter (hingga 1.320) + frunk 70 liter | 461 liter (hingga 1.877) |
| Baterai | LFP 40,8 kWh | LFP 60,22 kWh |
| Klaim jarak | 395 km (NEDC) | 490-495 km (NEDC) |
| Pengisian DC | 30-80% sekitar 25 menit | Hingga 100 kW |
| Karakter | Kompak, lincah | SUV, lega |

Semua angka adalah klaim pabrikan. Analisis lengkap ada di [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/). Tidak ada pemenang mutlak; yang ada hanyalah pilihan yang paling cocok dengan keluarga Anda.

## Keselamatan anak: apa yang perlu dicek

Brosur EX5 mencantumkan ISOFIX dan child anchor di jok belakang, kunci pengaman anak, serta airbag depan, samping depan, dan tirai samping. Brosur tidak menyebut jumlah total airbag, jadi kami tidak menuliskannya. Fitur seperti ESC, ABS, dan kamera 360 derajat juga tersedia pada semua varian.

Detailnya ada di [keamanan EX5](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/). Untuk EX2, data resmi mencantumkan 6 airbag. Bawa kursi anak Anda saat test drive, pasang, dan lihat apakah pemasangannya mudah serta pas. Ini ujian yang tidak bisa digantikan brosur.

## Mengisi daya dalam rutinitas keluarga

Keluarga biasanya punya pola: pulang sore, parkir, lalu istirahat. Pola ini cocok dengan pengisian semalam di rumah. EX2 mengklaim AC 10-100% sekitar 6,5 jam, sedangkan EX5 mendukung AC hingga 11 kW dan DC hingga 100 kW.

Pastikan tempat parkir Anda memungkinkan pengisian. Panduan umumnya ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/). Jika Anda tinggal di apartemen, baca dulu [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

## Cara test drive bersama keluarga

Datanglah dengan semua yang biasa naik. Biarkan anak duduk di jok belakang, minta orang tua mencoba naik turun, dan cek kenyamanan AC di belakang. Tanyakan apakah ada yang merasa mual atau kurang nyaman pada jalan berlubang.

Gunakan daftar sederhana: ruang kaki, tinggi pandang, kemudahan memasang kursi anak, dan kemudahan memuat bagasi. Persiapan lengkap ada di [cara test drive Geely](/artikel/cara-test-drive-geely/). Lokasi dealer ada di halaman [Geely MAI Jakarta](/lokasi/geely-mai-jakarta/).

## Kenyamanan penumpang belakang

Dalam keluarga, penumpang belakang sering terlupakan saat memilih mobil. Padahal mereka yang paling lama duduk diam. EX5 menyediakan sandaran jok belakang yang bisa diatur manual, armrest tengah dengan headrest, serta lubang AC belakang, dan dua port USB-C untuk mengisi gawai.

Untuk EX2, uji sendiri kenyamanan jok belakang dengan duduk selama beberapa menit. Rasakan ruang kepala dan ruang kaki, terutama jika anak Anda sudah besar. Ajak anak naik sendiri, lalu tanyakan pendapat mereka. Respons spontan seorang anak sering lebih jujur daripada brosur mana pun.

Jangan lupa menanyakan hal sepele namun penting: apakah tinggi pijakan terlalu tinggi untuk orang tua, apakah pintu terbuka cukup lebar untuk memasang kursi anak, dan apakah rak kecil di kabin cukup untuk botol minum serta camilan. Hal-hal kecil inilah yang menentukan apakah mobil menyenangkan dipakai setiap hari, bukan hanya mengesankan saat pertama dilihat.

## Menyiapkan kebiasaan baru bersama keluarga

Beralih ke mobil listrik juga berarti mengubah beberapa kebiasaan kecil. Mencolokkan kabel setelah pulang menjadi ritual baru, dan seluruh anggota keluarga perlu tahu caranya. Ajarkan anak yang lebih besar untuk tidak bermain di dekat kabel dan area pengisian demi keselamatan.

Diskusikan pula rencana perjalanan panjang bersama. Dengan EX5, misalnya, Anda bisa merencanakan pemberhentian pengisian sekaligus waktu istirahat anak. Perencanaan sederhana mengubah pengisian daya dari beban menjadi jeda yang berguna. Bacaan lanjutan tersedia di [tips memilih mobil listrik pertama](/artikel/tips-memilih-mobil-listrik-pertama/).

## Pertanyaan yang sering diajukan

### Mana yang lebih cocok untuk keluarga dengan dua anak?

Keduanya mungkin. EX2 lebih ringkas, EX5 lebih lega. Cobalah dengan barang bawaan Anda.

### Apakah ada tempat kursi anak?

Brosur EX5 menyebut ISOFIX dan child anchor di jok belakang. Untuk EX2, tanyakan ke sales.

### Apakah ada promo keluarga?

Lihat halaman [promo](/promo/) atau hubungi tim kami.

### Bagaimana cara mencoba?

Atur jadwal lewat halaman [kontak](/kontak/).

## Kesimpulan

Mobil listrik keluarga yang pas adalah yang sesuai dengan penumpang dan barang bawaan Anda. EX2 unggul pada keringkasan, EX5 pada kelegaan, dan keduanya perlu dicoba bersama seluruh keluarga.

Hubungi Geely MAI lewat halaman [kontak](/kontak/) untuk mengatur sesi coba keluarga.
