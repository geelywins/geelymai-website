---
title: "Mobil Listrik untuk Perusahaan: Menyusun Kebutuhan Armada Kantor"
description: "Menyiapkan mobil listrik untuk perusahaan? Petakan peran kendaraan, pengisian di kantor, dan perawatan, lalu jadwalkan sesi coba bersama Geely MAI Jakarta."
date: 2026-10-14
tags: ["mobil listrik untuk perusahaan", "mobil listrik armada", "mobil listrik geely", "geely ev", "geely indonesia", "geely ex5", "mobil operasional kantor", "ev geely jakarta", "pengadaan armada geely"]
model: "geely-ex5"
artikel: ["cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin", "pasang-charger-mobil-listrik-di-rumah-daya-pln-dan-instalasi", "perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin", "simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan", "alur-membeli-mobil-geely-dari-booking-sampai-serah-terima"]
draft: true
---

Mobil listrik untuk perusahaan perlu dimulai dari peta kebutuhan: siapa memakai, ke mana, berapa jauh, dan di mana mengisi dayanya. Halaman ini membantu tim pengadaan menyusun pertanyaan tersebut, memahami data Geely yang relevan, dan menyiapkan sesi coba bersama tim Geely MAI Jakarta.

## Mulai dari peran kendaraan, bukan dari merek

Perusahaan biasanya memiliki beberapa jenis kebutuhan kendaraan. Ada mobil untuk direksi, mobil operasional harian, mobil pengantar dokumen, dan kendaraan pendukung kegiatan lapangan. Setiap peran memiliki pola jarak dan jam pakai yang berbeda.

Langkah pertama adalah mengelompokkan peran itu. Kendaraan yang dipakai dalam kota dengan jarak pendek akan berbeda kebutuhannya dibandingkan kendaraan yang sering ke luar kota. Dengan pengelompokan ini, Anda tidak perlu memilih satu model untuk semua keperluan, dan evaluasi menjadi lebih adil.

## Mengumpulkan data pemakaian

Minta pengguna kendaraan mencatat data selama dua sampai empat minggu: jarak harian, jam keberangkatan dan kepulangan, titik tujuan, serta tempat parkir malam. Data ini menjadi dasar semua perhitungan berikutnya.

Dari data tersebut, kami dapat membantu menilai apakah klaim jarak model tertentu mencukupi. Contohnya, [Geely EX5](/model/geely-ex5/) mengklaim jarak NEDC 490-495 km dan WLTP 425-430 km. Semua angka adalah klaim pabrikan, sehingga evaluasi akhir sebaiknya dilakukan lewat uji langsung.

## Pengisian daya di kantor dan di rumah pengguna

Pertanyaan terbesar bagi perusahaan adalah lokasi pengisian. Apakah kendaraan menginap di kantor, atau dibawa pulang oleh karyawan? Jika menginap di kantor, perusahaan perlu menyiapkan instalasi di area parkir. Jika dibawa pulang, pengisian di rumah karyawan menjadi isu tersendiri.

Aspek teknis seperti daya terpasang dan instalasi kami bahas di [memasang charger: daya PLN dan instalasi](/artikel/pasang-charger-mobil-listrik-di-rumah-daya-pln-dan-instalasi/). Kami tidak menebak angka daya; silakan konsultasikan dengan PLN dan teknisi listrik bersertifikat. Dari sisi mobil, EX5 mendukung AC hingga 11 kW dan DC CCS2 hingga 100 kW.

## Biaya operasional: hitung dengan data Anda

Tim keuangan biasanya ingin membandingkan biaya jangka panjang. Kami tidak menuliskan angka penghematan karena hasilnya sangat bergantung pada tarif listrik, harga BBM, jarak, dan kebiasaan pengguna. Yang bisa kami berikan adalah kerangka perhitungan.

Panduannya ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Gunakan data pemakaian yang sudah Anda kumpulkan, dan masukkan komponen energi, perawatan, serta pembiayaan. Dengan begitu, laporan kepada manajemen bersandar pada angka nyata perusahaan.

## Perawatan dan operasional

Mobil listrik tidak memiliki mesin pembakaran, sehingga beberapa komponen perawatan berbeda dari mobil bensin. Namun komponen seperti rem, ban, dan suspensi tetap memerlukan perhatian berkala. Jadwal servis dan biaya resmi sebaiknya Anda tanyakan tertulis ke sales.

Uraian umum ada di [perawatan mobil listrik: apa bedanya dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/). Untuk keperluan tata kelola armada, kami menyarankan menyusun log perawatan dan pengisian agar mudah ditinjau saat audit.

## Pembiayaan dan proses pengadaan

Perusahaan dapat memiliki mekanisme pembiayaan yang berbeda dari pembeli perorangan. Sebutkan hal ini sejak awal kepada kami agar dokumen dan alurnya disiapkan dengan tepat. Gambaran umum skema kredit ada di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

Untuk alur dari pemesanan sampai serah terima, baca [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/). Harga dan promo berubah-ubah, jadi minta penawaran tertulis yang berlaku untuk pembelian lebih dari satu unit.

## Fitur yang relevan untuk pemakaian kantor

Beberapa fitur EX5 relevan untuk operasional: kamera 360 derajat untuk parkir, ISOFIX bila membawa anak atau keluarga pegawai, pengisian nirkabel untuk ponsel, serta bantuan pengemudi pada varian Max. Fitur V2L juga bisa menyuplai peralatan ringan saat kegiatan di luar kantor.

Pilih varian sesuai peran kendaraan. Untuk kendaraan direksi, kenyamanan seperti jok berventilasi dan pijat pada varian Max mungkin relevan. Untuk operasional harian, varian yang lebih sederhana bisa cukup. Perbandingannya dibahas pada halaman [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Menyusun sesi coba untuk tim

Sebelum memutuskan, ajak perwakilan dari bagian operasional, keuangan, dan pengguna utama. Biarkan masing-masing menilai dari sudut pandangnya. Operasional memeriksa kemudahan pemakaian, keuangan memeriksa kerangka biaya, pengguna menilai kenyamanan.

Kami dapat mengatur sesi di [dealer Geely MAI Jakarta](/lokasi/geely-mai-jakarta/). Sampaikan jumlah peserta dan model yang ingin dicoba lewat halaman [kontak](/kontak/) agar unit siap. Untuk kebutuhan operasional berbasis ride-hailing, lihat juga [mobil listrik untuk taksi online](/lp/mobil-listrik-taksi-online/).

## Aspek tata kelola dan keselamatan armada

Armada perusahaan memerlukan aturan penggunaan yang jelas. Tentukan siapa yang boleh mengemudi, bagaimana prosedur pengisian, dan apa yang harus dilakukan jika terjadi kendala di jalan. Aturan tertulis membuat pengguna merasa tenang dan mengurangi risiko salah penggunaan.

Latih pengemudi tentang hal dasar: cara mencolokkan pengisi daya, arti indikator di layar, dan sikap saat baterai rendah. Pelatihan singkat satu jam sudah banyak membantu. Dealer dapat menjelaskan fitur dasar saat serah terima unit, dan Anda bisa memintanya sebagai bagian dari proses.

Terakhir, siapkan asuransi dan dokumen kendaraan dengan teliti. Bacalah [asuransi mobil listrik yang perlu dicek sebelum memilih](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/) sebelum menandatangani polis. Persiapan yang rapi di awal menghemat banyak waktu di kemudian hari.

## Dampak pada citra dan laporan keberlanjutan

Sebagian perusahaan menimbang armada listrik bukan hanya soal biaya, tetapi juga citra dan komitmen lingkungan. Pertimbangan ini sah, tetapi sebaiknya dituliskan terpisah dari analisis biaya agar keputusan tidak bias. Kami tidak membuat klaim angka pengurangan emisi karena tidak ada datanya dalam sumber resmi kami.

Jika perusahaan Anda menyusun laporan keberlanjutan, sampaikan kebutuhan datanya kepada tim kami sejak awal. Kami akan menyampaikan apa yang bisa dan tidak bisa kami berikan, tanpa janji berlebihan.

## Pertanyaan yang sering diajukan

### Apakah perusahaan bisa membeli lebih dari satu unit?

Bisa. Sampaikan jumlah dan kebutuhan Anda agar kami siapkan penawaran tertulis.

### Apakah perlu instalasi pengisi daya di kantor?

Tergantung pola pemakaian. Konsultasikan dengan PLN dan teknisi.

### Bagaimana jika kendaraan sering ke luar kota?

Rencanakan pengisian di sepanjang rute dan uji klaim jarak lewat test drive.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Pengadaan mobil listrik untuk perusahaan berjalan baik bila diawali dengan peta peran kendaraan, data pemakaian, dan rencana pengisian. Hitung biaya dengan angka Anda sendiri, lalu uji bersama tim.

Hubungi Geely MAI melalui halaman [kontak](/kontak/) untuk menjadwalkan sesi coba perusahaan Anda.
