---
title: "Jarak Tempuh Geely EX5: NEDC 495 km, WLTP 430 km"
description: "Jarak tempuh Geely EX5: NEDC 495 km (Pro) dan 490 km (Max), WLTP 430 km dan 425 km. Pahami selisih kedua standar dan cara menghitung kebutuhan Anda."
date: 2026-10-14
category: "Model Geely"
tags: ["jarak tempuh geely ex5", "geely ex5 nedc wltp", "geely ex5", "suv listrik geely", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Jarak tempuh Geely EX5 menurut brosur resmi adalah 495 km (Pro) dan 490 km (Max) pada standar NEDC, serta 430 km dan 425 km pada standar WLTP. Kedua angka sama-sama klaim laboratorium. Artikel ini menjelaskan mengapa angkanya berbeda, mana yang lebih realistis sebagai pembanding, dan cara menghitung kebutuhan Anda sendiri.

## Dua standar, dua angka

NEDC adalah prosedur pengujian lama yang berjalan dalam kondisi yang cenderung ringan. WLTP lebih baru dan menggunakan pola berkendara yang lebih bervariasi, termasuk kecepatan lebih tinggi. Karena itu angka WLTP umumnya lebih rendah dan dianggap lebih mendekati kondisi nyata.

Brosur EX5 mencantumkan keduanya, yang membantu Anda melihat rentang. Jika Anda ingin sudut pandang konservatif, pakai WLTP sebagai acuan awal, lalu sesuaikan dengan kebiasaan sendiri. Penjelasan umum ada di [NEDC vs WLTP](/artikel/nedc-vs-wltp-arti-jarak-tempuh-mobil-listrik/).

## Tabel angka dari brosur

| Standar | Pro | Max |
|---|---|---|
| NEDC | 495 km | 490 km |
| WLTP | 430 km | 425 km |

Selisih antara varian kecil dan sejalan dengan bobot Max yang lebih berat. Dalam pemakaian sehari-hari, selisih 5 km tidak akan terasa. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Baterai di balik angka

EX5 memakai baterai LFP Short Blade berkapasitas 60,22 kWh. Jarak yang ditempuh adalah hasil energi tersimpan dibagi energi terpakai per kilometer. Energi per kilometer inilah yang dipengaruhi kecepatan, beban, AC, dan gaya mengemudi.

Karena brosur tidak memuat konsumsi energi per kilometer, kami tidak menghitung sendiri dari kapasitas dan jarak. Hasil itu bisa menyesatkan karena mengabaikan kondisi pengujian. Tanyakan data konsumsi resmi kepada sales bila Anda membutuhkannya.

## Mengapa hasil nyata bisa berbeda

Kecepatan tinggi di jalan tol menambah hambatan udara. AC memakai energi dari baterai yang sama. Penumpang dan bagasi menambah beban. Tanjakan dan cuaca panas atau hujan juga memengaruhi.

Mode berkendara juga berperan: brosur menyebut ECO, NORMAL, dan SPORT. Mode ECO umumnya mengutamakan efisiensi. Pelajari bagaimana tiap mode terasa saat test drive dan pilih sesuai situasi.

## Menghitung kebutuhan harian

Catat jarak harian Anda selama dua minggu. Lihat rata-rata, hari terjauh, dan seberapa sering hari terjauh itu muncul. Bandingkan dengan angka WLTP sebagai pembanding konservatif.

Bagi sebagian besar pengguna kota, jarak harian jauh di bawah klaim, sehingga EX5 menyisakan ruang bernapas. Meski begitu, kebiasaan mengisi sebelum baterai terlalu rendah tetap bijak.

## Merencanakan perjalanan jauh

Untuk rute antarkota, bagi perjalanan menjadi beberapa etape dengan titik pengisian yang sudah Anda pilih. EX5 mendukung DC hingga 100 kW, tetapi brosur tidak mencantumkan waktu pengisian, jadi tanyakan kepada sales.

Panduan perjalanan jauh ada di [EX5 untuk perjalanan jauh dan mudik](/artikel/geely-ex5-untuk-perjalanan-jauh-dan-mudik/). Detail pengisian ada di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/).

## Cadangan dan kebiasaan sehat

Jangan membiasakan baterai nyaris kosong. Sisakan cadangan agar Anda punya pilihan bila rute berubah. Banyak pengguna menetapkan batas pribadi untuk mulai mencari tempat mengisi.

Kebiasaan ini bersifat pribadi. Tentukan berdasarkan kenyamanan dan akses Anda ke titik pengisian. Pembahasan perawatan baterai ada di [umur baterai mobil listrik LFP](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

## Membandingkan dengan EX2

EX2 memiliki klaim 395 km (NEDC) dengan baterai 40,8 kWh. EX5 menawarkan klaim lebih panjang dan baterai lebih besar, cocok bagi yang sering bepergian jauh. Namun bagi pengguna kota, kapasitas EX2 sering sudah memadai.

Baca [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/) dan [jarak tempuh EX2](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/). Jangan membeli kapasitas besar untuk kebutuhan yang jarang muncul.

## Uji saat test drive

Minta rute yang menyerupai perjalanan Anda dan perhatikan penurunan persentase baterai. Meskipun singkat, ini memberi gambaran awal. Bandingkan dengan estimasi di layar 15,4 inci dan percayai kebiasaan setelah beberapa minggu.

Atur jadwal lewat halaman [kontak](/kontak/). Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Contoh membaca angka untuk tiga pola pemakaian

Pengguna kota dengan perjalanan pendek biasanya hanya memakai sebagian kecil dari klaim jarak per hari. Baginya, angka NEDC dan WLTP hampir tidak berpengaruh pada keputusan harian; yang lebih penting adalah kemudahan mengisi daya di rumah.

Pekerja komuter jarak sedang perlu memperhatikan angka WLTP sebagai acuan hati-hati, apalagi bila rutenya mencakup tol dan AC menyala sepanjang waktu. Mengisi dua atau tiga kali seminggu mungkin lebih realistis daripada menunggu baterai sangat rendah.

Pengguna yang sering ke luar kota harus menempatkan kecepatan tol, beban penumpang, dan cuaca sebagai variabel utama. Rencanakan etape lebih pendek dari klaim agar cadangan tetap aman. Ini bukan angka pasti; ini cara berpikir yang melindungi Anda dari kejutan.

## Kesalahan membaca angka jarak

Kesalahan pertama adalah menganggap NEDC sebagai janji. Kesalahan kedua adalah membandingkan angka dua mobil dari standar berbeda seolah setara. Kesalahan ketiga adalah menghabiskan baterai sampai nyaris kosong demi mengejar klaim.

Hindari ketiganya dengan selalu menyebut standar yang dipakai, membandingkan hanya angka dari standar yang sama, dan menyisakan cadangan. Sikap hati-hati ini membuat kepemilikan mobil listrik terasa tenang, bukan penuh kecemasan.

## Peran tekanan ban dan beban

Tekanan ban yang kurang meningkatkan hambatan gelinding dan memboroskan energi. Periksa tekanan ban secara berkala sesuai anjuran pabrikan. Beban tambahan, seperti rak atap atau bagasi penuh, juga menambah pemakaian. Rel atap pada EX5 berguna, tetapi lepaskan perlengkapan atap bila tidak diperlukan.

## Cara mencatat konsumsi setelah memiliki mobil

Setelah mobil Anda terima, catat persentase baterai dan odometer di awal dan akhir perjalanan rutin selama beberapa minggu. Hitung rata-rata persentase yang terpakai per kilometer. Dari situ Anda memperoleh angka yang paling relevan: milik Anda sendiri, bukan milik laboratorium.

## Pertanyaan yang sering diajukan

### Berapa jarak tempuh EX5?

NEDC 495 km (Pro) dan 490 km (Max); WLTP 430 km dan 425 km.

### Mana yang lebih realistis, NEDC atau WLTP?

WLTP umumnya lebih mendekati kondisi nyata, tetapi tetap klaim laboratorium.

### Apakah AC memengaruhi jarak?

Ya, AC memakai energi dari baterai yang sama.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Jarak EX5 diklaim 495 km NEDC dan 430 km WLTP pada Pro. Pakai angka itu sebagai pembanding, hitung kebutuhan harian Anda, dan sisakan cadangan.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
