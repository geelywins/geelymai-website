---
title: "Geely EX2: Panduan Mobil Listrik Kompak untuk Pemula"
description: "Panduan Geely EX2 untuk calon pembeli: baterai LFP 40,8 kWh, klaim 395 km NEDC, pengisian, ruang, varian Pro dan Max, serta pertanyaan yang perlu dijawab dulu."
date: 2026-10-14
category: "Model Geely"
tags: ["geely ex2", "mobil listrik kompak", "geely ex2 jakarta", "geely ex2 max", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Geely EX2 adalah mobil listrik kompak berkapasitas lima penumpang dengan baterai LFP 40,8 kWh dan klaim jarak 395 km (NEDC). Panduan ini ditujukan bagi Anda yang baru mempertimbangkan mobil listrik: apa yang ditawarkan EX2, apa yang perlu Anda siapkan, dan bagaimana menilai apakah mobil ini cocok untuk hidup Anda.

## Kenalan dulu dengan EX2

EX2 diposisikan sebagai mobil listrik kompak untuk pemakaian harian. Motornya 85 kW dengan torsi 150 Nm, dan perkiraan akselerasi 0-100 km/jam sekitar 11,5 detik. Karakternya lebih ke arah tenang dan mudah dikendalikan daripada sporty.

Ada dua varian, Pro dan Max. Keduanya berbagi dasar teknis yang sama, sedangkan Max menambah sejumlah kelengkapan. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/) dan informasi rinci di halaman [Geely EX2](/model/geely-ex2/).

## Apa arti kompak dalam keseharian

Mobil kompak lebih mudah dipakai di jalan sempit dan tempat parkir ramai. Itu keuntungan nyata di kota padat. Sebaliknya, ruang kabin dan bagasi terbatas dibanding SUV keluarga, sehingga perlu diuji dengan kebutuhan Anda.

Bagasi EX2 berkapasitas 375 liter dan bisa membesar hingga 1.320 liter saat jok belakang dilipat, ditambah frunk 70 liter di depan. Pembahasannya ada di [bagasi 375 liter dan frunk 70 liter](/artikel/bagasi-375-liter-dan-frunk-70-liter-geely-ex2-muat-apa-saja/).

## Baterai dan jarak

Baterai LFP 40,8 kWh menjadi sumber energi. Klaim jarak 395 km mengikuti standar NEDC, yang diukur di laboratorium. Di jalan nyata hasilnya akan berbeda tergantung kecepatan, AC, beban, dan gaya mengemudi. Cara membacanya dibahas di [jarak tempuh EX2: cara membaca angkanya](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/).

Untuk pengguna kota dengan jarak harian pendek, kapasitas ini umumnya memberi ruang bernapas. Untuk pengguna yang sering bepergian jauh, perencanaan pengisian menjadi kunci.

## Pengisian daya

Klaim pengisian AC 10-100% sekitar 6,5 jam, cocok untuk semalam di rumah. Pengisian cepat DC 30-80% diklaim sekitar 25 menit, berguna di perjalanan. Hasil nyata dapat berbeda dan tergantung peralatan serta kondisi baterai.

Hal yang paling menentukan kepuasan adalah tempat mengisi daya. Sebelum membeli, pastikan Anda punya akses yang realistis. Panduan ada di [cara mengisi daya EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/).

## Kabin dan teknologi

Layar tengah 14,6 inci dan panel instrumen 8,8 inci menjadi pusat informasi. Varian Max menambah ambient light 256 warna dan interior ivory. Layar besar memudahkan bagi yang menyukai antarmuka digital, tetapi pengemudi yang terbiasa tombol fisik perlu mencobanya terlebih dahulu.

Pembahasan kabin ada di [ambient light dan layar 14,6 inci](/artikel/ambient-light-256-warna-dan-layar-14-6-inci-geely-ex2-max/) serta [jok elektrik dan interior ivory](/artikel/jok-elektrik-6-arah-dan-interior-ivory-geely-ex2-max/).

## Keselamatan

EX2 dilengkapi 6 airbag. Varian Max menambahkan kamera 540 derajat dan ADAS Level 2. Fitur ini membantu, namun tidak menggantikan kewaspadaan pengemudi. Kami tidak mencantumkan rating keselamatan karena datanya belum tersedia.

Bacaan lanjutan ada di [keamanan EX2: 6 airbag dan fitur pelindung](/artikel/keamanan-geely-ex2-max-6-airbag-dan-fitur-pelindung/).

## Pro atau Max

Karena tenaga dan jarak sama, pilihan Pro atau Max sebaiknya didasarkan pada fitur yang akan benar-benar Anda pakai. Jika parkir sempit dan perjalanan tol sering, Max bermanfaat. Jika pemakaian sederhana, Pro mungkin cukup. Perbandingan lengkap ada di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

Untuk harga terkini, lihat [harga Geely EX2](/artikel/harga-geely-ex2-terbaru-pro-dan-max-otr-jakarta/) dan halaman [promo](/promo/).

## Siapa yang cocok memilih EX2

EX2 cocok bagi pengguna kota, pasangan muda, atau keluarga kecil dengan jarak harian wajar dan akses pengisian jelas. Ia juga menarik bagi mereka yang menginginkan mobil kedua yang irit biaya operasional.

Jika Anda sering membawa banyak penumpang dan barang, atau kerap menempuh perjalanan sangat jauh, pertimbangkan model yang lebih lega seperti [Geely EX5](/model/geely-ex5/). Perbandingannya ada di [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/).

## Hal yang belum kami miliki datanya

Beberapa informasi belum tersedia pada sumber resmi kami: dimensi, garansi, dan jadwal servis. Kami tidak menebaknya. Tanyakan kepada sales dan minta jawaban tertulis. Pembahasan terkait ada di [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/) serta [perawatan EX2 Max](/artikel/perawatan-geely-ex2-max-servis-berkala-dan-biaya/).

## Langkah berikutnya

Tulis kebutuhan Anda, cek akses pengisian, lalu jadwalkan test drive. Persiapan test drive dibahas di [checklist test drive Geely EX2 Max](/artikel/test-drive-geely-ex2-max-checklist-yang-perlu-dicek/). Hubungi kami lewat halaman [kontak](/kontak/) untuk mengatur jadwal.

Jika ini mobil listrik pertama Anda, baca juga [tips memilih mobil listrik pertama](/artikel/tips-memilih-mobil-listrik-pertama/) dan [istilah mobil listrik](/artikel/istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen/) agar tidak bingung dengan istilah teknis.

## Kesalahan yang sering dilakukan calon pembeli pertama

Kesalahan pertama adalah memutuskan hanya dari jarak klaim, tanpa menghitung kebiasaan sendiri. Kesalahan kedua adalah menunda memikirkan tempat mengisi daya sampai mobil sudah dipesan. Kesalahan ketiga adalah mengira mobil listrik tidak memerlukan perawatan sama sekali.

Kesalahan lain adalah membandingkan mobil listrik dengan mobil bensin hanya dari harga beli. Biaya energi, perawatan, dan pajak ikut menentukan. Susun tabel sederhana yang memuat semuanya, lalu bandingkan dengan jujur.

## Persiapan sebelum datang ke dealer

Tuliskan jarak harian, jumlah penumpang tetap, barang yang biasa dibawa, dan tempat parkir Anda. Foto area parkir dan stop kontak terdekat. Siapkan pertanyaan tentang garansi, servis, dan waktu pengiriman.

Dengan persiapan itu, kunjungan Anda menjadi jauh lebih produktif. Sales dapat memberi jawaban yang relevan, dan Anda pulang dengan informasi yang bisa dibandingkan, bukan sekadar kesan umum tentang mobil yang bagus.

## Mengenal biaya harian dibanding mobil bensin

Salah satu alasan orang melirik mobil listrik adalah biaya energi per kilometer yang umumnya lebih rendah. Besarnya bergantung tarif listrik, tempat mengisi, dan kebiasaan Anda. Karena itu, hitung dengan tarif listrik rumah Anda sendiri dan catatan konsumsi bahan bakar mobil sekarang.

Panduan langkah demi langkah ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Hitungan sendiri jauh lebih meyakinkan daripada klaim umum yang beredar.

## Pertanyaan yang sering diajukan

### Berapa jarak tempuh EX2?

Klaim 395 km (NEDC). Hasil nyata bergantung kondisi.

### Berapa lama mengisi daya?

Klaim AC 10-100% sekitar 6,5 jam dan DC 30-80% sekitar 25 menit.

### Apakah EX2 muat lima orang?

Kapasitasnya lima penumpang. Uji kenyamanan jok belakang saat test drive.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

EX2 adalah mobil listrik kompak yang tenang dan jelas datanya, cocok untuk pemakaian kota dengan akses pengisian yang pasti. Uji sendiri ruang dan kenyamanannya sebelum memutuskan.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
