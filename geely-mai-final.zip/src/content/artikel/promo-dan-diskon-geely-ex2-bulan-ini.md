---
title: "Promo Geely EX2 Oktober 2026: DP Rendah dan Balloon 0 Persen"
description: "Promo Geely EX2 per Oktober 2026: uang muka kisaran Rp 40 jutaan, angsuran ringan, balloon payment bunga 0% skema 50:50. Pahami cara kerja dan risikonya."
date: 2026-10-14
category: "Harga & Promo"
tags: ["promo geely ex2", "diskon geely ex2", "dp geely ex2", "balloon payment mobil listrik", "geely ex2 jakarta", "harga mobil listrik geely", "geely ev", "mobil listrik murah"]
draft: true
---

Promo Geely EX2 per Oktober 2026 berfokus pada cara bayar: uang muka kisaran Rp 40 jutaan, angsuran ringan, dan skema balloon payment dengan bunga 0 persen serta pembayaran 50:50. Artikel ini menjelaskan cara kerja skema itu, risiko yang perlu disiapkan, dan pertanyaan yang sebaiknya diajukan sebelum Anda setuju.

*Promo, syarat, dan periode dapat berubah. Data per Oktober 2026; minta konfirmasi tertulis dari Geely MAI sebelum memutuskan. Persetujuan pembiayaan tetap ditentukan perusahaan pembiayaan.*

## Ringkasan penawaran

| Penawaran | Isi singkat |
|---|---|
| Uang muka | Kisaran Rp 40 jutaan, mengikuti persetujuan pembiayaan |
| Angsuran | Dibuat ringan lewat skema khusus |
| Balloon payment | Sebagian nilai dibayar di akhir masa kredit |
| Bunga | 0 persen pada skema yang berlaku |
| Pembayaran | Skema 50:50 |

Sebagai acuan harga, EX2 Pro Rp 239.900.000 dan EX2 Max Rp 269.900.000 OTR Jakarta per Oktober 2026. Lihat [harga Geely EX2](/artikel/harga-geely-ex2-terbaru-pro-dan-max-otr-jakarta/). Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Cara kerja balloon payment

Pada kredit biasa, seluruh sisa harga dicicil sampai lunas. Pada balloon payment, sebagian nilai ditahan dan dibayar di akhir masa kredit, sehingga angsuran bulanan lebih kecil. Pada skema 50:50 yang disebut dalam promo, gambarannya adalah separuh nilai dicicil dan separuh menjadi pembayaran akhir.

Bunga 0 persen berarti tidak ada tambahan bunga pada skema tersebut. Namun besar uang muka, tenor, dan angsuran berbeda untuk tiap varian. Karena itu kami memberi simulasi tertulis sesuai pilihan Anda, bukan angka umum.

## Bagian yang paling sering terlupa: pembayaran akhir

Pembayaran akhir wajib dipenuhi. Pilihan yang umumnya dipertimbangkan adalah melunasi dari dana yang sudah disiapkan, menukar tambah ke mobil lain, atau opsi lain sesuai ketentuan saat itu. Karena pilihan yang tersedia bergantung aturan pembiayaan, tanyakan sejak awal dan minta tertulis.

Bila Anda berencana menukar tambah, pelajari alurnya di [tukar tambah ke mobil listrik](/lp/tukar-tambah-ke-mobil-listrik/). Skema ini cocok bagi yang ingin angsuran ringan sekarang dan sudah memiliki rencana jelas untuk bagian akhir.

## Angsuran ringan bukan berarti mobil lebih murah

Angsuran kecil terasa nyaman, tetapi total kewajiban tetap harus dihitung. Dengan balloon payment, sebagian beban dipindahkan ke akhir masa kredit. Bandingkan total pembayaran, bukan hanya angsuran bulanan.

Mintalah simulasi untuk skema biasa sebagai pembanding. Dengan dua simulasi berdampingan, Anda bisa memilih berdasarkan angka, bukan hanya kesan. Panduan hitungan dasar ada di [simulasi cicilan EX2 Max](/artikel/simulasi-cicilan-geely-ex2-max-dp-dan-tenor/).

## Soal diskon dan potongan tunai

Banyak orang mencari diskon tunai untuk EX2. Potongan berbeda tiap periode dan varian, dan kami tidak menuliskan angka yang tidak pasti. Tanyakan potongan terbaru lewat halaman [kontak](/kontak/) dan pastikan tertuang dalam penawaran tertulis.

Waspadai klaim potongan besar yang tidak bisa dibuktikan tertulis. Penawaran yang sah selalu dapat dituangkan ke dalam dokumen bertanggal dengan syarat yang jelas.

## Pertanyaan yang perlu diajukan sebelum setuju

- Berapa nilai pembayaran akhir dalam rupiah dan kapan jatuh temponya?
- Berapa tenor dan angsuran untuk varian yang saya pilih?
- Apakah bunga 0 persen berlaku selama seluruh masa kredit?
- Biaya lain apa saja: administrasi, asuransi, atau lainnya?
- Apa pilihan saya di akhir kredit dan apa syaratnya?
- Apakah pelunasan lebih cepat diperbolehkan?

Jawaban tertulis membuat perbandingan dengan penawaran lain menjadi adil dan melindungi kedua pihak.

## Siapa yang cocok dan siapa yang perlu berhati-hati

Skema ini lebih cocok bagi Anda yang berpenghasilan stabil, ingin angsuran ringan, dan sudah punya rencana dana akhir. Kurang cocok bagi yang pendapatannya belum menentu atau belum memikirkan pembayaran akhir sama sekali.

Persetujuan kredit ditentukan perusahaan pembiayaan, bukan dealer. Siapkan dokumen lebih awal; daftarnya ada di [syarat dan dokumen kredit mobil listrik](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/).

## Langkah mengambil promo

1. Pilih varian; bantuan ada di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).
2. Hubungi kami dan minta simulasi untuk skema uang muka rendah dan balloon.
3. Siapkan dokumen pengajuan.
4. Ikuti alur sampai serah terima di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/).

Penawaran umum lain ada di halaman [promo](/promo/). Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

## Membandingkan dua skema secara adil

Susun tabel dengan kolom: uang muka, tenor, angsuran, pembayaran akhir, total yang dibayar, dan biaya lain. Isi untuk skema balloon dan skema biasa. Hitung total dengan menjumlahkan semua pembayaran sepanjang waktu, termasuk pembayaran akhir.

Setelah itu, tanyakan pada diri sendiri: mana yang membuat saya lebih tenang? Jawaban yang jujur sering bukan yang termurah secara total, melainkan yang paling sesuai dengan arus kas Anda.

## Contoh pertanyaan untuk pasangan atau keluarga

Sebelum menyetujui skema balloon, diskusikan bersama pasangan: apakah penghasilan kita stabil dalam beberapa tahun ke depan, berapa dana yang bisa kita sisihkan untuk pembayaran akhir, dan apakah kita berencana mengganti mobil pada akhir masa kredit. Jawaban jujur atas pertanyaan ini menentukan apakah skema ringan sekarang benar-benar ringan nanti.

Catat juga kewajiban lain yang sedang berjalan, seperti cicilan rumah atau biaya pendidikan. Mobil sebaiknya melengkapi hidup Anda, bukan menekan arus kas hingga tidak ada ruang untuk kejutan.

## Memeriksa keaslian penawaran

Pastikan penawaran yang Anda terima berasal dari kanal resmi dealer, bukan dari pesan berantai. Periksa bahwa dokumen mencantumkan tanggal, varian, nilai, dan syarat. Penawaran yang hanya berupa tangkapan layar tanpa rincian sebaiknya dikonfirmasi ulang lewat halaman [kontak](/kontak/).

## Pertanyaan yang sering diajukan

### Berapa uang muka promo EX2?

Kisaran Rp 40 jutaan per Oktober 2026, mengikuti persetujuan pembiayaan.

### Apakah bunga benar-benar 0 persen?

Pada skema balloon yang berlaku menurut data kami. Konfirmasi tertulis syaratnya.

### Apa itu skema 50:50?

Gambarannya separuh nilai dicicil dan separuh dibayar di akhir. Minta simulasi tertulis.

### Apakah promo bisa berubah?

Ya. Konfirmasi sebelum memutuskan.

## Kesimpulan

Promo EX2 per Oktober 2026 menawarkan uang muka rendah dan angsuran ringan lewat balloon payment, dengan konsekuensi pembayaran akhir yang harus disiapkan. Bandingkan total, bukan hanya cicilan, dan minta semuanya tertulis.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk simulasi sesuai kebutuhan Anda.
