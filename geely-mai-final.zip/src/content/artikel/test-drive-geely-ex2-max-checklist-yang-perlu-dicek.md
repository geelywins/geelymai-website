---
title: "Test Drive Geely EX2 Max: Daftar Cek Sebelum dan Saat Mencoba"
description: "Test drive Geely EX2 Max: daftar cek persiapan, pertanyaan untuk sales, rute yang disarankan, dan cara mencatat kesan agar keputusan Anda tidak keliru."
date: 2026-10-14
category: "Test Drive"
tags: ["test drive geely ex2", "checklist test drive", "geely ex2 max", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik kompak"]
draft: false
---

Test drive Geely EX2 Max adalah kesempatan terbaik untuk membuktikan hal yang tidak bisa dibaca dari brosur. Artikel ini memberi daftar cek lengkap: persiapan sebelum datang, hal yang diperiksa saat duduk di mobil, rute yang sebaiknya diminta, dan cara mencatat kesan supaya keputusan Anda tidak dipengaruhi suasana.

## Mengapa daftar cek penting

Test drive biasanya singkat dan penuh distraksi. Anda gugup, sales menjelaskan banyak hal, dan waktu terbatas. Tanpa daftar, mudah sekali pulang tanpa tahu bagian mana yang belum dicoba. Daftar sederhana membuat tiap menit terpakai untuk hal yang benar-benar memengaruhi keputusan.

Anggap sesi ini seperti wawancara dua arah: Anda menilai mobil, dan mobil menilai kecocokannya dengan hidup Anda. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Persiapan sebelum datang

Hubungi dealer lebih dulu dan pastikan unit varian Max tersedia untuk dicoba. Bawa SIM yang masih berlaku, karena umumnya diminta. Ajak orang yang akan sering memakai mobil, dan bila ada anak, bawa kursi anak.

Tuliskan lima prioritas Anda, misalnya parkir mudah, kabin nyaman, ruang bagasi, biaya, dan teknologi. Dengan begitu Anda menilai berdasarkan kebutuhan, bukan sekadar kesan umum. Atur jadwal lewat halaman [kontak](/kontak/).

## Memeriksa mobil saat diam

Sebelum menyalakan mobil, periksa kabin. Duduklah di kursi pengemudi dan atur jok serta setir. Coba jangkau semua tombol penting. Perhatikan layar 14,6 inci dan panel instrumen 8,8 inci: apakah informasi mudah dibaca dan menu mudah dicari?

Duduk juga di jok belakang, lalu minta orang lain duduk di depan sesuai ukuran tubuhnya. Periksa ruang kaki dan kepala. Buka bagasi 375 liter dan frunk 70 liter, lalu bawa barang yang biasa Anda angkut, misalnya stroller atau koper kecil.

## Di jalan: tenaga dan kendali

Rasakan akselerasi dari berhenti dan saat menyalip. Dengan motor 85 kW dan torsi 150 Nm, karakternya halus; nilai apakah itu sesuai dengan selera Anda. Coba pengereman, termasuk sensasi rem regeneratif saat melepas gas.

Perhatikan kendali setir, kestabilan di kecepatan lebih tinggi, dan respons saat berbelok. Bila Anda terbiasa dengan mobil bensin, ingatlah bahwa mobil listrik hampir senyap, jadi dengarkan suara ban dan angin dengan teliti.

## Di jalan: kenyamanan dan kebisingan

Minta rute yang mencakup jalan halus, jalan berlubang, dan polisi tidur. Duduk bergantian di depan dan belakang agar tahu perbedaan kenyamanannya. Perhatikan suara dari roda dan angin, serta seberapa tenang kabin.

Nyalakan AC dan rasakan seberapa cepat kabin mendingin. Kami tidak memiliki data uji pendinginan, jadi pengalaman Anda sendiri adalah satu-satunya bukti. Pembahasan kenyamanan roda ada di [velg 16 inci dan kenyamanan](/artikel/velg-16-inci-dan-kenyamanan-berkendara-geely-ex2-max/).

## Menguji fitur Max

Coba kamera 540 derajat dengan memarkir mundur dan paralel. Tanyakan cara kerja ADAS Level 2 dan minta didemonstrasikan di jalan yang aman. Lihat bagaimana jok elektrik bergerak dan seberapa mudah mengaturnya.

Tanyakan cara kerja V2L dan aplikasi, lalu minta ditunjukkan langsung. Pembahasan fitur ada di [fitur ADAS EX2 Max](/artikel/fitur-adas-geely-ex2-max-apa-saja-dan-cara-kerjanya/) dan [kamera 540 derajat](/artikel/kamera-540-derajat-geely-ex2-max-membantu-parkir/).

## Pertanyaan yang perlu ditanyakan

Tanyakan data yang belum kami miliki: dimensi resmi, garansi, jadwal servis, dan titik pemasangan kursi anak. Tanyakan juga ketersediaan unit, waktu tunggu pengiriman, dan syarat pembayaran.

Minta semua jawaban penting dituliskan. Bila sales perlu mengonfirmasi, mintalah ia menghubungi Anda kembali. Pembahasan tentang garansi ada di [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

## Mencatat kesan secara jujur

Segera setelah test drive, tulis kesan Anda sebelum bicara apa pun dengan sales. Beri nilai 1 sampai 5 untuk tiap prioritas Anda, dan tulis satu hal yang paling Anda sukai serta satu yang paling mengganggu. Catatan ini melindungi Anda dari pengaruh tekanan atau euforia.

Jika memungkinkan, ulangi test drive di hari berbeda atau jam berbeda, misalnya saat ramai. Kesan di jalan lengang bisa sangat berbeda dengan jam sibuk.

## Setelah test drive

Jangan terburu-buru memesan. Bandingkan catatan dengan mobil lain yang Anda coba, bicarakan dengan keluarga, dan hitung total biaya. Minta penawaran tertulis dari halaman [promo](/promo/) bila siap melangkah.

Bila masih ragu, itu wajar. Lebih baik bertanya lagi daripada menyesal. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/), dan panduan umum ada di [cara test drive Geely](/artikel/cara-test-drive-geely/).

## Kesalahan yang sering terjadi saat test drive

Kesalahan pertama adalah membiarkan sales menentukan seluruh rute. Rute yang terlalu mulus tidak mewakili pemakaian Anda. Kesalahan kedua adalah tidak membawa pendamping, padahal pendapat kedua sangat membantu. Kesalahan ketiga adalah memutuskan karena kesan tiga menit pertama.

Kesalahan lain adalah tidak mencoba fitur yang menjadi alasan memilih Max. Bila Anda memilih Max demi kamera atau ADAS, pastikan Anda mencobanya secara langsung dan tidak hanya mendengar penjelasan. Menunda pertanyaan sampai setelah pemesanan juga merugikan, sebab saat itu posisi tawar Anda berkurang.

## Contoh urutan 30 menit yang efisien

Lima menit pertama untuk memeriksa kabin dan bagasi. Sepuluh menit berikutnya untuk berkendara di jalan biasa, merasakan tenaga, rem regeneratif, dan kenyamanan. Lima menit untuk jalan lebih cepat atau naik jalan layang bila memungkinkan.

Lima menit untuk mencoba parkir dengan kamera, dan lima menit terakhir untuk bertanya serta mencatat kesan. Bila waktu Anda lebih panjang, tambahkan sesi duduk di jok belakang selama rute. Sesi yang tertata membuat Anda pulang dengan informasi, bukan hanya kesan.

## Pertanyaan yang sering diajukan

### Apa yang harus dibawa saat test drive?

SIM yang berlaku, daftar prioritas, dan bila perlu kursi anak atau barang bawaan.

### Berapa lama test drive?

Tanyakan kepada dealer. Mintalah rute yang mencakup jalan yang biasa Anda lalui.

### Apakah boleh membawa keluarga?

Sebaiknya. Pendapat mereka penting untuk kenyamanan jok belakang.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Test drive yang baik dimulai dari persiapan: prioritas tertulis, pendamping yang tepat, dan rute yang relevan. Catat kesan dengan jujur sebelum mengambil keputusan.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mengatur jadwal.
