---
title: "Cek Mobil Baru Saat Serah Terima: Daftar PDI yang Perlu Dilakukan"
description: "Daftar cek serah terima mobil baru Geely: bodi, interior, kelistrikan, kabel pengisi, fitur, dan dokumen, plus cara mencatat temuan sebelum tanda tangan."
date: 2026-10-14
category: "Tips Membeli"
tags: ["cek mobil baru", "pdi mobil", "serah terima mobil", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah"]
draft: false
---

Serah terima adalah momen ketika mobil resmi berpindah ke tangan Anda, sehingga ketelitian di tahap ini melindungi Anda dari masalah yang baru terlihat kemudian. Artikel ini memberi daftar cek umum yang bisa dipakai pada mobil Geely baru, ditambah hal khusus mobil listrik, dan cara mencatat temuan sebelum menandatangani berita acara.

## Apa itu PDI dan serah terima

PDI atau pre-delivery inspection adalah pemeriksaan unit oleh dealer sebelum diserahkan. Serah terima adalah penyerahan mobil beserta dokumennya kepada pembeli. Keduanya berbeda: PDI dilakukan dealer, sedangkan pemeriksaan saat serah terima adalah kesempatan Anda memverifikasi.

Jangan menganggap PDI dealer menggantikan pemeriksaan Anda. Datanglah dengan waktu cukup dan daftar cek. Alur lengkap pembelian ada di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/).

## Persiapan sebelum hari serah terima

Pastikan dokumen pembelian lengkap dan pembayaran sudah sesuai. Pilih waktu siang hari saat cahaya baik agar cacat cat mudah terlihat. Ajak seseorang yang teliti. Siapkan senter ponsel dan catatan.

Tanyakan kepada sales urutan acara dan dokumen yang akan diserahkan. Bila Anda memasang pengisi di rumah, pastikan sudah siap agar mobil dapat langsung diisi.

## Pemeriksaan bodi dan cat

Kelilingi mobil perlahan. Periksa goresan, penyok, cat tidak rata, celah antarpanel yang tidak simetris, dan kondisi kaca. Lihat juga bagian bawah bemper dan kolong bila memungkinkan. Foto setiap temuan sebelum Anda berbicara dengan sales.

Periksa semua lampu, wiper, dan spion. Pada EX5, perhatikan gagang pintu tersembunyi dan lipatan spion otomatis. Cacat sekecil apa pun lebih mudah ditangani bila dicatat saat serah terima.

## Pemeriksaan interior

Periksa jok, plafon, karpet, dan panel dari noda atau lecet. Coba semua pengaturan jok. Pastikan sabuk pengaman terpasang baik, dan ISOFIX tersedia bila dijanjikan. Periksa laci, lampu kabin, dan soket yang ada.

Nyalakan AC dan rasakan pendinginan. Perhatikan bau yang tidak biasa atau bunyi aneh dari panel. Interior baru seharusnya bersih dan tanpa cacat.

## Layar, fitur, dan konektivitas

Nyalakan layar dan jelajahi menu. Sambungkan ponsel Anda lewat Bluetooth dan uji panggilan serta musik. Coba kamera, sensor parkir, dan fitur yang Anda pilih varian karenanya. Minta demonstrasi fitur yang belum Anda pahami.

Catat bahasa dan pengaturan awal. Tanyakan cara memperbarui perangkat lunak bila ada. Pembahasan konektivitas EX5 ada di [aplikasi dan konektivitas EX5](/artikel/aplikasi-dan-konektivitas-geely-ex5-ota-navigasi-dan-flyme/).

## Khusus mobil listrik: baterai dan pengisian

Periksa persentase baterai awal dan tanyakan berapa seharusnya. Pastikan kabel pengisi yang dijanjikan ada dan dalam kondisi baik, lalu uji sambungan bila memungkinkan. Tanyakan lokasi dan cara membuka port pengisian.

Minta dealer menjelaskan cara mengisi, membuka bagasi depan atau belakang, dan fungsi darurat. Tanyakan juga perlengkapan lain yang termasuk, seperti adaptor. Panduan ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/).

## Ban, rem, dan perlengkapan darurat

Periksa kondisi ban dan tekanan, serta kelengkapan perlengkapan darurat seperti segitiga pengaman atau kit penambal bila disebut. Kami tidak memiliki daftar resmi perlengkapan, jadi tanyakan kepada sales dan minta tertulis.

Coba rem parkir dan fungsi tahan otomatis bila ada. Jalan pelan di area sekitar untuk merasakan rem dan setir. Bila terasa janggal, laporkan sebelum meninggalkan dealer.

## Dokumen yang harus diterima

Pastikan Anda menerima buku manual, buku servis dan garansi, faktur, serta dokumen lain yang dijanjikan. Periksa nama, nomor rangka, dan data kendaraan pada dokumen sama dengan unit. Minta salinan bila hanya ditunjukkan.

Tanyakan jadwal servis pertama dan nomor layanan darurat. Foto dokumen penting dan simpan di tempat aman. Pembahasan garansi ada di [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

## Mencatat temuan dengan benar

Tulis setiap temuan pada berita acara serah terima atau lembar tertulis lain, lengkap dengan foto dan tanggal. Jangan menandatangani berita acara bersih bila ada temuan yang belum dibereskan. Minta dealer menjadwalkan perbaikan secara tertulis.

Bersikaplah sopan tetapi tegas. Dealer yang baik akan menerima catatan Anda dan menindaklanjutinya. Catatan tertulis adalah dasar bila terjadi perselisihan kemudian.

## Setelah meninggalkan dealer

Dalam beberapa hari pertama, perhatikan hal-hal kecil: bunyi, bau, respons fitur, dan perilaku pengisian. Catat dan laporkan segera bila ada kejanggalan. Jangan menunggu hingga servis pertama.

Jadwalkan servis pertama sesuai ketentuan dan simpan semua bukti. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/) dan [Geely EX5](/model/geely-ex5/). Untuk pertanyaan, hubungi kami lewat halaman [kontak](/kontak/).

## Mengatur waktu dan suasana pemeriksaan

Jangan memeriksa mobil dengan terburu-buru. Mintalah waktu yang cukup, idealnya di tempat dengan cahaya terang, sebab goresan halus dan cacat cat sering tidak terlihat di tempat gelap atau saat hujan. Bila memungkinkan, jadwalkan serah terima pada pagi atau siang hari.

Ajak satu orang yang Anda percaya sebagai pasangan memeriksa. Dua pasang mata lebih teliti, dan satu orang dapat mencatat sementara yang lain memeriksa. Tenangkan diri: antusiasme menerima mobil baru sering membuat orang melewatkan hal kecil yang kelak mengganggu.

## Contoh urutan pemeriksaan yang rapi

Agar tidak ada yang terlewat, ikuti urutan tetap. Mulailah dari luar mengelilingi mobil searah jarum jam, lalu masuk ke kabin, nyalakan sistem, periksa bagian depan dan bagasi, dan terakhir tinjau dokumen. Urutan yang sama membuat Anda tidak mengulang atau melompati bagian.

Beri tanda pada daftar setiap bagian yang sudah diperiksa. Bila menemukan sesuatu, foto saat itu juga dan tulis lokasi serta waktunya. Kebiasaan sederhana ini membuat laporan Anda jelas dan sulit disangkal, sehingga proses perbaikan berjalan lebih cepat.

## Pertanyaan yang sering diajukan

### Berapa lama serah terima?

Tanyakan kepada dealer. Sisihkan waktu cukup untuk memeriksa dengan teliti.

### Bolehkah menolak unit yang cacat?

Catat temuan tertulis dan minta penyelesaian. Tanyakan kebijakan dealer.

### Apa dokumen yang harus diterima?

Manual, buku servis dan garansi, faktur, dan dokumen lain yang dijanjikan.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Serah terima yang baik adalah serah terima yang teliti: periksa bodi, interior, fitur, pengisian, dan dokumen, lalu catat semua temuan secara tertulis sebelum menandatangani.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mengatur serah terima.
