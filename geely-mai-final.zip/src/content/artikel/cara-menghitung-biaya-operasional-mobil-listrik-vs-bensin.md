---
title: "Cara Menghitung Biaya Operasional Mobil Listrik vs Bensin"
description: "Langkah menghitung biaya per kilometer mobil listrik dan bensin dengan tarif dan catatan Anda sendiri, termasuk biaya tersembunyi yang sering terlewat."
date: 2026-10-14
category: "Kredit & Biaya"
tags: ["biaya operasional mobil listrik", "biaya per km mobil listrik", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah", "hitung biaya mobil"]
draft: false
---

Menghitung biaya operasional mobil listrik dan mobil bensin tidak memerlukan rumus rumit, tetapi memerlukan data dari kebiasaan Anda sendiri. Artikel ini memberi langkah demi langkah yang bisa Anda isi dengan tarif listrik rumah, harga bensin yang Anda bayar, dan catatan jarak Anda. Kami sengaja tidak menuliskan angka rupiah karena harga energi berubah dan situasi tiap orang berbeda.

## Mengapa hitung sendiri

Angka rata-rata yang beredar jarang cocok dengan kondisi Anda. Tarif listrik berbeda tiap golongan, harga bensin berubah, dan jarak harian tiap orang tidak sama. Perhitungan dari data sendiri lebih dapat dipercaya dan lebih mudah dipertanggungjawabkan kepada keluarga.

Kami hanya menyediakan kerangkanya. Gambaran umum ada di [mobil listrik Jakarta](/lp/mobil-listrik-jakarta/).

## Langkah 1: catat jarak Anda

Catat jarak yang Anda tempuh per bulan, dari odometer atau aplikasi peta. Gunakan rata-rata beberapa bulan agar tidak terpengaruh bulan yang tak biasa. Jarak per bulan adalah dasar semua hitungan lain.

Pisahkan jarak kota dan jarak luar kota bila pemakaiannya berbeda jauh, sebab konsumsi energi keduanya bisa berbeda.

## Langkah 2: hitung biaya per kilometer mobil bensin

Ambil data pengisian bensin: berapa liter dan berapa rupiah yang Anda bayar dalam sebulan, lalu bagi dengan jarak sebulan. Hasilnya adalah biaya bensin per kilometer dan konsumsi liter per kilometer.

Gunakan data mobil Anda yang sebenarnya, bukan klaim pabrikan. Konsumsi nyata di Jakarta biasanya berbeda dari angka brosur karena kemacetan dan AC.

## Langkah 3: hitung biaya per kilometer mobil listrik

Untuk mobil listrik, Anda butuh dua angka: energi yang dipakai per kilometer dan tarif listrik. Energi per kilometer dapat dicatat setelah beberapa minggu memakai mobil, dari persentase baterai yang berkurang dikalikan kapasitas baterai lalu dibagi jarak.

Contoh kapasitas: EX2 40,8 kWh dan EX5 60,22 kWh. Kalikan energi per kilometer dengan tarif listrik per kWh yang Anda bayar. Sebelum memiliki mobil, minta estimasi dari sales sebagai awal, lalu perbarui dengan data nyata. Baca [biaya per km EX2 Max vs mobil bensin](/artikel/biaya-per-km-geely-ex2-max-vs-mobil-bensin/).

## Langkah 4: perhitungkan kehilangan saat mengisi

Tidak semua energi dari stopkontak masuk ke baterai, karena ada kehilangan saat konversi. Karena itu energi yang Anda bayar biasanya sedikit lebih besar daripada yang tersimpan. Kami tidak memiliki angka kehilangan resmi, sehingga sisihkan margin kecil dalam hitungan.

Perbedaan antara pengisian AC rumah dan DC di stasiun juga memengaruhi biaya, sebab tarif stasiun umumnya berbeda dari tarif rumah. Masukkan proporsi pengisian Anda.

## Langkah 5: tambahkan biaya perawatan

Mobil listrik tidak memiliki oli mesin, tetapi tetap ada biaya rem, ban, filter, dan pemeriksaan. Tanyakan jadwal dan estimasi biaya servis kepada sales. Kami belum memiliki angka resmi, jadi isi setelah Anda mendapatkannya.

Bandingkan dengan biaya perawatan mobil bensin Anda selama setahun terakhir. Pembahasan ada di [perawatan mobil listrik: apa yang berbeda dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/).

## Langkah 6: pajak, asuransi, dan pengisi daya

Masukkan pajak tahunan, premi asuransi, dan biaya pemasangan pengisi di rumah. Aturan pajak dapat berubah, jadi cek aturan terbaru. Premi asuransi bergantung nilai kendaraan dan cakupan. Biaya pengisi berbeda tiap instalasi.

Panduan ada di [pajak mobil listrik EX2](/artikel/pajak-dan-insentif-mobil-listrik-untuk-geely-ex2-max/), [asuransi mobil listrik](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/), dan [pasang charger mobil listrik di rumah](/artikel/pasang-charger-mobil-listrik-di-rumah-daya-pln-dan-instalasi/).

## Langkah 7: cicilan dan biaya modal

Jika membeli kredit, masukkan angsuran bulanan dan uang muka. Pertimbangkan juga biaya modal: uang muka yang Anda keluarkan tidak bisa dipakai untuk hal lain. Pahami kredit di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

Biaya cicilan sering lebih besar daripada biaya energi, sehingga membandingkan hanya biaya energi bisa menyesatkan. Lihat gambaran total.

## Membuat tabel perbandingan

Buat tabel dengan baris: energi, perawatan, pajak, asuransi, cicilan, dan lain-lain, serta dua kolom: mobil bensin dan mobil listrik. Isi dengan data Anda. Jumlahkan per bulan dan per tahun.

Setelah itu, bagi total tahunan dengan jarak tahunan untuk mendapat biaya per kilometer keseluruhan. Angka ini lebih jujur daripada biaya energi saja.

## Biaya yang sering terlewat

Beberapa biaya sering terlupa: ban pengganti, biaya parkir dengan pengisi, tarif stasiun umum, biaya kabel atau adaptor tambahan, dan penurunan nilai jual. Masukkan sebisa mungkin, atau tandai sebagai risiko yang belum terukur.

Pembahasan nilai jual ada di [nilai jual kembali mobil listrik](/artikel/nilai-jual-kembali-mobil-listrik-mitos-dan-faktanya/). Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

## Menjaga hitungan tetap jujur

Hindari hanya memasukkan angka yang menguntungkan pilihan yang sudah Anda sukai. Mintalah pasangan atau teman memeriksa asumsi Anda. Perbarui hitungan setelah memiliki data nyata, dan terima bila hasilnya tidak seindah dugaan.

Hasil yang jujur membantu Anda mengatur anggaran dan menghindari kejutan. Atur konsultasi lewat halaman [kontak](/kontak/) bila ingin membahas.

## Contoh struktur tabel yang bisa Anda salin

Buat kolom: komponen biaya, mobil bensin (per bulan), mobil listrik (per bulan), dan catatan sumber angka. Baris yang disarankan: energi, perawatan, pajak, asuransi, cicilan, biaya pengisi, dan parkir. Isi hanya dengan angka yang punya sumber, dan beri tanda tanya pada yang masih perkiraan.

Dengan tabel seperti itu, Anda dapat melihat dengan jelas komponen mana yang paling menentukan. Sering kali, cicilan dan asuransi jauh lebih besar daripada selisih energi, sehingga fokus perbandingan sebaiknya pada total, bukan satu komponen.

## Kapan hitungan perlu diperbarui

Perbarui tabel setiap kali tarif listrik, harga bensin, atau kebiasaan Anda berubah, misalnya saat pindah rumah atau kantor. Dengan begitu hitungan Anda tetap mencerminkan kenyataan.

## Pertanyaan yang sering diajukan

### Apakah mobil listrik selalu lebih murah per kilometer?

Tidak selalu. Tergantung tarif listrik, tempat mengisi, dan kebiasaan Anda.

### Apakah pengisian di stasiun umum lebih mahal?

Umumnya tarifnya berbeda dari rumah. Cek tarif stasiun yang Anda pakai.

### Bagaimana mendapat angka konsumsi EX2?

Minta estimasi dari sales lalu catat sendiri setelah memiliki mobil.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Biaya operasional terbaik dihitung dari data Anda sendiri: jarak, tarif, konsumsi, dan biaya sampingan. Susun tabel jujur dan perbarui setelah memiliki data nyata.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
