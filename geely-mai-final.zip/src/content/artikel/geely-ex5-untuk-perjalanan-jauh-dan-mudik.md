---
title: "Geely EX5 untuk Perjalanan Jauh dan Mudik: Rencana Etape"
description: "Geely EX5 untuk perjalanan jauh dan mudik: klaim 495 km NEDC dan 430 km WLTP, DC hingga 100 kW, cara membagi etape, cadangan baterai, dan persiapan keluarga."
date: 2026-10-14
category: "Model Geely"
tags: ["geely ex5 mudik", "perjalanan jauh geely ex5", "geely ex5", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Geely EX5 untuk perjalanan jauh dan mudik menawarkan baterai 60,22 kWh, klaim jarak 495 km NEDC (Pro) dan 430 km WLTP, serta pengisian DC hingga 100 kW. Brosur tidak mencantumkan waktu pengisian, jadi artikel ini fokus pada cara merencanakan etape, cadangan, dan kebiasaan keluarga agar perjalanan jauh terasa tenang.

## Mengapa EX5 sering dilirik untuk mudik

Keluarga yang mudik biasanya membawa banyak penumpang dan barang. Bagasi 461 liter yang membesar hingga 1.877 liter, kabin lega, dan baterai lebih besar daripada EX2 menjadikan EX5 kandidat wajar. Namun kecocokan sebenarnya bergantung pada rute dan kesiapan pengisian.

Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/). Informasi rinci ada di halaman [Geely EX5](/model/geely-ex5/).

## Membaca angka jarak untuk rute jauh

Angka NEDC 495 km dan WLTP 430 km (Pro) adalah klaim laboratorium. Untuk rute tol dengan kecepatan tinggi, beban penuh, dan AC menyala, hasil nyata umumnya lebih rendah daripada klaim. Kami tidak memiliki data uji jalan EX5, sehingga tidak menyebut angka perkiraan.

Pakai WLTP sebagai acuan hati-hati, lalu rencanakan etape lebih pendek dari klaim. Penjelasan ada di [jarak tempuh EX5](/artikel/jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km/) dan [NEDC vs WLTP](/artikel/nedc-vs-wltp-arti-jarak-tempuh-mobil-listrik/).

## Pengisian cepat DC di perjalanan

EX5 mendukung DC CCS2 hingga 100 kW. Itu batas atas mobil; kecepatan nyata bergantung kemampuan stasiun dan kondisi baterai. Karena brosur tidak mencantumkan waktu, tanyakan kepada sales perkiraan resmi untuk rentang yang Anda butuhkan.

Strategi umum adalah berhenti lebih sering untuk pengisian singkat, sekaligus waktu istirahat. Detail pengisian ada di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/).

## Membagi perjalanan menjadi etape

Tuliskan rute dari rumah ke tujuan, lalu bagi menjadi etape yang masing-masing berakhir di titik pengisian yang sudah dipilih. Etape sebaiknya jauh di bawah klaim jarak agar cadangan tetap aman.

Siapkan satu titik utama dan satu cadangan per etape, karena stasiun bisa penuh atau rusak saat musim mudik. Simpan rencana di ponsel dan perbarui sesuai kondisi di lapangan.

## Mencari stasiun pengisian

Kami tidak mencantumkan nama atau lokasi stasiun karena datanya berubah dan belum kami verifikasi. Gunakan aplikasi peta atau penyedia pengisian untuk melihat lokasi, jenis konektor, dan ketersediaan. Pastikan mendukung CCS2.

Untuk panduan umum, baca [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/). Periksa stasiun sebelum berangkat, bukan di tengah jalan.

## Berangkat dengan baterai terisi

Isi baterai di rumah hingga level yang dibutuhkan sebelum berangkat. Gunakan fitur jadwal pengisian yang disebut brosur agar pengisian selesai menjelang waktu keberangkatan. Pastikan kabel pengisi ada di mobil.

Periksa tekanan ban, wiper, lampu, dan peringatan di panel instrumen 10,2 inci. Perjalanan jauh menguji hal kecil yang biasanya terabaikan. Pembahasan perawatan ada di [perawatan EX5](/artikel/perawatan-geely-ex5-servis-berkala-dan-biaya/).

## Kenyamanan penumpang

Perjalanan jauh melelahkan, dan kenyamanan membantu. Jok depan berventilasi, AC otomatis dengan lubang belakang, dan port USB-C di belakang meringankan penumpang. Max menambah jok massage dan HUD. Bahas di [kenyamanan EX5](/artikel/fitur-kenyamanan-geely-ex5-jok-ventilasi-massage-dan-hud/).

Atur jeda berkala bagi anak dan orang tua. Bawa bekal, air, dan hiburan. Perjalanan yang tenang lebih penting daripada tiba paling cepat.

## Bantuan pengemudi di jalan tol

Varian Max membawa adaptive cruise control dan bantuan jalur yang membantu mengurangi beban di jalan tol. Namun kewaspadaan tetap wajib dan istirahat tidak boleh dilewatkan. Baca [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/).

Jangan memakai ADAS sebagai alasan mengemudi saat mengantuk. Berhentilah ketika lelah, apa pun fitur yang dimiliki mobil.

## Rencana cadangan

Siapkan rencana bila rute berubah karena macet atau penutupan jalan. Simpan nomor layanan darurat dealer dan tanyakan layanan derek. Bila persentase turun lebih cepat dari perkiraan, kurangi kecepatan dan pemakaian AC, lalu cari titik pengisian terdekat.

V2L dan V2V dapat berguna dalam keadaan tertentu, tetapi detail dayanya tidak ada di brosur. Baca [V2L dan V2V EX5](/artikel/v2l-dan-v2v-geely-ex5-listrik-mobil-untuk-perangkat-lain/) dan jangan mengandalkannya tanpa konfirmasi.

## Latihan sebelum mudik pertama

Cobalah perjalanan menengah terlebih dahulu, misalnya akhir pekan di luar kota dengan satu kali pengisian. Pengalaman ini mengajarkan ritme pengisian dan membuat mudik pertama terasa lebih percaya diri. Atur jadwal test drive lewat halaman [kontak](/kontak/) dan lihat promo di halaman [promo](/promo/).

## Contoh pembagian rute dalam sehari

Misalkan Anda berangkat pagi dan tiba sore. Bagi perjalanan menjadi tiga etape dengan dua perhentian pengisian yang sekaligus menjadi waktu makan dan salat. Etape pertama paling santai sebagai pemanasan, etape kedua pada tengah hari, dan etape ketiga menjelang sore dengan baterai cukup untuk mencapai tujuan beserta cadangan.

Angka etape harus Anda sesuaikan setelah melihat penurunan baterai pada etape pertama. Karena kami tidak memiliki data jalan nyata EX5, perlakukan rencana awal sebagai hipotesis yang diperbarui di jalan. Fleksibilitas ini jauh lebih aman daripada mengikuti jadwal kaku.

## Membawa anak dan orang tua

Perjalanan jauh dengan anak kecil atau orang tua memerlukan jeda lebih sering. Gunakan waktu pengisian untuk toilet, makan, dan meregangkan badan. Bawa perlengkapan yang mudah dijangkau, bukan terkubur di bagasi.

Pastikan semua penumpang memakai sabuk dan anak duduk di kursi anak yang sesuai. ISOFIX di jok belakang memudahkan pemasangan. Pembahasan keselamatan ada di [keamanan EX5](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/).

## Setelah tiba di tujuan

Tanyakan apakah tempat menginap atau rumah keluarga memiliki colokan yang aman. Jangan menyambung ke kabel panjang atau stopkontak yang tidak memadai. Bila tidak ada, cari titik pengisian terdekat sebelum perlu pulang, agar perjalanan balik tidak dimulai dengan kejutan.

## Pertanyaan yang sering diajukan

### Apakah EX5 cocok untuk mudik?

Bisa dengan perencanaan etape dan pengisian yang matang.

### Berapa lama mengisi di perjalanan?

Brosur tidak mencantumkan waktu. Tanyakan kepada sales.

### Berapa jarak tempuhnya?

Klaim NEDC 495 km (Pro) dan 490 km (Max); WLTP 430 km dan 425 km.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

EX5 menyediakan ruang dan jangkauan yang mendukung perjalanan jauh keluarga, tetapi keberhasilannya bergantung perencanaan etape dan cadangan. Siapkan rencana, uji sebelum mudik, dan utamakan istirahat.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
