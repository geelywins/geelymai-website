---
title: "Spesifikasi Geely EX5: Tabel Pro dan Max dengan Penjelasan"
description: "Spesifikasi Geely EX5 Pro dan Max dari brosur resmi: baterai 60,22 kWh, motor 160 kW, torsi 320 Nm, dimensi, bagasi, dan perbedaan kedua varian."
date: 2026-10-14
category: "Model Geely"
tags: ["spesifikasi geely ex5", "geely ex5 pro max", "geely ex5", "suv listrik geely", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Spesifikasi Geely EX5 pada artikel ini bersumber dari brosur resmi, yang sendiri menyatakan data dapat berubah tanpa pemberitahuan. Kami menyajikan angka kunci Pro dan Max dalam tabel, menjelaskan artinya dalam bahasa sehari-hari, dan menandai informasi yang tidak ada di brosur agar Anda tahu apa yang perlu ditanyakan.

## Ringkasan dalam satu tabel

| Aspek | Pro | Max |
|---|---|---|
| Baterai | LFP Short Blade 60,22 kWh | LFP Short Blade 60,22 kWh |
| Daya motor | 160 kW (218 PS) | 160 kW (218 PS) |
| Torsi | 320 Nm | 320 Nm |
| 0-100 km/jam | 6,9 detik | 7,1 detik |
| Jarak NEDC | 495 km | 490 km |
| Jarak WLTP | 430 km | 425 km |
| Bobot kosong | 1.715 kg | 1.765 kg |
| Penggerak | Roda depan | Roda depan |

Tabel ini bukan pengganti brosur. Untuk keputusan pembelian, minta lembar spesifikasi terbaru yang tertulis. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Dimensi dan ruang

Panjang EX5 tercatat 4.615 mm, lebar 1.901 mm, dan tinggi 1.670 mm, dengan jarak sumbu roda 2.750 mm. Ground clearance 173 mm saat kosong dan 145 mm saat bermuatan. Radius putar minimum 5,4 meter, lalu kapasitas lima penumpang.

Jarak sumbu roda yang panjang umumnya membantu ruang kabin. Namun kenyamanan sebenarnya hanya bisa dinilai dengan duduk langsung. Bagasi 461 liter saat kursi tegak dan 1.877 liter saat dilipat dibahas di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/).

## Tenaga dan penggerak

Motor sinkron magnet permanen menyalurkan tenaga ke roda depan. Daya 160 kW dan torsi 320 Nm memberi akselerasi cepat untuk SUV keluarga, dan kecepatan maksimum tercatat 175 km/jam. Tersedia tiga mode berkendara: ECO, NORMAL, dan SPORT.

Perbedaan 0-100 km/jam antara Pro dan Max, yaitu 6,9 dan 7,1 detik, sejalan dengan bobot Max yang lebih berat. Selisih ini kecil dalam pemakaian harian, jadi jangan menjadikannya alasan utama memilih varian.

## Baterai dan jarak

Baterai Short Blade berjenis LFP berkapasitas 60,22 kWh. Brosur mencantumkan dua siklus pengujian: NEDC 495 km (Pro) dan 490 km (Max), serta WLTP 430 km (Pro) dan 425 km (Max). Angka WLTP biasanya lebih konservatif daripada NEDC.

Kedua angka tetap klaim laboratorium, bukan hasil jalan. Penjelasan selisihnya ada di [NEDC vs WLTP](/artikel/nedc-vs-wltp-arti-jarak-tempuh-mobil-listrik/) dan [jarak tempuh EX5](/artikel/jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km/).

## Pengisian

EX5 mendukung pengisian AC Type-2 hingga 11 kW dan DC CCS2 hingga 100 kW. Brosur juga menyebut V2L, V2V, rem regeneratif, dan jadwal pengisian. Waktu pengisian tidak tercantum di brosur, sehingga kami tidak menuliskan menit atau jam.

Tanyakan kepada sales waktu pengisian pada daya yang akan Anda gunakan. Pembahasan ada di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/) dan [V2L dan V2V EX5](/artikel/v2l-dan-v2v-geely-ex5-listrik-mobil-untuk-perangkat-lain/).

## Suspensi, rem, dan velg

Suspensi depan MacPherson dan belakang multi-link. Rem depan cakram berventilasi dan belakang cakram. Velg alloy 18 inci dengan ban 225/55 R18. Konfigurasi ini memengaruhi kenyamanan dan kemantapan, dan hasil akhirnya hanya bisa dinilai lewat test drive.

Velg 18 inci memberi tampilan lebih tegas, namun bisa meneruskan lebih banyak guncangan dibanding velg lebih kecil. Rasakan di jalan yang biasa Anda lewati.

## Fitur interior dan hiburan

Layar sentuh HD 15,4 inci dan panel instrumen LCD 10,2 inci menjadi pusat informasi. Audio berupa 6 speaker pada Pro dan 14 speaker plus 2 speaker di headrest pengemudi pada Max. Tersedia wireless charger, USB-A depan, USB-C belakang, Bluetooth, navigasi, dan pembaruan nirkabel.

Pembahasan konektivitas ada di [aplikasi dan konektivitas EX5](/artikel/aplikasi-dan-konektivitas-geely-ex5-ota-navigasi-dan-flyme/).

## Keselamatan dan bantuan pengemudi

Seluruh varian dilengkapi ABS, ESC, TCS, kamera 360 derajat, sensor parkir belakang, TPMS, dan ISOFIX di jok belakang, di antara fitur lain. Varian Max menambah rangkaian bantuan pengemudi seperti adaptive cruise control dan peringatan titik buta.

Brosur tidak menyebutkan jumlah total airbag, sehingga kami tidak menulis angkanya. Baca [keamanan EX5](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/) dan [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/).

## Yang tidak ada di brosur

Beberapa hal tidak tercantum: jumlah total airbag, waktu pengisian, dan ketentuan garansi. Jangan menebaknya. Tanyakan kepada sales dan minta jawaban tertulis, lalu simpan.

Untuk perbedaan Pro dan Max secara praktis, baca [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/). Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Cara memakai tabel ini

Cetak atau simpan tabel, lalu tandai angka yang paling penting bagi Anda. Bandingkan dengan lembar spesifikasi resmi saat test drive. Bila ada selisih, tanyakan penyebabnya. Spesifikasi hanya alat bantu; penilaian akhir tetap datang dari pengalaman mencoba.

Atur jadwal lewat halaman [kontak](/kontak/), dan lihat penawaran terkini di halaman [promo](/promo/).

## Teknologi yang disebut brosur

Brosur menyebut beberapa nama teknologi, antara lain arsitektur GEA, penggerak listrik 11-in-1, sistem audio Flyme Sound, dan teknologi integrasi baterai CTB. Istilah-istilah ini adalah klaim pabrikan, dan brosur tidak menjelaskan manfaat terukurnya, sehingga kami tidak menafsirkannya lebih jauh.

Bila salah satu teknologi itu penting bagi keputusan Anda, minta penjelasan tertulis dari sales tentang apa yang dilakukannya dan bagaimana dampaknya bagi pemilik. Penjelasan yang konkret lebih berguna daripada singkatan yang terdengar canggih.

## Cara membaca selisih Pro dan Max di tabel

Pada tabel inti, baterai, motor, dan torsi identik antara Pro dan Max. Yang berbeda adalah bobot, sedikit akselerasi, dan klaim jarak. Selisih jarak 5 km pada NEDC dan WLTP kecil dan tidak akan terasa dalam pemakaian sehari-hari.

Karena itu, beda utama kedua varian ada pada kelengkapan, bukan pada kemampuan dasar mobil. Hal ini penting agar Anda tidak keliru membayar lebih untuk performa yang sebenarnya sama.

## Pertanyaan yang sering diajukan

### Berapa jarak tempuh EX5?

Klaim NEDC 495 km (Pro) dan 490 km (Max); WLTP 430 km dan 425 km.

### Berapa tenaga EX5?

160 kW (218 PS) dengan torsi 320 Nm.

### Berapa kapasitas bagasi?

461 liter dengan kursi tegak, hingga 1.877 liter saat dilipat.

### Berapa lama mengisi daya?

Brosur tidak mencantumkan waktu. Tanyakan kepada sales.

## Kesimpulan

EX5 menawarkan baterai 60,22 kWh, motor 160 kW dengan torsi 320 Nm, dan ruang yang lega. Perbedaan Pro dan Max lebih banyak pada kelengkapan. Gunakan tabel ini sebagai peta, lalu verifikasi lewat dokumen resmi dan test drive.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
