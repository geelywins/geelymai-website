---
title: "NEDC vs WLTP: Cara Membaca Jarak Tempuh Mobil Listrik"
description: "NEDC vs WLTP: arti dua standar uji jarak mobil listrik, mengapa angkanya beda, dan cara membandingkan EX2, EX5, dan Starray dengan adil."
date: 2026-10-14
category: "Panduan EV"
tags: ["nedc vs wltp", "jarak tempuh mobil listrik", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "panduan mobil listrik", "mobil listrik murah"]
draft: true
---

NEDC dan WLTP adalah dua standar pengujian yang dipakai pabrikan untuk menyatakan jarak tempuh mobil listrik. Keduanya berasal dari laboratorium, bukan dari jalan raya Jakarta. Artikel ini menjelaskan perbedaan keduanya, mengapa angkanya tak sama, dan cara memakai angka itu untuk membandingkan mobil dengan adil tanpa terjebak harapan berlebihan.

## Mengapa ada standar uji

Jika setiap pabrikan mengukur jarak dengan caranya sendiri, angkanya tidak bisa dibandingkan. Standar uji menetapkan prosedur yang sama: kecepatan mengikuti pola tertentu, suhu terkendali, dan tanpa lalu lintas nyata. Hasilnya adalah angka yang bisa dibandingkan antarmobil pada standar yang sama.

Namun tujuannya membandingkan, bukan memprediksi pengalaman harian Anda. Itulah inti pemahaman yang perlu dipegang sejak awal. Gambaran umum ada di [mobil listrik Jakarta](/lp/mobil-listrik-jakarta/).

## Apa itu NEDC

NEDC adalah prosedur lama yang menggunakan pola berkendara relatif ringan dengan akselerasi lembut dan kecepatan terbatas. Karena kondisi ini ringan, angka NEDC biasanya lebih tinggi dan sering terasa terlalu optimistis bagi pengguna.

Banyak data pabrikan yang kami pegang masih memakai NEDC, seperti klaim 395 km pada EX2 dan klaim Starray EM-i. Karena itu, penting mengetahui bahwa angka tersebut cenderung lebih longgar dibanding kondisi nyata.

## Apa itu WLTP

WLTP lebih baru dan dirancang lebih mewakili pemakaian sehari-hari, dengan pola yang lebih bervariasi dan kecepatan lebih tinggi. Karena itu angka WLTP umumnya lebih rendah daripada NEDC untuk mobil yang sama.

Brosur EX5 mencantumkan kedua angka: NEDC 495 km (Pro) dan 490 km (Max), serta WLTP 430 km dan 425 km. Selisih ini memperlihatkan bagaimana pilihan standar memengaruhi angka. Pembahasan EX5 ada di [jarak tempuh EX5](/artikel/jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km/).

## Mengapa hasil nyata tetap berbeda

Keduanya mengabaikan hal yang Anda alami: macet, AC menyala, hujan, tanjakan, penumpang, dan bagasi. Gaya mengemudi Anda juga unik. Karena itu, tidak ada standar yang mampu memprediksi jarak harian Anda secara tepat.

Perlakukan angka standar sebagai batas atas ideal. Pengalaman nyata sebagian besar akan lebih rendah, dan seberapa jauh bergantung pada kondisi Anda. Penjelasan untuk EX2 ada di [jarak tempuh EX2: cara membaca angkanya](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/).

## Cara membandingkan dengan adil

Bandingkan angka dari standar yang sama. NEDC dengan NEDC, WLTP dengan WLTP. Membandingkan NEDC satu mobil dengan WLTP mobil lain menyesatkan karena keduanya diukur dengan cara berbeda.

Bila hanya tersedia satu standar, catat standarnya dan jangan menyamakannya dengan standar lain. Kami tidak membandingkan angka dengan merek lain dalam artikel ini, hanya menjelaskan cara membaca.

## Cara membaca klaim pada Geely

EX2 mencantumkan klaim 395 km (NEDC). EX5 mencantumkan NEDC dan WLTP. Starray EM-i mencantumkan klaim NEDC, termasuk jarak listrik murni hingga 105 km dan jarak gabungan 1.000+ km. Semuanya adalah klaim pabrikan.

Untuk EX5, jika Anda menginginkan acuan yang lebih hati-hati, pakai WLTP. Untuk model lain, pakai NEDC hanya sebagai pembanding antarmodel dan sesuaikan dengan kebutuhan Anda sendiri.

## Menghitung kebutuhan Anda sendiri

Catat jarak harian selama dua minggu, temukan hari terjauh, lalu bandingkan dengan angka klaim yang dikurangi margin besar. Jika masih nyaman, kapasitas kemungkinan cukup. Jika tidak, pertimbangkan model berkapasitas lebih besar atau plug-in hybrid.

Lebih penting lagi, pastikan akses pengisian Anda. Jarak yang cukup tanpa tempat mengisi tetap menyulitkan. Panduan ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/).

## Faktor yang menggeser angka di jalan

Kecepatan tinggi, AC, beban, tanjakan, ban kurang angin, dan gaya mengemudi agresif mengurangi jarak. Sebaliknya, laju stabil, pengereman halus, dan ban sesuai tekanan membantu. Rem regeneratif juga mengembalikan sebagian energi saat melambat.

Anda tidak perlu menghafal angka pengaruh masing-masing. Cukup pahami arahnya, lalu amati pola pada mobil Anda. Setelah beberapa minggu, Anda akan memiliki angka sendiri yang jauh lebih berguna.

## Mencatat konsumsi pribadi

Catat persentase baterai dan odometer di awal dan akhir perjalanan rutin. Hitung rata-rata persentase per kilometer. Dari situ Anda mendapat angka paling relevan: milik Anda sendiri. Gunakan angka itu untuk merencanakan perjalanan jauh.

Perbarui catatan bila kebiasaan berubah, misalnya saat musim hujan atau saat membawa lebih banyak penumpang. Data pribadi mengalahkan angka laboratorium mana pun dalam hal relevansi.

## Hubungan dengan keputusan membeli

Jangan memilih mobil hanya dari angka jarak tertinggi. Timbang bersama kebutuhan ruang, akses pengisian, fitur, dan biaya. Angka yang lebih besar belum tentu berguna bila kebutuhan harian Anda jauh lebih kecil.

Panduan memilih ada di [tips memilih mobil listrik pertama](/artikel/tips-memilih-mobil-listrik-pertama/). Informasi model ada di halaman [Geely EX2](/model/geely-ex2/) dan [Geely EX5](/model/geely-ex5/).

## Kesalahan umum membaca angka jarak

Kesalahan pertama adalah menganggap angka sebagai jatah harian. Kesalahan kedua adalah membandingkan angka dari standar berbeda. Kesalahan ketiga adalah mengabaikan bahwa AC dan kecepatan tinggi sangat memengaruhi. Kesalahan keempat adalah menghabiskan baterai sampai hampir kosong demi mengejar klaim.

Hindari semuanya dengan kebiasaan sederhana: sebut standarnya, bandingkan yang setara, sisakan cadangan, dan ukur kebutuhan Anda sendiri. Sikap hati-hati ini membuat kepemilikan mobil listrik terasa tenang.

## Bagaimana dengan plug-in hybrid

Pada plug-in hybrid seperti Starray EM-i, angka NEDC dibagi menjadi jarak listrik murni dan jarak gabungan dengan bensin, serta beberapa angka konsumsi. Setiap angka mengukur hal yang berbeda, sehingga jangan mencampurnya. Pembahasannya ada di [konsumsi BBM Starray EM-i](/artikel/konsumsi-bbm-geely-starray-em-i-dan-jarak-tempuh-1000-km/).

## Pertanyaan yang sering diajukan

### Mana yang lebih akurat, NEDC atau WLTP?

WLTP umumnya lebih mendekati kondisi nyata, tetapi keduanya tetap laboratorium.

### Apakah angka NEDC bisa tercapai di jalan?

Biasanya sulit tercapai penuh. Anggap sebagai batas atas ideal.

### Bisakah membandingkan NEDC dengan WLTP?

Tidak adil. Bandingkan dari standar yang sama.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

NEDC dan WLTP adalah alat pembanding, bukan janji. Bandingkan dari standar yang sama, ukur kebutuhan harian Anda, dan buat catatan konsumsi pribadi setelah memiliki mobil.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
