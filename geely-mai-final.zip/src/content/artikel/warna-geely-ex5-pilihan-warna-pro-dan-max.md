---
title: "Warna Geely EX5: Pilihan Warna dan Cara Memilih yang Tepat"
description: "Pilihan warna Geely EX5: Ivory White hanya Max, Dark Blue untuk Pro dan Max, serta lima warna lain. Tips memilih warna untuk iklim Jakarta dan perawatannya."
date: 2026-10-14
category: "Model Geely"
tags: ["warna geely ex5", "pilihan warna ex5", "geely ex5", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Warna Geely EX5 menurut brosur resmi mencakup Ivory White yang hanya tersedia di Max, Dark Blue untuk Pro dan Max, serta Carbon Black, Snowy White, Frost Grey, Moonlight Silver, dan Turquoise Green. Ketersediaan lima warna terakhir per varian perlu ditanyakan. Artikel ini membantu Anda memilih warna dengan pertimbangan praktis.

## Daftar warna dari brosur

Brosur mencantumkan tujuh nama warna. Ivory White hanya pada Max. Dark Blue ada pada Pro dan Max. Lima lainnya, yaitu Carbon Black, Snowy White, Frost Grey, Moonlight Silver, dan Turquoise Green, tidak dirinci ketersediaannya per varian di sumber kami.

Karena itu, jangan berasumsi semua warna tersedia untuk varian pilihan Anda. Tanyakan kepada sales dan minta konfirmasi tertulis, termasuk perkiraan waktu tunggu untuk tiap warna. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Warna dan suhu kabin

Di kota panas seperti Jakarta, warna terang cenderung memantulkan lebih banyak panas daripada warna gelap, sehingga permukaan bodi dan kabin biasanya tidak secepat memanas. Namun kami tidak memiliki data pengukuran suhu untuk EX5, jadi pengaruh nyatanya perlu Anda alami sendiri.

Bila Anda sering parkir di tempat terbuka, pertimbangkan hal ini, terutama bila memiliki anak kecil. Pelindung kaca depan dan film kaca yang sesuai aturan dapat membantu apa pun warnanya.

## Warna dan kebersihan

Warna gelap menampakkan debu dan bekas air lebih jelas, sedangkan warna terang menyamarkannya tetapi menonjolkan noda lumpur dan getah. Warna perak dan abu sering dianggap paling toleran terhadap debu sehari-hari.

Jika Anda tidak ingin sering mencuci, pilih warna yang menyamarkan kotoran sesuai kondisi sekitar Anda. Preferensi ini sangat pribadi, jadi lihat langsung di dealer pada siang hari.

## Warna dan nilai jual

Sebagian orang memilih warna netral dengan harapan lebih mudah dijual kembali. Kami tidak memiliki data pasar untuk EX5 sehingga tidak membuat klaim. Pembahasan umum ada di [nilai jual kembali mobil listrik](/artikel/nilai-jual-kembali-mobil-listrik-mitos-dan-faktanya/).

Sebagai gantinya, pilihlah warna yang akan membuat Anda senang melihat mobil itu tiap hari. Kepuasan harian lebih pasti daripada spekulasi harga jual kelak.

## Ivory White khusus Max

Ivory White hanya tersedia di Max menurut brosur. Bila warna ini warna impian Anda, itu memengaruhi pilihan varian. Pastikan keputusan memilih Max didasarkan pada kebutuhan fitur juga, bukan hanya warna.

Lihat langsung warna ini di bawah cahaya alami. Warna di foto, layar, dan brosur bisa berbeda dari aslinya, dan gambar pada brosur umumnya hanya ilustrasi.

## Dark Blue untuk kedua varian

Dark Blue tersedia pada Pro dan Max, sehingga cocok bagi yang ingin warna berkarakter tanpa terikat varian. Warna gelap seperti ini tampak elegan, tetapi lebih menuntut perawatan dari goresan halus dan debu.

Pertimbangkan apakah Anda siap merawatnya. Cuci secara teratur dengan teknik yang benar dan pertimbangkan pelapis pelindung bila Anda ingin mempertahankan tampilan.

## Warna-warna berkarakter

Turquoise Green dan Frost Grey memberi kesan berbeda dari warna konvensional. Pilihan seperti ini cocok bagi yang ingin tampil beda, namun ketersediaan dan waktu tunggunya mungkin berbeda. Tanyakan sebelum jatuh hati pada satu warna.

Bila unit warna pilihan Anda tidak tersedia, tanyakan apakah ada pilihan kedua yang masih menyenangkan. Menyiapkan warna cadangan menghindarkan Anda dari kekecewaan atau keputusan tergesa.

## Cara memilih dengan tenang

Lihat unit contoh di siang hari dan sore hari. Foto dari berbagai sudut. Ajak keluarga memberi pendapat. Bayangkan warna itu di depan rumah, di tempat parkir kantor, dan di jalan raya. Setelah itu, bandingkan dengan pilihan kedua Anda.

Jangan memilih warna hanya karena tersedia cepat atau karena sedang ada promo. Warna akan menemani Anda bertahun-tahun. Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Perbedaan Pro dan Max dalam konteks warna

Warna hanyalah satu dari banyak faktor memilih varian. Baca [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/) untuk memahami selisih fitur secara utuh, lalu baru kaitkan dengan warna favorit Anda. Penawaran terkini ada di halaman [promo](/promo/), dan jadwal bisa diatur lewat halaman [kontak](/kontak/).

## Perawatan warna agar tetap awet

Apa pun warnanya, perawatan rutin menjaga tampilan. Cuci mobil dengan sampo khusus kendaraan, keringkan dengan kain mikrofiber, dan hindari menggosok debu kering karena dapat menimbulkan goresan halus. Cuci lebih cepat bila terkena kotoran burung atau getah.

Pertimbangkan pelapis pelindung bila Anda ingin menjaga kilap. Tanyakan kepada sales apakah pemasangan pelapis atau film memengaruhi garansi cat. Kami tidak memiliki data garansi cat untuk disebutkan, jadi tanyakan dan minta tertulis.

## Tautan dengan pilihan lain

Memilih warna juga berkaitan dengan hal lain seperti kabin dan roda. Lihat [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/) dan [fitur kenyamanan EX5](/artikel/fitur-kenyamanan-geely-ex5-jok-ventilasi-massage-dan-hud/) untuk melihat gambaran utuh kendaraan, bukan hanya cat luarnya.

Bila Anda membandingkan dengan model yang lebih kecil, baca juga [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/). Keputusan terbaik lahir dari gambaran menyeluruh, dan warna adalah sentuhan akhir yang menyenangkan.

## Warna dan keselamatan

Warna terang umumnya lebih mudah terlihat di jalan pada malam hari atau saat hujan dibanding warna gelap. Kami tidak memiliki data statistik soal ini, jadi anggap sebagai pertimbangan umum saja. Lampu LED, DRL, dan lampu belakang menyambung pada EX5 membantu terlihat apa pun warna Anda.

Apa pun pilihannya, jaga lampu tetap bersih dan berfungsi. Kebiasaan sederhana ini lebih menentukan keselamatan daripada pilihan cat. Warna menyenangkan hati, sementara kewaspadaan menjaga keselamatan.

## Pertanyaan yang sering diajukan

### Warna apa yang hanya ada di Max?

Menurut brosur, Ivory White hanya pada Max.

### Apakah semua warna tersedia untuk Pro?

Dark Blue tersedia untuk Pro dan Max; lainnya tanyakan kepada sales.

### Apakah warna memengaruhi harga?

Kami tidak memiliki datanya. Tanyakan kepada sales.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Pilihlah warna EX5 berdasarkan ketersediaan yang sudah dikonfirmasi, kondisi parkir, dan kesukaan Anda. Lihat langsung di bawah cahaya alami sebelum memutuskan.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk memeriksa ketersediaan warna.
