---
title: "Pajak Mobil Listrik Geely EX2: Cara Mengecek Aturan Terbaru"
description: "Pajak mobil listrik Geely EX2 dan insentif bergantung pada aturan terbaru. Panduan komponen biaya, cara memeriksa aturan, dan pertanyaan tertulis untuk dealer."
date: 2026-10-14
category: "Kredit & Biaya"
tags: ["pajak mobil listrik geely ex2", "insentif mobil listrik", "geely ex2", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah"]
draft: false
---

Pajak mobil listrik Geely EX2 dan insentif yang menyertainya mengikuti aturan pemerintah yang dapat berubah kapan saja, sehingga artikel ini sengaja tidak memuat angka atau persentase. Yang bisa kami berikan adalah kerangka: komponen biaya yang perlu dicek, cara memeriksa aturan terkini, dan pertanyaan yang sebaiknya Anda minta dijawab tertulis.

## Mengapa kami tidak menulis angka pajak

Tarif dan insentif kendaraan dapat berubah akibat kebijakan pusat maupun daerah. Angka yang benar hari ini bisa tidak berlaku bulan depan. Artikel yang dibaca berbulan-bulan akan menyesatkan bila memuat angka tertentu.

Karena itu, selalu minta rincian tertulis dari dealer pada tanggal Anda membeli, lalu cocokkan dengan sumber resmi pemerintah atau kantor pelayanan setempat. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Komponen biaya kepemilikan kendaraan

Biaya yang melekat pada kendaraan bermotor umumnya meliputi pajak tahunan, biaya pengurusan surat, pelat nomor, dan asuransi. Setiap komponen punya dasar perhitungan sendiri. Pada harga OTR, sebagian komponen sudah termasuk, tetapi apa yang termasuk dan tidak harus dikonfirmasi tertulis.

Pisahkan dalam catatan Anda antara biaya sekali bayar saat membeli dan biaya berulang tahunan. Pemisahan ini mempermudah penyusunan anggaran jangka panjang.

## Apa yang biasanya dibicarakan tentang insentif

Pembahasan insentif untuk kendaraan listrik biasanya menyangkut keringanan pajak atau bea tertentu. Apakah suatu model memenuhi syarat, untuk periode apa, dan apa yang harus dipenuhi pembeli, sepenuhnya mengikuti aturan terbaru. Jangan menganggap insentif otomatis tersedia hanya karena pernah mendengarnya.

Tanyakan kepada dealer apakah insentif yang berlaku sudah tercermin dalam harga yang ditawarkan atau harus diurus terpisah. Minta jawaban tertulis, lengkap dengan tanggal.

## Cara mengecek aturan terbaru

Mulailah dari sumber resmi: situs pemerintah daerah untuk pajak kendaraan dan layanan pajak setempat. Bandingkan dengan informasi dealer. Bila ada perbedaan, tanyakan penyebabnya dan minta dokumen pendukung.

Waspadai informasi dari media sosial atau pesan berantai yang tidak menyebutkan sumber. Aturan sering disederhanakan atau salah kutip. Sebelum memutuskan, pastikan Anda memegang rujukan yang dapat diverifikasi.

## Hubungan pajak dengan ganjil genap

Banyak calon pembeli mengaitkan mobil listrik dengan kebijakan lalu lintas di Jakarta. Ketentuan ini juga dapat berubah, dan kami tidak menuliskan rinciannya di sini. Pembahasan terpisah ada di [mobil listrik dan ganjil genap Jakarta](/artikel/mobil-listrik-dan-ganjil-genap-jakarta/).

Selalu periksa aturan terbaru dari pihak berwenang sebelum merencanakan pemakaian harian berdasarkan kebijakan tersebut.

## Pajak dan perhitungan cicilan

Jika Anda membeli lewat kredit, tanyakan apakah komponen pajak dan biaya pengurusan ikut dibiayai atau harus dibayar di awal. Hal ini memengaruhi uang muka sebenarnya yang perlu Anda siapkan.

Hitung simulasi dengan rincian lengkap, bukan hanya harga mobil. Panduan hitungan ada di [simulasi cicilan EX2 Max](/artikel/simulasi-cicilan-geely-ex2-max-dp-dan-tenor/) dan [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Pajak tahunan dan perencanaan anggaran

Pajak tahunan adalah biaya berulang yang sebaiknya masuk anggaran sejak awal. Tanyakan kepada dealer atau kantor layanan setempat bagaimana pajak untuk kendaraan listrik diperlakukan di daerah Anda, dan catat tanggal jatuh temponya.

Kami tidak memiliki angka resmi, sehingga kami tidak memberi perkiraan. Buat pos anggaran yang fleksibel dan perbarui setelah mendapat informasi pasti. Bandingkan dengan biaya mobil Anda sekarang untuk melihat gambaran selisih sebenarnya.

## Pertanyaan tertulis untuk dealer

Siapkan daftar: komponen apa saja yang sudah termasuk dalam harga OTR, apakah ada insentif yang berlaku untuk unit yang saya pesan, apa syaratnya, siapa yang mengurus, dan berapa lama prosesnya. Minta semuanya tertulis dan bertanggal.

Simpan dokumen itu bersama bukti pembayaran. Bila aturan berubah setelah pemesanan, dokumen tertulis menjadi dasar untuk menanyakan kebijakan yang berlaku bagi pesanan Anda.

## Hal yang perlu diwaspadai

Waspadai tawaran yang menjanjikan keringanan luar biasa tanpa dasar tertulis, atau permintaan pembayaran tambahan di luar rincian resmi. Jika ada biaya yang tidak jelas, tanyakan peruntukannya dan minta kuitansi.

Informasi model ada di halaman [Geely EX2](/model/geely-ex2/). Untuk penawaran terkini, lihat halaman [promo](/promo/).

## Membandingkan dengan mobil bensin

Saat membandingkan biaya mobil listrik dan mobil bensin, jangan hanya melihat harga dan bahan bakar. Masukkan pajak, perawatan, dan asuransi pada kedua sisi. Perlakuan pajak bisa berbeda, dan itu sebabnya perhitungan harus memakai angka resmi pada waktu pembelian.

Gunakan kerangka yang sama untuk kedua mobil: biaya awal, biaya tahunan, dan biaya per kilometer. Dengan begitu perbandingan Anda adil. Panduannya ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/).

## Bila aturan berubah setelah Anda memesan

Aturan bisa berubah di antara tanggal pemesanan dan serah terima. Tanyakan kepada dealer kebijakan mana yang berlaku bagi pesanan Anda dan minta jawaban tertulis. Jangan mengandalkan ucapan lisan, sebab perubahan aturan sering menimbulkan beda tafsir.

Sebagai bentuk kehati-hatian, sisihkan sedikit dana cadangan dalam anggaran Anda. Dana itu menjadi bantalan bila ada biaya tambahan yang baru diketahui kemudian, dan membuat Anda tidak terkejut saat pembayaran akhir.

## Dokumen yang perlu disimpan

Simpan faktur, kuitansi, surat tanda terima pengurusan, dan rincian biaya tertulis dari dealer. Dokumen ini berguna bila Anda perlu menelusuri biaya di kemudian hari, mengajukan klaim, atau menjual mobil. Foto setiap dokumen dan simpan salinan digitalnya di tempat aman.

Jika ada hal yang tidak Anda pahami pada rincian biaya, tanyakan sebelum membayar, bukan setelahnya. Penjelasan yang jelas di awal mencegah perselisihan dan membuat proses pembelian terasa lebih nyaman bagi kedua pihak.

## Pertanyaan yang sering diajukan

### Berapa pajak tahunan EX2?

Kami tidak mencantumkan angka. Cek aturan terbaru dan minta rincian tertulis.

### Apakah ada insentif?

Tergantung aturan yang berlaku saat Anda membeli. Tanyakan dan minta tertulis.

### Apakah pajak termasuk harga OTR?

Sebagian mungkin termasuk. Konfirmasikan tertulis apa saja yang termasuk.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Pajak dan insentif mobil listrik mengikuti aturan yang berubah, jadi pegang rincian tertulis dan sumber resmi, bukan angka yang beredar. Hitung biaya secara lengkap sebelum menyetujui.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk meminta rincian terbaru.
