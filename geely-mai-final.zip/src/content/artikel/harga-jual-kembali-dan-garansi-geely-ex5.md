---
title: "Garansi dan Nilai Jual Kembali Geely EX5: Pertanyaan Wajib"
description: "Garansi dan nilai jual kembali Geely EX5 belum kami cantumkan angkanya. Daftar pertanyaan, dokumen yang diminta, dan cara menjaga nilai mobil sejak awal."
date: 2026-10-14
category: "Model Geely"
tags: ["garansi geely ex5", "nilai jual kembali geely ex5", "geely ex5", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Garansi dan nilai jual kembali Geely EX5 adalah dua hal yang wajar Anda tanyakan sebelum membeli, tetapi kami tidak mencantumkan angka tahun, kilometer, atau persentase karena datanya belum ada pada sumber resmi kami. Artikel ini menyusun pertanyaan, dokumen, dan kebiasaan yang membantu melindungi nilai mobil Anda.

## Mengapa kami tidak menyebut angka

Garansi menyangkut hak dan kewajiban yang mengikat, sedangkan nilai jual dipengaruhi pasar yang berubah. Menyebut angka tanpa dasar dapat merugikan Anda. Karena itu kami hanya menuliskan yang dapat diverifikasi, dan mengarahkan Anda ke dokumen resmi.

Garansi yang valid adalah garansi yang tertulis pada dokumen yang Anda terima, bukan pada artikel atau ucapan siapa pun. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Garansi kendaraan dan garansi baterai

Pada kendaraan listrik, garansi biasanya dibagi menjadi garansi kendaraan umum dan garansi komponen utama seperti baterai dan motor. Masing-masing dapat punya jangka waktu, batas jarak, dan syarat berbeda.

Tanyakan keduanya terpisah. Jangan puas dengan jawaban "garansi lengkap" tanpa rincian. Minta tahu komponen apa yang dicakup, berapa lama, dan apa yang membatalkannya. Pembahasan serupa untuk EX2 ada di [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

## Pertanyaan yang diajukan ke sales

Siapkan daftar: berapa lama garansi kendaraan dan baterai, apakah ada batas jarak tempuh, komponen apa yang dikecualikan, apakah servis wajib di bengkel resmi, dan bagaimana prosedur klaim. Tanyakan juga apakah garansi berpindah saat mobil dijual.

Catat jawaban beserta nama dan tanggal. Catatan ini berguna bila ada perbedaan pemahaman di kemudian hari. Minta dokumen garansi tertulis dan baca bagian pengecualian dengan teliti.

## Garansi dan servis berkala

Garansi umumnya mensyaratkan servis berkala sesuai jadwal. Melewatkannya dapat memengaruhi keberlakuan. Kami belum memiliki jadwal resmi EX5, jadi tanyakan dan catat tanggalnya. Pembahasan perawatan ada di [perawatan EX5: servis berkala dan biaya](/artikel/perawatan-geely-ex5-servis-berkala-dan-biaya/).

Simpan semua bukti servis. Riwayat yang rapi membantu klaim dan menambah kepercayaan calon pembeli saat Anda menjual mobil.

## Apa yang memengaruhi nilai jual kembali

Nilai jual dipengaruhi kondisi fisik, riwayat servis, kondisi baterai, jarak tempuh, popularitas model, dan situasi pasar. Kami tidak memiliki data pasar EX5, sehingga tidak membuat prediksi angka.

Yang bisa Anda kendalikan adalah kondisi mobil dan kelengkapan dokumen. Pembahasan umum ada di [nilai jual kembali mobil listrik: mitos dan faktanya](/artikel/nilai-jual-kembali-mobil-listrik-mitos-dan-faktanya/).

## Menjaga baterai agar nilai terjaga

Baterai adalah komponen yang paling dipertimbangkan calon pembeli mobil listrik bekas. Kebiasaan pengisian yang baik membantu menjaga kondisinya. Pembahasan ada di [umur baterai mobil listrik LFP](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

Simpan catatan pengisian bila memungkinkan. Calon pembeli sering menghargai transparansi tentang bagaimana baterai dirawat, dan bukti tertulis lebih meyakinkan daripada pernyataan lisan.

## Pengaruh varian dan warna

Sebagian orang percaya varian lengkap atau warna netral lebih mudah dijual. Kami tidak memiliki data untuk memastikannya pada EX5. Pilih varian dan warna berdasarkan kegunaan dan kesukaan Anda, sebab kepuasan harian lebih pasti daripada spekulasi.

Pembahasan varian ada di [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/) dan warna di [warna Geely EX5](/artikel/warna-geely-ex5-pilihan-warna-pro-dan-max/).

## Saat menjual nanti

Siapkan buku servis, faktur, dan catatan perawatan. Putuskan hubungan akun aplikasi dan hapus data pribadi dari sistem mobil sebelum diserahkan. Bersihkan mobil secara menyeluruh dan perbaiki cacat kecil yang mudah.

Jika mobil masih dalam masa garansi, tanyakan prosedur pengalihan hak garansi. Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Tanda yang perlu diwaspadai

Waspadai jawaban terlalu umum, janji yang tidak mau dituliskan, atau tekanan untuk memutuskan sebelum membaca dokumen. Bila menemukan hal itu, tunda keputusan dan konfirmasi ulang.

Mobil adalah pembelian besar. Beberapa hari untuk memastikan jauh lebih murah daripada penyesalan bertahun-tahun. Atur jadwal bertanya lewat halaman [kontak](/kontak/), dan lihat penawaran di halaman [promo](/promo/).

## Contoh percakapan yang baik dengan sales

Anda bisa membuka dengan kalimat sederhana: "Saya ingin tahu ketentuan garansi kendaraan dan baterai EX5, mohon dijelaskan dan diberikan secara tertulis." Lalu lanjutkan dengan pertanyaan spesifik tentang jangka waktu, batas jarak, dan pengecualian. Bila jawabannya tidak jelas, minta sales mengonfirmasi ke pihak terkait dan menghubungi Anda kembali.

Sikap tenang dan terstruktur biasanya mendapat tanggapan lebih baik. Tidak perlu curiga berlebihan, cukup teliti. Dealer yang baik akan menghargai pembeli yang memahami haknya dan membantu menjelaskan sampai Anda paham.

## Dokumen yang perlu disimpan sejak hari pertama

Simpan faktur, buku servis, buku garansi, bukti pembayaran, dan catatan komunikasi penting. Foto setiap halaman dan simpan di penyimpanan daring yang aman. Dokumen lengkap mempermudah klaim, penjualan kembali, dan penyelesaian sengketa bila terjadi.

Buat folder khusus di ponsel Anda dengan nama yang jelas, dan perbarui setiap kali ada servis atau pembayaran. Kebiasaan sederhana ini sering membedakan pemilik yang tenang dari yang kerepotan saat dokumen dibutuhkan.

## Garansi dan penggunaan komersial

Banyak garansi membedakan penggunaan pribadi dan komersial. Bila Anda berencana memakai EX5 untuk usaha, misalnya layanan antar-jemput, tanyakan apakah garansi tetap berlaku dan dalam kondisi apa. Kami tidak memiliki ketentuan resminya.

Tanyakan juga pengaruh modifikasi, seperti pemasangan aksesori atau perubahan kelistrikan, terhadap garansi. Minta jawaban tertulis sebelum melakukan perubahan apa pun pada mobil.

## Langkah selanjutnya

Siapkan daftar pertanyaan di atas dan bawa saat berkunjung. Sampaikan bahwa Anda ingin jawaban tertulis. Lihat juga [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/) bila Anda juga mempertimbangkan pembiayaan.

## Satu kebiasaan yang berguna

Setiap kali berkunjung ke bengkel resmi, minta salinan lembar kerja dan simpan. Dokumen kecil ini kelak menjadi bukti perawatan yang konsisten.

## Pertanyaan yang sering diajukan

### Berapa garansi baterai EX5?

Kami tidak memiliki angka resmi. Mintalah dokumen garansi tertulis.

### Berapa nilai jual EX5 nanti?

Kami tidak memprediksi angka. Banyak faktor memengaruhinya.

### Apakah servis harus di bengkel resmi?

Tanyakan ketentuan garansinya kepada sales.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Garansi EX5 perlu Anda pastikan lewat dokumen resmi, dan nilai jual kembali dijaga lewat perawatan dan dokumentasi yang rapi. Minta jawaban tertulis dan simpan semua bukti.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk pertanyaan tentang garansi.
