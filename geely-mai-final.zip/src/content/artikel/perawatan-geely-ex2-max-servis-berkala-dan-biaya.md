---
title: "Perawatan Geely EX2 Max: Apa yang Perlu Anda Tanyakan"
description: "Perawatan Geely EX2 Max: jadwal servis dan biaya belum kami cantumkan. Panduan pertanyaan, kebiasaan perawatan harian, dan hal yang berbeda dari mobil bensin."
date: 2026-10-14
category: "Kredit & Biaya"
tags: ["perawatan geely ex2", "servis berkala geely ex2", "geely ex2 max", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik kompak"]
draft: true
---

Perawatan Geely EX2 Max sering dibayangkan lebih sederhana dibanding mobil bensin, tetapi jadwal servis dan biaya resminya belum kami miliki sehingga tidak kami tuliskan. Artikel ini memberikan kerangka pertanyaan untuk sales, kebiasaan perawatan harian yang bisa Anda lakukan sendiri, dan gambaran apa yang umumnya berbeda pada mobil listrik.

## Apa yang tidak kami tuliskan dan alasannya

Jadwal servis, interval kilometer, dan biaya adalah informasi yang mengikat dan sering berubah. Menebaknya berisiko menyesatkan Anda. Karena itu kami hanya menyajikan hal yang dapat diverifikasi, lalu mengarahkan Anda untuk meminta jadwal resmi secara tertulis dari dealer.

Sikap ini mungkin terasa kurang memuaskan, tetapi lebih jujur. Dokumen buku servis yang Anda terima saat serah terima adalah rujukan yang sah. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Apa yang umumnya berbeda dari mobil bensin

Mobil listrik tidak memiliki mesin pembakaran, sehingga tidak ada oli mesin, busi, atau filter oli yang perlu diganti berkala. Hal ini mengurangi sebagian komponen perawatan rutin yang biasa Anda kenal. Pembahasan umum ada di [perawatan mobil listrik: apa yang berbeda dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/).

Namun, mobil listrik tetap memiliki rem, ban, suspensi, AC, cairan pendingin, dan sistem kelistrikan yang perlu diperiksa. Jangan menyimpulkan bahwa mobil listrik bebas perawatan. Perbedaannya ada pada jenis pekerjaan, bukan pada keberadaannya.

## Komponen yang tetap memerlukan perhatian

Rem tetap bekerja, meski penggunaan rem regeneratif dapat mengurangi keausan kampasnya. Ban tetap aus, bahkan mobil listrik yang bertenaga halus tetap membebani ban oleh bobot baterainya. Suspensi depan MacPherson dan belakang multi-link perlu diperiksa mengikuti kondisi jalan.

Sistem pendingin baterai dan kabin, filter kabin, serta wiper juga memerlukan pengecekan. Tanyakan kepada sales komponen mana saja yang masuk jadwal servis EX2 dan berapa interval tiap pemeriksaan.

## Perawatan baterai dalam keseharian

Baterai EX2 berjenis LFP 40,8 kWh. Kebiasaan pengisian yang baik membantu menjaga usia pakai. Hindari membiarkan baterai terlalu kosong dalam waktu lama, dan jangan menunda pengisian hingga sangat rendah secara rutin. Pembahasan lengkap ada di [umur baterai LFP dan cara merawatnya](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

Kami tidak memiliki rekomendasi resmi tentang batas pengisian harian untuk EX2, jadi tanyakan kepada sales dan ikuti petunjuk pabrikan di buku manual.

## Perawatan yang bisa Anda lakukan sendiri

Ada pekerjaan ringan yang tidak memerlukan bengkel. Periksa tekanan ban secara berkala, bersihkan lensa kamera dan sensor dari debu, jaga kebersihan kabin, dan cek lampu serta wiper. Perhatikan lampu peringatan di panel instrumen 8,8 inci.

Simpan kabel pengisi daya di tempat kering dan hindari menginjaknya. Kabel yang rusak berbahaya dan sebaiknya tidak dipakai. Frunk 70 liter dapat menjadi tempat penyimpanan kabel yang rapi.

## Pertanyaan yang sebaiknya diajukan ke sales

Siapkan daftar: berapa interval servis berkala dan apa saja isinya, apakah servis harus di bengkel resmi agar garansi berlaku, ke mana saya membawa mobil bila ada masalah, dan apakah tersedia layanan derek. Tanyakan juga apakah ada paket servis berkala dan apa cakupannya.

Minta jawaban tertulis, karena janji lisan sulit dibuktikan kemudian. Pembahasan terkait ada di [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

## Menghitung biaya perawatan secara adil

Biaya perawatan sebaiknya dihitung sebagai bagian dari total biaya kepemilikan, bersama listrik, asuransi, pajak, dan cicilan. Kami tidak mencantumkan angka perawatan karena belum ada data resmi, tetapi Anda bisa menyusun tabel kosong dan mengisinya ketika sales memberi angka.

Bandingkan dengan biaya perawatan mobil Anda sekarang selama setahun terakhir. Perbandingan nyata dari catatan sendiri jauh lebih bermakna daripada rata-rata yang beredar di internet. Panduan hitungan ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/).

## Bengkel dan layanan purna jual

Mobil listrik memerlukan teknisi yang terlatih menangani sistem bertegangan tinggi. Tanyakan lokasi bengkel resmi terdekat, jam operasional, dan estimasi waktu tunggu suku cadang. Ketersediaan layanan di dekat tempat tinggal Anda sering menjadi faktor kenyamanan jangka panjang.

Jangan menyerahkan perbaikan sistem kelistrikan atau baterai kepada bengkel yang tidak berwenang. Selain berisiko, hal ini dapat memengaruhi garansi. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

## Kebiasaan yang memperpanjang usia mobil

Cuci mobil secara rutin, terutama setelah hujan dan jalan berdebu. Hindari memarkir di bawah sinar matahari terik terlalu lama bila ada pilihan teduh. Gunakan mobil secara teratur; mobil yang jarang dipakai pun tetap memerlukan pengecekan baterai.

Catat tanggal servis dan simpan bukti pekerjaan. Catatan yang rapi membantu klaim garansi dan meningkatkan kepercayaan calon pembeli bila suatu saat Anda menjual mobilnya.

## Servis sebelum perjalanan jauh

Sebelum bepergian jauh, lakukan pemeriksaan ringan: tekanan ban, kondisi wiper, lampu, dan kabel pengisi. Pastikan juga tidak ada lampu peringatan menyala. Rencanakan titik pengisian di sepanjang rute, dan simpan nomor layanan darurat dealer di ponsel.

Pemeriksaan sepuluh menit ini sering mencegah masalah yang merepotkan di jalan. Bila Anda ragu terhadap kondisi mobil, lebih baik singgah ke bengkel resmi sehari sebelum berangkat daripada menunda hingga sudah di perjalanan.

## Perawatan saat mobil jarang dipakai

Jika mobil sering menganggur, misalnya karena Anda bekerja dari rumah, jangan abaikan baterainya. Tanyakan kepada sales cara menyimpan mobil listrik dengan benar saat tidak dipakai beberapa pekan, termasuk tingkat pengisian yang dianjurkan. Kami tidak memiliki panduan resmi untuk EX2, sehingga kami tidak menyebut angkanya.

Nyalakan dan jalankan mobil secara berkala agar ban tidak mengalami titik tekan tetap dan sistem tetap aktif. Cuci dan bersihkan kabin agar tidak berjamur, terutama di musim hujan.

## Pertanyaan yang sering diajukan

### Apakah mobil listrik tidak perlu servis?

Tetap perlu. Yang berbeda adalah jenis pekerjaannya.

### Berapa biaya servis EX2?

Kami belum memiliki angka resmi. Mintalah jadwal dan estimasi tertulis.

### Apakah harus servis di bengkel resmi?

Tanyakan ketentuan garansinya kepada sales.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Perawatan EX2 Max umumnya berbeda dari mobil bensin, tetapi tetap ada dan perlu direncanakan. Minta jadwal serta biaya resmi secara tertulis, lalu rawat mobil dengan kebiasaan yang konsisten.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk pertanyaan seputar servis.
