---
title: "Kabin dan Bagasi Geely EX5: 461 Liter hingga 1.877 Liter"
description: "Kabin dan bagasi Geely EX5: 461 liter kursi tegak hingga 1.877 liter saat dilipat 60/40, laci bawah jok, ISOFIX, dan cara menguji ruangnya sebelum membeli."
date: 2026-10-14
category: "Model Geely"
tags: ["bagasi geely ex5", "kabin geely ex5", "geely ex5", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Kabin dan bagasi Geely EX5 menjadi alasan utama banyak keluarga melirik SUV listrik ini. Bagasinya 461 liter saat kursi tegak dan 1.877 liter saat jok belakang dilipat. Artikel ini membahas apa yang ditawarkan ruangnya, bagaimana menyusun barang, dan cara membuktikan sendiri apakah cukup untuk keluarga Anda.

## Angka ruang yang kami pegang

Data brosur menyebut panjang 4.615 mm, lebar 1.901 mm, tinggi 1.670 mm, dan jarak sumbu roda 2.750 mm, dengan kapasitas lima penumpang. Bagasi 461 liter saat kursi tegak dan 1.877 liter saat dilipat. Angka ini panduan, bukan jaminan bahwa barang Anda muat.

Bentuk bagasi, tinggi lantai, dan bukaan pintu menentukan seberapa mudah memuat. Karena itu, bawa barang Anda sendiri saat mencoba. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Jok belakang yang bisa dilipat 60/40

Jok belakang dapat dilipat dengan pembagian 60/40. Artinya Anda bisa melipat sebagian saja: misalnya membawa barang panjang sambil tetap mengangkut satu atau dua penumpang di sisi lainnya. Fleksibilitas ini berguna untuk keluarga yang kebutuhan angkutnya berubah-ubah.

Sandaran jok belakang juga bisa diatur secara manual dan tersedia armrest tengah dengan headrest. Coba atur sandaran pada sudut yang nyaman untuk penumpang yang akan sering duduk di sana.

## Laci penyimpanan di bawah jok belakang

Brosur menyebut adanya laci penyimpanan di bawah jok belakang. Ruang seperti ini cocok untuk barang kecil yang jarang diambil, misalnya perlengkapan darurat. Ukuran dan kapasitasnya tidak tercantum, jadi lihat langsung di dealer.

Menaruh barang berat di laci perlu hati-hati agar tidak bergeser saat pengereman. Gunakan wadah yang rapat untuk mencegah barang berbunyi atau bergeser.

## Pintu bagasi elektrik pada Max

Varian Max dilengkapi pintu bagasi elektrik satu sentuhan. Fitur ini memudahkan saat kedua tangan penuh, misalnya membawa belanjaan atau anak. Bila Anda memilih Pro, pintu dibuka secara manual.

Tanyakan kepada sales apakah tinggi buka pintu bisa diatur, penting bagi yang parkir di tempat dengan plafon rendah. Detail ini sering diabaikan hingga mobil sudah dimiliki.

## Mengatur isi bagasi

Letakkan barang berat dan stabil di bawah, dekat sandaran jok. Barang ringan dan mudah bergeser di atas atau di tempat tertutup. Gunakan penutup atau wadah agar barang tidak terlihat dari luar, terutama saat parkir.

Hindari menumpuk barang melebihi sandaran jok belakang karena menghalangi pandangan dan berbahaya saat pengereman mendadak. Pastikan kabel pengisi daya mudah dijangkau tanpa membongkar isi bagasi.

## ISOFIX dan keluarga dengan anak

Brosur menyebut titik ISOFIX dan child anchor di jok belakang. Bagi keluarga dengan anak kecil, ini memudahkan pemasangan kursi anak yang kokoh. Namun jenis dan jumlah kursi yang bisa dipasang sebaiknya diuji dengan kursi anak Anda sendiri.

Bawa kursi anak saat test drive dan pasang di jok belakang. Perhatikan ruang kaki penumpang depan setelah kursi anak terpasang. Pembahasan keselamatan ada di [keamanan EX5](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/).

## Kenyamanan duduk di jok depan dan belakang

Jok depan EX5 berfitur elektrik, dengan jok pengemudi 6 arah dan jok penumpang depan 4 arah. Max menambah jok massage dan sandaran kaki penumpang depan elektrik. Fitur kenyamanan dibahas di [kenyamanan EX5: jok ventilasi, massage, dan HUD](/artikel/fitur-kenyamanan-geely-ex5-jok-ventilasi-massage-dan-hud/).

Bagi penumpang belakang, perhatikan ruang kaki, ruang kepala, dan lubang AC belakang. Duduk di belakang selama beberapa menit memberi gambaran lebih jujur daripada angka dimensi mana pun.

## Membandingkan dengan EX2

EX2 yang lebih kompak memiliki bagasi 375 liter dan frunk 70 liter, sedangkan EX5 menawarkan bagasi utama lebih besar. Bila Anda sering membawa barang atau penumpang dewasa, ruang EX5 lebih menenangkan.

Perbandingan lengkap ada di [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/). Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Cara menguji sebelum membeli

Bawa barang yang biasa Anda angkut: stroller, koper, peralatan olahraga, atau tas besar. Coba masukkan satu per satu dan lihat apakah mudah. Lipat jok dan coba skenario terburuk, misalnya membawa barang panjang.

Ajak seluruh keluarga duduk di semua posisi. Catat kesan masing-masing. Atur jadwal lewat halaman [kontak](/kontak/) dan lihat penawaran di halaman [promo](/promo/).

## Kebiasaan menata bagasi untuk keluarga

Keluarga yang sering bepergian biasanya memiliki satu tas perlengkapan tetap: tisu, botol minum, pakaian ganti, dan obat ringan. Simpan tas ini di tempat yang mudah dijangkau, misalnya di sisi bagasi dekat pintu, sehingga tidak perlu membongkar koper saat dibutuhkan.

Pisahkan barang kotor, seperti sepatu atau alat olahraga, dalam wadah tertutup supaya kabin tetap bersih. Kebiasaan sederhana ini membuat ruang yang besar tetap terasa rapi dan fungsional dalam jangka panjang.

## Bila ruang terasa masih kurang

Jika setelah mencoba Anda merasa bagasi tetap kurang, pertimbangkan rak atap, mengingat brosur menyebut rel atap pada EX5. Tanyakan kepada sales batas beban rel atap, aksesori resmi yang tersedia, dan pengaruhnya terhadap konsumsi energi serta garansi. Kami tidak memiliki angka batas beban, jadi jangan menebaknya.

Barang di atap menambah hambatan udara dan dapat memperpendek jarak tempuh. Gunakan seperlunya dan lepaskan bila tidak dipakai. Rencanakan muatan sebelum bepergian jauh agar pengisian daya tetap terkelola.

## Lampu dan kemudahan di bagasi

Brosur menyebut lampu bagasi LED, tombol darurat untuk membuka bagasi dari dalam, dan soket 12V di bagian depan. Lampu bagasi membantu saat memuat barang malam hari, sedangkan tombol darurat memberi rasa aman bagi anak yang tanpa sengaja terkurung.

Ajarkan seluruh anggota keluarga cara kerja tombol itu. Pengetahuan sederhana semacam ini jarang dibicarakan, padahal bernilai besar pada situasi darurat dan sering luput dari daftar fitur yang dibandingkan.

## Pertanyaan yang sering diajukan

### Berapa kapasitas bagasi EX5?

461 liter kursi tegak, hingga 1.877 liter saat dilipat.

### Apakah jok belakang bisa dilipat sebagian?

Ya, pembagian 60/40 menurut brosur.

### Apakah ada ISOFIX?

Brosur menyebut ISOFIX dan child anchor di jok belakang.

### Apakah pintu bagasi elektrik di semua varian?

Menurut brosur hanya pada varian Max.

## Kesimpulan

Kabin dan bagasi EX5 memberi ruang lega dan fleksibel untuk keluarga. Namun kecukupannya tetap perlu dibuktikan dengan barang dan penumpang Anda sendiri.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mengatur sesi coba.
