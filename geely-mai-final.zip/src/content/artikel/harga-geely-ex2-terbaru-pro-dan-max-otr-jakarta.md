---
title: "Harga Geely EX2 Jakarta Oktober 2026: Pro dan Max OTR"
description: "Harga Geely EX2 per Oktober 2026 OTR Jakarta: Pro Rp 239,9 juta dan Max Rp 269,9 juta. Cara membaca selisih, hitung uang muka, dan minta penawaran tertulis."
date: 2026-10-14
category: "Harga & Promo"
tags: ["harga geely ex2", "harga geely ex2 max", "harga geely ex2 pro", "otr geely ex2 jakarta", "harga mobil listrik geely", "mobil listrik murah", "geely ev", "geely indonesia"]
draft: false
---

Harga Geely EX2 per Oktober 2026 untuk wilayah Jakarta tercatat Rp 239.900.000 (Pro) dan Rp 269.900.000 (Max), keduanya OTR. Artikel ini membantu Anda membaca angka itu: apa arti OTR, apa yang menjelaskan selisih Rp 30 juta, dan bagaimana meminta penawaran tertulis yang bisa Anda bandingkan.

*Harga dan promo dapat berubah tanpa pemberitahuan. Data per Oktober 2026; minta penawaran tertulis terbaru dari Geely MAI sebelum memutuskan.*

## Daftar harga per Oktober 2026

| Varian | Harga OTR Jakarta |
|---|---|
| Geely EX2 Pro | Rp 239.900.000 |
| Geely EX2 Max | Rp 269.900.000 |

Angka ini berasal dari data penjual per Oktober 2026 dan bukan jaminan harga pada hari Anda memesan. Karena itu, anggap tabel ini sebagai titik awal diskusi, lalu minta konfirmasi tertulis bertanggal. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Apa arti OTR

OTR atau on the road berarti harga yang sudah siap untuk dipakai di jalan pada wilayah tertentu, sehingga sudah mencakup komponen pengurusan yang diperlukan. Komponen persisnya bisa berbeda antar penawaran, jadi minta rincian tertulis supaya Anda tahu apa saja yang termasuk.

Karena OTR bergantung wilayah, harga untuk Jakarta tidak otomatis berlaku di kota lain. Jika Anda berdomisili di luar Jakarta, tanyakan harga untuk wilayah Anda dan jangan menyamakan begitu saja.

## Apa yang sama pada Pro dan Max

Berdasarkan data kami, kedua varian memakai baterai LFP 40,8 kWh, motor 85 kW, torsi 150 Nm, dan klaim jarak 395 km (NEDC). Bagasi 375 liter dan frunk 70 liter serta kapasitas lima penumpang juga sama. Dengan kata lain, selisih harga bukan untuk jarak tambahan atau tenaga tambahan.

Hal ini penting agar Anda tidak keliru berharap. Membayar lebih untuk Max tidak menjadikan mobil lebih jauh jangkauannya. Spesifikasi lengkap ada di [spesifikasi lengkap Geely EX2 Max](/artikel/spesifikasi-lengkap-geely-ex2-max/).

## Apa yang dibeli dengan selisih Rp 30 juta

Max menambah kamera 540 derajat, ADAS Level 2, V2L, jok pengemudi elektrik, velg, dan kontrol lewat aplikasi. Selisihnya adalah Rp 269.900.000 dikurangi Rp 239.900.000, yaitu Rp 30.000.000. Pertanyaannya bukan apakah fitur-fiturnya bagus, melainkan apakah Anda akan memakainya.

Satu cara adil adalah membagi selisih itu dengan jumlah tahun Anda berencana memakai mobil. Bila Anda memakai mobil lima tahun, selisih per tahun sekitar Rp 6 juta, atau Rp 500 ribu per bulan sebagai ilustrasi aritmetika. Tanyakan pada diri sendiri apakah fitur Max bernilai sebanyak itu bagi Anda. Pembahasannya ada di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Membayangkan uang muka dan pokok pinjaman

Sebagai latihan hitung, bila uang muka sekitar Rp 40 juta, pokok yang perlu dibiayai pada Pro sekitar Rp 199,9 juta, dan pada Max sekitar Rp 229,9 juta. Ini bukan cicilan. Besar angsuran bergantung tenor, skema, dan persetujuan perusahaan pembiayaan.

Gunakan angka ini hanya untuk membayangkan skala. Untuk hitungan lebih lengkap, baca [simulasi cicilan EX2 Max](/artikel/simulasi-cicilan-geely-ex2-max-dp-dan-tenor/) dan minta simulasi tertulis dari kami.

## Biaya di luar harga mobil

Harga mobil bukan seluruh biaya kepemilikan. Siapkan anggaran untuk pemasangan pengisi daya di rumah, asuransi, pajak tahunan, dan perawatan. Biaya energi bisa Anda bandingkan lewat [biaya per km EX2 Max vs mobil bensin](/artikel/biaya-per-km-geely-ex2-max-vs-mobil-bensin/).

Aturan pajak dapat berubah, jadi baca [pajak mobil listrik EX2](/artikel/pajak-dan-insentif-mobil-listrik-untuk-geely-ex2-max/) dan cek aturan terbaru. Masukkan semua biaya itu ke satu tabel agar keputusan Anda berdasar gambaran utuh.

## Cara meminta penawaran tertulis

1. Tentukan varian yang paling mendekati kebutuhan Anda.
2. Hubungi kami lewat halaman [kontak](/kontak/) dan minta rincian harga OTR tertulis beserta tanggalnya.
3. Minta simulasi kredit sesuai uang muka dan tenor yang Anda inginkan.
4. Jadwalkan test drive; panduannya ada di [cara test drive Geely](/artikel/cara-test-drive-geely/).
5. Simpan penawaran dan perhatikan masa berlakunya.

## Hal yang perlu dicek sebelum membayar

Pastikan ketersediaan warna dan unit, perkiraan waktu tunggu, perlengkapan bawaan termasuk kabel pengisi, serta ketentuan garansi. Kami tidak mencantumkan angka garansi karena belum ada data resminya; baca [garansi baterai dan mobil EX2](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/) untuk daftar pertanyaan.

Tanyakan juga apa yang terjadi bila pengajuan kredit tidak disetujui dan bagaimana nasib tanda jadi Anda. Jawaban tertulis melindungi kedua pihak.

## Menilai harga dengan kepala dingin

Harga dan promo bisa berubah dari bulan ke bulan. Meski demikian, hindari memutuskan karena takut ketinggalan. Beri diri Anda satu atau dua hari setelah test drive dan setelah menerima simulasi, lalu putuskan ketika yakin cicilan nyaman dan mobilnya cocok.

Tips tambahan ada di [booking dan negosiasi EX2](/artikel/tips-booking-dan-negosiasi-geely-ex2-max/). Informasi promo terkini ada di halaman [promo](/promo/).

## Membandingkan dengan pilihan lain

Bila Anda sedang menimbang beberapa mobil, bandingkan dengan dasar yang sama: varian, kelengkapan, total pembayaran, dan biaya kepemilikan. Harga termurah belum tentu paling hemat jika biaya lainnya lebih tinggi.

Untuk panduan membandingkan mobil listrik kompak, baca [cara membandingkan EX2 Max dengan mobil listrik kompak lain](/artikel/cara-membandingkan-geely-ex2-max-dengan-mobil-listrik-kompak-lain/). Bila kebutuhan ruang Anda lebih besar, lihat juga [harga Geely EX5](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/).

## Harga dan kebutuhan pengisian

Harga mobil hanya satu sisi; sisi lainnya adalah kesiapan mengisi daya. Pemasangan pengisi di rumah memerlukan perencanaan daya listrik dan izin tempat parkir, terutama bagi penghuni apartemen. Tanyakan kepada pengelola gedung sebelum memesan. Panduan ada di [cara mengisi daya EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/).

Detail varian dan perlengkapan terbaru dapat dilihat di halaman [Geely EX2](/model/geely-ex2/). Karena perlengkapan bisa berubah, minta daftar tertulis untuk unit yang akan Anda terima.

## Pertanyaan yang sering diajukan

### Berapa harga Geely EX2 Pro?

Per Oktober 2026 tercatat Rp 239.900.000 OTR Jakarta. Minta penawaran tertulis terbaru.

### Berapa harga Geely EX2 Max?

Per Oktober 2026 tercatat Rp 269.900.000 OTR Jakarta.

### Apakah harga bisa berubah?

Ya, sewaktu-waktu. Konfirmasi tertulis bertanggal sebelum membayar.

### Bagaimana cara melihat promo?

Lihat halaman [promo](/promo/) atau hubungi kami.

## Kesimpulan

Harga EX2 per Oktober 2026 adalah Rp 239,9 juta untuk Pro dan Rp 269,9 juta untuk Max (OTR Jakarta). Selisihnya membayar kelengkapan, bukan tenaga atau jarak. Minta penawaran tertulis, hitung biaya lengkap, dan putuskan dengan tenang.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk penawaran terbaru.
