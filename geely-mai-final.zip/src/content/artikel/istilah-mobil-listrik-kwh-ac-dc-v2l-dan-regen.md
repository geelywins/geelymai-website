---
title: "Istilah Mobil Listrik: kWh, AC, DC, V2L, dan Regen Dijelaskan"
description: "Kamus istilah mobil listrik untuk pemula: kWh, kW, AC, DC, V2L, V2V, regen, NEDC, WLTP, PHEV, dan lainnya, dijelaskan sederhana dengan contoh pada model Geely."
date: 2026-10-14
category: "Panduan EV"
tags: ["istilah mobil listrik", "arti kwh", "v2l regen", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "panduan mobil listrik"]
draft: true
---

Istilah mobil listrik sering terdengar rumit bagi pemula, padahal sebagian besar mudah dipahami dengan analogi sehari-hari. Kamus singkat ini menjelaskan istilah yang paling sering muncul saat Anda membaca brosur atau berbicara dengan sales, lengkap dengan contoh pada model Geely yang kami bahas.

## Cara memakai kamus ini

Baca sekilas, lalu kembali ke bagian yang Anda butuhkan saat bertemu istilah baru. Contoh angka diambil dari data resmi yang kami miliki, dan semua angka jarak atau pengisian adalah klaim pabrikan. Gambaran umum ada di [mobil listrik pertama](/lp/mobil-listrik-pertama/).

## kWh: ukuran isi baterai

kWh atau kilowatt-jam menyatakan energi yang tersimpan, seperti ukuran tangki pada mobil bensin. Baterai EX2 berkapasitas 40,8 kWh, EX5 60,22 kWh, dan Starray EM-i 18,4 kWh. Semakin besar angkanya, semakin banyak energi yang tersimpan, meski jarak juga bergantung efisiensi mobil.

Jadi jangan membandingkan kWh sebagai jarak. Dua mobil dengan kWh sama bisa menempuh jarak berbeda.

## kW: ukuran daya

kW atau kilowatt menyatakan daya, yaitu seberapa cepat energi dipakai atau dikirim. Motor EX2 berdaya 85 kW dan motor EX5 160 kW. Pada pengisian, kW menunjukkan kecepatan energi masuk ke baterai: EX5 mendukung AC hingga 11 kW dan DC hingga 100 kW.

Singkatnya, kWh adalah isi tangki, sedangkan kW adalah derasnya aliran. Dua hal yang berbeda tetapi sering tertukar.

## AC dan DC: dua jenis pengisian

Pengisian AC memakai listrik bolak-balik dari stopkontak atau wallbox dan diubah di dalam mobil. Biasanya lebih lambat tetapi cocok untuk semalam di rumah. Pengisian DC memberikan arus searah langsung ke baterai di stasiun khusus, jauh lebih cepat.

Klaim EX2: AC 10-100% sekitar 6,5 jam dan DC 30-80% sekitar 25 menit. Panduan ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/).

## Type-2 dan CCS2: bentuk konektor

Type-2 adalah konektor umum untuk pengisian AC, dan CCS2 adalah konektor untuk pengisian DC. Brosur EX5 menyebut keduanya. Pastikan stasiun yang Anda tuju mendukung konektor yang sesuai dengan mobil Anda.

Konektor yang tidak cocok tidak bisa dipakai tanpa adaptor yang sesuai. Tanyakan kepada sales perlengkapan apa yang termasuk dalam pembelian.

## SPKLU: stasiun pengisian umum

SPKLU adalah singkatan stasiun pengisian kendaraan listrik umum. Lokasi dan ketersediaannya berubah, sehingga kami tidak mencantumkan nama atau titik tertentu. Gunakan aplikasi peta atau penyedia pengisian untuk melihat lokasi terkini.

Untuk perjalanan jauh, rencanakan titik utama dan cadangan. Pembahasan ada di [mudik dan perjalanan jauh dengan EX2](/artikel/mudik-dan-perjalanan-jauh-dengan-geely-ex2-max/).

## Rem regeneratif atau regen

Saat Anda melepas gas atau mengerem, motor dapat berbalik menjadi generator dan mengembalikan sebagian energi ke baterai. Inilah rem regeneratif. Efeknya terasa seperti mobil melambat sendiri ketika pedal dilepas.

Manfaatnya paling terasa di lalu lintas berhenti-jalan. Namun regen bukan sumber pengisian utama, dan tidak menggantikan pengisian dari listrik. Brosur EX5 menyebut rem regeneratif, dan EX2 juga dibahas di [EX2 Max di macet Jakarta](/artikel/geely-ex2-max-di-macet-jakarta/).

## V2L dan V2V

V2L atau vehicle-to-load menyalurkan listrik dari baterai mobil ke perangkat luar, misalnya lampu atau kipas. V2V atau vehicle-to-vehicle menyalurkan listrik ke mobil listrik lain. EX2 Max memiliki V2L, dan EX5 memiliki V2L dan V2V.

Daya keluarannya tidak tercantum pada data kami, jadi tanyakan kepada sales. Baca [fitur V2L EX2 Max](/artikel/fitur-v2l-geely-ex2-max-listrik-untuk-camping-dan-darurat/) dan [V2L dan V2V EX5](/artikel/v2l-dan-v2v-geely-ex5-listrik-mobil-untuk-perangkat-lain/).

## NEDC dan WLTP

Keduanya adalah standar uji laboratorium untuk menyatakan jarak tempuh. NEDC lebih lama dan cenderung menghasilkan angka lebih tinggi, WLTP lebih baru dan lebih konservatif. Keduanya tetap bukan hasil jalan nyata. Baca [NEDC vs WLTP](/artikel/nedc-vs-wltp-arti-jarak-tempuh-mobil-listrik/).

## LFP: jenis baterai

LFP adalah singkatan lithium iron phosphate, jenis baterai lithium yang dikenal stabil secara kimia. EX2, EX5, dan Starray EM-i memakai baterai LFP. Jenis baterai memengaruhi karakter dan kebiasaan perawatan. Baca [umur baterai mobil listrik LFP](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

## PHEV dan EV: dua jenis kendaraan

EV adalah mobil listrik murni yang bergantung baterai. PHEV atau plug-in hybrid memiliki baterai yang bisa diisi dari colokan sekaligus mesin bensin, seperti Starray EM-i. Pembahasan ada di [cara kerja plug-in hybrid EM-i](/artikel/cara-kerja-plug-in-hybrid-geely-em-i-dan-cara-mengisi-daya/).

## OTA dan ADAS

OTA adalah pembaruan perangkat lunak lewat internet tanpa ke bengkel. ADAS adalah sistem bantuan pengemudi seperti cruise control adaptif dan peringatan titik buta. Keduanya membantu, tetapi bukan pengganti kewaspadaan pengemudi. Baca [fitur ADAS EX2 Max](/artikel/fitur-adas-geely-ex2-max-apa-saja-dan-cara-kerjanya/).

## OTR, DP, dan tenor

OTR berarti harga siap pakai di wilayah tertentu. DP adalah uang muka. Tenor adalah lama cicilan. Ketiganya sering muncul saat membahas pembelian. Pahami kombinasinya di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Istilah yang sering muncul saat membeli

Selain istilah teknis, ada istilah transaksi yang perlu Anda pahami: booking atau pemesanan awal, tanda jadi, PDI atau pemeriksaan sebelum serah terima, dan balloon payment atau pembayaran akhir di ujung kredit. Pahami artinya sebelum menandatangani apa pun.

Baca [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/) dan [cek mobil baru saat serah terima](/artikel/cek-mobil-baru-saat-serah-terima-checklist-pdi/) untuk melihat istilah itu dalam konteks. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

## Tips agar tidak bingung

Saat membaca brosur, tandai istilah yang tidak Anda pahami lalu cari di kamus ini atau tanyakan kepada sales. Jangan malu bertanya; pertanyaan sederhana sering membuka informasi penting. Minta penjelasan dengan contoh nyata, bukan hanya definisi.

Catat jawaban dan simpan. Dalam beberapa minggu, istilah-istilah ini akan terasa wajar, dan Anda dapat membandingkan mobil dengan lebih percaya diri.

## Pertanyaan yang sering diajukan

### Apa bedanya kWh dan kW?

kWh adalah isi baterai, kW adalah daya atau kecepatan aliran energi.

### Apa bedanya AC dan DC?

AC lebih lambat untuk di rumah, DC lebih cepat di stasiun.

### Apakah regen menambah jarak banyak?

Membantu efisiensi, tetapi bukan sumber pengisian utama.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Istilah mobil listrik mudah dipahami bila dihubungkan dengan analogi sehari-hari. Simpan kamus ini dan kembali bila bertemu istilah baru.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk bertanya.
