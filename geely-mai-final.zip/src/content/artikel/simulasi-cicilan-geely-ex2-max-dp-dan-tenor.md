---
title: "Cicilan Geely EX2: Cara Menghitung DP, Tenor, dan Total Bayar"
description: "Cara menghitung cicilan Geely EX2: pokok pinjaman, uang muka, tenor, dan total bayar dengan contoh angka fiktif, plus pertanyaan wajib sebelum menandatangani."
date: 2026-10-14
category: "Kredit & Biaya"
tags: ["cicilan geely ex2", "simulasi kredit geely ex2", "dp geely ex2", "tenor kredit mobil listrik", "geely ex2 max", "mobil listrik geely", "geely ev", "mobil listrik murah"]
draft: true
---

Cicilan Geely EX2 ditentukan oleh tiga hal: besar pokok pinjaman, lama tenor, dan skema pembiayaannya. Artikel ini mengajarkan cara menghitung kerangkanya dengan contoh angka fiktif, supaya Anda dapat menguji simulasi dari perusahaan pembiayaan secara mandiri dan tidak hanya menerima angka yang disodorkan.

## Mengapa kami memakai angka contoh

Besar cicilan sebenarnya bergantung pada persetujuan pembiayaan, bunga, biaya administrasi, dan skema yang Anda pilih. Semua itu berubah-ubah dan kami tidak boleh menebaknya. Karena itu, hitungan di bawah memakai angka fiktif sekadar untuk memperlihatkan logikanya.

Untuk harga dan promo terkini, lihat [harga Geely EX2](/artikel/harga-geely-ex2-terbaru-pro-dan-max-otr-jakarta/) dan halaman [promo](/promo/). Untuk simulasi nyata, minta penawaran tertulis lewat halaman [kontak](/kontak/). Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Tiga komponen dasar

Komponen pertama adalah harga kendaraan yang menjadi dasar pembiayaan. Komponen kedua adalah uang muka atau DP, yaitu bagian yang Anda bayar di awal. Komponen ketiga adalah tenor, yaitu lama cicilan dalam bulan atau tahun.

Selisih antara harga dan uang muka menjadi pokok pinjaman. Pada pokok itu ditambahkan biaya sesuai skema, lalu hasilnya dibagi sepanjang tenor. Memahami urutan ini membuat Anda tidak mudah bingung oleh tabel simulasi.

## Contoh hitungan dengan angka fiktif

Misalkan harga mobil dinyatakan 100 satuan dan uang muka 20 satuan. Pokok pinjaman kasar adalah 80 satuan. Jika pokok itu dibagi rata sepanjang 60 bulan tanpa tambahan apa pun, angsuran pokoknya sekitar 1,33 satuan per bulan.

Angka ini belum mencakup bunga atau biaya lain, sehingga cicilan sebenarnya biasanya lebih besar. Tujuannya hanya menunjukkan bahwa memperpanjang tenor mengecilkan angsuran bulanan, tetapi memperbesar total waktu Anda terikat. Ganti angkanya dengan penawaran asli untuk hasil yang bermakna.

## Efek memperpanjang tenor

Tenor lebih panjang memberi angsuran bulanan lebih ringan, dan itu menggoda. Namun Anda terikat lebih lama, dan total bayar umumnya lebih besar bila ada bunga. Selain itu, risiko perubahan kondisi hidup selama tenor panjang juga lebih besar.

Pilih tenor yang membuat angsuran nyaman tanpa membuat Anda terikat lebih lama dari kebutuhan. Sebagai aturan praktis, angsuran sebaiknya tidak mengganggu kebutuhan pokok, tabungan, dan dana darurat Anda.

## Efek uang muka lebih besar

Uang muka lebih besar mengecilkan pokok pinjaman dan biasanya angsuran. Namun menguras tabungan demi uang muka tinggi berisiko bila ada keperluan mendadak. Sisakan dana darurat yang cukup, juga anggaran untuk pengisi daya di rumah dan asuransi.

Seimbangkan: uang muka yang cukup besar agar angsuran wajar, tetapi tidak sampai membuat Anda rapuh secara finansial. Tidak ada angka ideal universal; yang ada hanya angka yang cocok bagi kondisi Anda.

## Skema berbeda: kredit biasa dan balloon

Pada kredit biasa, pokok dicicil sampai lunas. Pada skema balloon, sebagian nilai dibayar di akhir sehingga angsuran bulanan lebih kecil. Penjelasan skema ini ada di [promo Geely EX2](/artikel/promo-dan-diskon-geely-ex2-bulan-ini/).

Bandingkan keduanya dengan tabel yang sama, termasuk pembayaran akhir. Angsuran kecil dengan pembayaran akhir besar belum tentu lebih baik bagi Anda. Pilih sesuai arus kas dan rencana jangka panjang.

## Biaya yang sering terlewat

Selain angsuran, ada biaya yang kerap luput: administrasi, asuransi, pajak, dan pengisi daya rumah. Tanyakan mana yang dibiayai kredit dan mana yang harus dibayar di muka. Biaya yang dibiayai tetap menambah total, hanya terbagi sepanjang tenor.

Biaya listrik bulanan juga perlu dimasukkan. Anda bisa membandingkannya dengan biaya bahan bakar lewat [biaya per km EX2 Max vs mobil bensin](/artikel/biaya-per-km-geely-ex2-max-vs-mobil-bensin/). Dengan begitu cicilan dilihat dalam konteks biaya bulanan seluruhnya.

## Pertanyaan yang diajukan sebelum menandatangani

Tanyakan: berapa total yang saya bayar sampai lunas, apa saja biaya di luar angsuran, apakah ada denda keterlambatan, bagaimana pelunasan lebih cepat, dan apa yang terjadi bila saya kesulitan membayar. Minta jawaban tertulis dan baca perjanjian sampai akhir.

Siapkan dokumen lebih dulu supaya proses lancar; daftarnya ada di [syarat dan dokumen kredit mobil listrik](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/). Persetujuan tetap menjadi wewenang perusahaan pembiayaan.

## Cicilan Pro dan Max

Pada skema yang sama, varian dengan harga lebih tinggi menghasilkan cicilan lebih besar. Besarnya selisih bulanan terlihat dari simulasi tertulis. Hitung apakah fitur tambahan Max sepadan dengan selisih itu selama masa kredit.

Bagi sebagian orang, selisih bulanan terasa wajar. Bagi yang lain, lebih baik dialihkan ke dana darurat atau pengisi daya rumah. Panduan memilih ada di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Menyusun anggaran bulanan

Tulis seluruh pemasukan dan pengeluaran tetap Anda, lalu masukkan angsuran, listrik pengisian, asuransi bulanan, dan pajak yang dibagi per bulan. Lihat apakah masih tersisa ruang untuk tabungan. Bila tidak, turunkan target atau perpanjang tenor secara wajar, jangan memaksakan.

Anggaran yang jujur adalah dasar keputusan yang baik. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

## Kesalahan umum saat menghitung cicilan

Kesalahan pertama adalah hanya melihat angsuran bulanan tanpa menghitung total. Kesalahan kedua adalah lupa memasukkan biaya sampingan seperti asuransi dan pengisi daya. Kesalahan ketiga adalah membandingkan simulasi dengan tenor yang berbeda seolah setara.

Hindari semuanya dengan satu tabel yang memuat kolom sama untuk setiap penawaran: uang muka, tenor, angsuran, pembayaran akhir bila ada, dan total seluruh pembayaran. Dengan tabel itu, perbedaan sebenarnya antar penawaran langsung terlihat.

## Kapan sebaiknya menunda

Jika setelah dihitung angsuran terasa menekan, tundalah dan perbaiki rencana. Menabung lebih lama untuk uang muka yang lebih besar, atau memilih varian yang lebih sederhana, sering lebih bijak daripada memaksakan. Mobil seharusnya memudahkan hidup, bukan menjadi sumber kecemasan bulanan.

## Pertanyaan yang sering diajukan

### Berapa cicilan EX2 per bulan?

Bergantung varian, uang muka, tenor, dan skema. Minta simulasi tertulis.

### Apakah tenor panjang lebih baik?

Angsuran lebih kecil, tetapi Anda terikat lebih lama dan total bisa lebih besar.

### Apakah pengajuan pasti disetujui?

Tidak. Persetujuan ditentukan perusahaan pembiayaan.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Cicilan adalah hasil pokok pinjaman, tenor, dan skema. Hitung dengan kerangka yang jelas, bandingkan total, dan pilih angsuran yang nyaman bagi arus kas Anda.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk meminta simulasi tertulis.
