---
title: "Promo EX5 Oktober 2026: Skema Balloon untuk SUV Keluarga"
description: "Promo EX5 Oktober 2026 untuk SUV listrik keluarga: DP kisaran Rp 40 jutaan dan balloon bunga 0%. Hitung beban pembayaran akhir yang lebih besar."
date: 2026-10-14
category: "Harga & Promo"
tags: ["promo geely ex5", "mobil listrik geely", "ev geely jakarta", "geely ev", "geely indonesia", "suv listrik keluarga", "geely ex5", "harga mobil listrik geely"]
draft: false
---

Bagi keluarga yang menimbang SUV listrik, penawaran EX5 per Oktober 2026 menarik di sisi arus kas: uang muka kisaran Rp 40 jutaan, bunga 0 persen, dan skema balloon 50:50. Namun nilai kendaraan yang lebih besar membuat porsi pembayaran akhir ikut besar. Tulisan ini mengajak Anda menghitung dari sudut pandang rumah tangga, bukan sekadar brosur.

*Penawaran dan periode dapat berubah. Data per Oktober 2026; mintalah konfirmasi tertulis dari Geely MAI. Keputusan pembiayaan ada pada perusahaan pembiayaan.*

## Gambaran singkat penawaran EX5

| Hal | Catatan |
|---|---|
| Uang muka | Kisaran Rp 40 jutaan, tergantung persetujuan |
| Bunga | 0 persen pada skema balloon yang berlaku |
| Pola bayar | 50:50, separuh dicicil, separuh dilunasi di ujung |
| Harga acuan | EX5 Pro Rp 465.000.000, EX5 Max Rp 505.000.000 (OTR Jakarta) |

Detail harga ada di [harga Geely EX5 terbaru](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/). Untuk profil modelnya, buka [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/) atau halaman [model EX5](/model/geely-ex5/).

## Mengapa skema ini relevan bagi pemilik SUV

Keluarga biasanya memiliki banyak pos pengeluaran tetap. Angsuran yang ditekan memberi ruang bernapas setiap bulan, sementara kewajiban terbesar digeser ke akhir masa kredit. Pola ini membantu bila Anda memperkirakan pendapatan naik atau punya dana yang baru cair beberapa tahun lagi.

Sebaliknya, jika pendapatan cenderung tetap dan belum ada rencana dana akhir, pergeseran ini hanya menunda tekanan. Jujurlah pada diri sendiri sebelum tergoda angsuran kecil.

## Memahami pembayaran akhir pada nilai yang besar

Pada kendaraan bernilai lebih tinggi, separuh nilai yang menjadi pembayaran akhir bukan angka kecil. Karena itu, mintalah dealer menuliskan nominalnya dalam rupiah beserta tanggal jatuh tempo, bukan hanya persentase.

Tanyakan pula pilihan di ujung masa kredit: melunasi, menukar tambah, atau opsi lain sesuai ketentuan pembiayaan saat itu. Rencana tukar tambah dibahas di [tukar tambah ke mobil listrik](/lp/tukar-tambah-ke-mobil-listrik/).

## Cara menyusun anggaran keluarga

Mulailah dari pendapatan bersih bulanan seluruh anggota yang menanggung cicilan. Kurangi kewajiban tetap seperti sekolah, tempat tinggal, dan tagihan lain. Sisa yang aman itulah batas angsuran Anda, bukan angka terbesar yang disetujui pembiayaan.

Tambahkan biaya kepemilikan: listrik untuk mengisi daya, asuransi, pajak, dan perawatan. Dasar hitungan cicilan ada di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Tentang diskon tunai

Potongan harga berubah mengikuti periode dan varian, sehingga kami tidak menetapkan angka di sini. Tanyakan lewat halaman [kontak](/kontak/) dan pastikan nilainya muncul pada dokumen penawaran bertanggal. Hindari percaya pada angka potongan yang hanya beredar sebagai gambar tanpa rincian.

## Daftar pertanyaan untuk dealer

- Berapa nominal pembayaran akhir untuk varian yang saya pilih?
- Berapa tenor dan angsuran per bulan?
- Apakah bunga 0 persen berlaku sepanjang kredit?
- Biaya apa saja di luar angsuran?
- Bolehkah saya melunasi lebih awal, dan adakah syaratnya?

Simpan jawaban tertulis agar dapat dibandingkan dengan penawaran lain.

## Pro atau Max dalam kacamata skema ini

Selisih harga antara dua varian memengaruhi uang muka, angsuran, dan pembayaran akhir sekaligus. Jangan memilih Max hanya karena angsuran terlihat kecil; pilih berdasarkan fitur yang akan benar-benar dipakai. Bantuan memilih ada di [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/).

## Langkah praktis mengambil penawaran

1. Tentukan varian dan catat batas angsuran aman Anda.
2. Minta dua simulasi tertulis: balloon dan kredit biasa.
3. Lengkapi dokumen; rujukan ada di [syarat dan dokumen kredit](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/).
4. Ikuti alur sampai serah terima di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/).

Penawaran lain tersedia di halaman [promo](/promo/).

## Diskusi keluarga sebelum tanda tangan

Bicarakan bersama: apakah penghasilan stabil beberapa tahun ke depan, dari mana dana pembayaran akhir, dan apakah akan berganti mobil di ujung kredit. Libatkan pasangan sejak awal agar keputusan tidak menjadi beban satu orang.

## Kapan sebaiknya menunda

Bila setelah dihitung pembayaran akhir terasa menakutkan, tundalah. Menabung lebih lama atau memilih varian yang lebih sederhana sering lebih bijak daripada memaksakan diri.

## Membandingkan dua skema secara adil

Buat tabel dengan kolom uang muka, tenor, angsuran, pembayaran akhir, total yang dibayar, dan biaya lain, lalu isi untuk skema balloon dan kredit biasa. Jumlahkan seluruh pembayaran sepanjang waktu, termasuk pembayaran akhir, supaya perbandingannya jujur.

Setelah angka terkumpul, tanyakan pada diri sendiri mana yang membuat tidur lebih tenang. Jawabannya sering bukan skema dengan total terendah, melainkan yang paling pas dengan arus kas keluarga Anda.

## Memeriksa keaslian penawaran

Pastikan penawaran datang dari kanal resmi dealer, bukan pesan berantai. Dokumen yang sah mencantumkan tanggal, varian, nilai, dan syarat. Tangkapan layar tanpa rincian sebaiknya dikonfirmasi ulang lewat halaman [kontak](/kontak/).

Catat juga kewajiban lain yang sedang berjalan sebelum menyetujui. Mobil seharusnya melengkapi hidup Anda, bukan menekan keuangan hingga tak tersisa ruang untuk kejutan.

## Persiapan dana akhir sejak hari pertama

Cara paling aman menghadapi pembayaran akhir adalah menyisihkan dana secara rutin sejak bulan pertama. Bagi nominal pembayaran akhir dengan jumlah bulan tenor, lalu anggap hasilnya sebagai tabungan wajib di samping angsuran. Dengan begitu, ketika jatuh tempo tiba, dananya sudah terkumpul dan Anda tidak tergantung pada keberuntungan atau keputusan terburu-buru.

Simpan dana itu di tempat terpisah yang mudah diakses tetapi tidak mudah tergoda untuk dipakai. Tinjau kembali rencana setiap enam bulan, terutama bila ada perubahan pendapatan atau kebutuhan keluarga.

## Hal yang tidak tercakup dalam angsuran

Angsuran umumnya belum termasuk biaya lain seperti asuransi, pajak tahunan, dan perawatan. Tanyakan apakah asuransi dibayar di muka atau dicicil, dan minta rinciannya tertulis. Pembahasan asuransi ada di [asuransi mobil listrik yang perlu dicek](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/). Menghitung semua komponen sejak awal mencegah kejutan di tengah masa kredit.

## Pertanyaan yang sering diajukan

### Berapa uang muka promo EX5?

Kisaran Rp 40 jutaan per Oktober 2026, mengikuti persetujuan pembiayaan.

### Apakah bunga benar-benar 0 persen?

Pada skema balloon yang berlaku menurut data kami; minta syarat tertulis.

### Apa maksud skema 50:50?

Separuh nilai dicicil, separuh dibayar di akhir. Minta simulasi tertulis.

### Apakah penawaran bisa berubah?

Ya, selalu konfirmasi sebelum memutuskan.

## Kesimpulan

Skema balloon EX5 meringankan angsuran bulanan, tetapi memindahkan beban besar ke akhir masa kredit. Hitung total, siapkan dana akhir, dan simpan semua keterangan secara tertulis.

Hubungi tim Geely MAI lewat halaman [kontak](/kontak/) untuk simulasi yang sesuai keluarga Anda.
