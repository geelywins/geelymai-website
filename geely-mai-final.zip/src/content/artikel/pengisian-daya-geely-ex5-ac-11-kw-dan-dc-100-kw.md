---
title: "Pengisian Daya Geely EX5: AC 11 kW, DC 100 kW, dan Jadwal"
description: "Pengisian daya Geely EX5 menurut brosur: AC Type-2 hingga 11 kW, DC CCS2 hingga 100 kW, jadwal pengisian, V2L dan V2V. Cara merencanakan tempat mengisi."
date: 2026-10-14
category: "Model Geely"
tags: ["pengisian daya geely ex5", "charger geely ex5", "geely ex5", "suv listrik geely", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Pengisian daya Geely EX5 menurut brosur resmi mendukung AC Type-2 hingga 11 kW dan DC CCS2 hingga 100 kW. Brosur tidak mencantumkan waktu pengisian, sehingga kami tidak menuliskan menit atau jam. Artikel ini menjelaskan arti angka tersebut dan cara merencanakan pengisian di rumah maupun di perjalanan.

## Dua jenis pengisian: AC dan DC

Pengisian AC memakai listrik bolak-balik dari stopkontak atau wallbox, dan diubah menjadi arus searah oleh pengisi di dalam mobil. Pengisian DC memberikan arus searah langsung ke baterai lewat stasiun khusus, sehingga bisa jauh lebih cepat.

Pada EX5, AC mendukung hingga 11 kW dengan konektor Type-2, dan DC hingga 100 kW dengan konektor CCS2. Angka itu adalah batas atas kemampuan mobil. Kecepatan nyata dipengaruhi kemampuan stasiun, suhu, dan kondisi baterai. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Apa arti 11 kW untuk pengisian di rumah

Mobil dapat menerima hingga 11 kW, tetapi pasokan di rumah belum tentu setinggi itu. Banyak instalasi rumah memiliki daya listrik terbatas, sehingga pengisian berjalan pada daya yang lebih rendah dan memerlukan waktu lebih lama.

Karena itu, daya listrik rumah, kabel, dan perangkat pengisi perlu dicek oleh teknisi kelistrikan yang berkompeten. Jangan memasang sendiri tanpa pengetahuan. Panduan ada di [pasang charger mobil listrik di rumah](/artikel/pasang-charger-mobil-listrik-di-rumah-daya-pln-dan-instalasi/).

## Apa arti 100 kW pada pengisian cepat

Dengan DC hingga 100 kW, EX5 dirancang menerima pengisian cepat di stasiun yang mendukung. Namun banyak stasiun memiliki daya berbeda, dan kecepatan mobil tidak akan melebihi kemampuan stasiun. Kecepatan juga biasanya menurun ketika baterai mendekati penuh.

Karena brosur tidak mencantumkan lama pengisian, jangan menghitung sendiri dengan membagi kapasitas baterai dengan daya. Hasilnya menyesatkan. Tanyakan kepada sales perkiraan waktu resmi untuk rentang pengisian yang Anda butuhkan.

## Jadwal pengisian

Brosur menyebut fitur jadwal pengisian atau scheduled charging. Fungsi ini umumnya memungkinkan Anda menentukan kapan pengisian mulai, misalnya saat tarif listrik lebih ringan atau saat Anda tidur. Detail pengaturannya tidak dijelaskan di brosur.

Minta demonstrasi dari sales: bagaimana mengatur jadwal, apakah bisa lewat aplikasi, dan apa yang terjadi bila pengisian terputus. Fitur sederhana ini dapat sangat memudahkan rutinitas harian.

## V2L dan V2V

EX5 memiliki V2L, yaitu menyalurkan listrik dari mobil ke perangkat, dan V2V, yaitu dari mobil ke mobil. Keduanya menjadikan baterai sebagai sumber daya serbaguna. Penjelasannya ada di [V2L dan V2V EX5](/artikel/v2l-dan-v2v-geely-ex5-listrik-mobil-untuk-perangkat-lain/).

Ingat bahwa menyalurkan listrik keluar memakai energi baterai yang sama dengan penggerak. Jangan menguras baterai berlebihan bila Anda masih memerlukan jarak untuk pulang.

## Rem regeneratif sebagai pelengkap

Brosur menyebut rem regeneratif, yang mengembalikan sebagian energi saat mobil melambat. Ini bukan sumber pengisian utama, tetapi membantu efisiensi, terutama di lalu lintas berhenti-jalan. Tanyakan apakah tingkat regenerasi dapat diatur.

Karena pengaruhnya bergantung gaya mengemudi, jangan mengandalkannya untuk menambah jarak secara signifikan. Anggap sebagai bonus kecil dalam rutinitas harian Anda.

## Merencanakan pengisian harian

Bagi sebagian besar pengguna kota, pola paling sederhana adalah mengisi di rumah semalam sambil memantau lewat jadwal pengisian. Pengisian cepat DC dicadangkan untuk perjalanan jauh atau situasi mendesak.

Mulailah dengan menanyakan akses Anda: apakah ada tempat parkir sendiri, bolehkah memasang wallbox, dan berapa daya listrik yang tersedia. Jawaban ini menentukan apakah EX5 nyaman dipakai. Panduan umum ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/).

## Mencari stasiun pengisian

Kami tidak mencantumkan nama atau lokasi stasiun karena datanya berubah dan belum kami verifikasi. Gunakan aplikasi peta atau aplikasi penyedia pengisian, dan periksa jenis konektor, daya, dan status ketersediaan. Pastikan stasiun mendukung CCS2 untuk DC.

Siapkan titik cadangan pada setiap perjalanan jauh. Pembahasan lanjutan ada di [EX5 untuk perjalanan jauh dan mudik](/artikel/geely-ex5-untuk-perjalanan-jauh-dan-mudik/).

## Keselamatan saat mengisi

Gunakan perangkat pengisi yang sesuai standar dan hindari kabel yang rusak atau sambungan sembarangan. Jangan mengisi di tempat basah tanpa perlindungan yang memadai. Periksa kabel dan konektor secara berkala.

Bila terdapat bau terbakar, panas berlebihan, atau percikan, hentikan pengisian dan hubungi teknisi. Keselamatan jauh lebih penting daripada menghemat waktu. Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Pengisian di apartemen dan tempat parkir bersama

Bagi penghuni apartemen, tantangan utamanya adalah izin dan infrastruktur. Tanyakan kepada pengelola apakah pemasangan pengisi diperbolehkan, siapa yang menanggung listrik, dan apakah tersedia titik pengisian bersama. Jawaban tertulis dari pengelola menghindarkan salah paham.

Jika pemasangan di tempat parkir sendiri tidak memungkinkan, cari alternatif seperti pengisi di kantor atau stasiun terdekat. Rencana ini harus ada sebelum Anda memesan, bukan sesudahnya. Baca [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

## Memantau kesehatan baterai lewat kebiasaan pengisian

Kebiasaan pengisian memengaruhi usia baterai dalam jangka panjang. Hindari seringnya membiarkan baterai terlalu kosong dan jangan terus memakai pengisian cepat jika tidak perlu. Gunakan pengisian AC di rumah sebagai kebiasaan utama.

Kami tidak memiliki rekomendasi resmi tentang batas pengisian harian untuk EX5. Tanyakan kepada sales dan ikuti petunjuk di buku manual. Kebiasaan yang konsisten lebih berharga daripada angka yang dihafal tanpa konteks.

## Menyiapkan perlengkapan pengisian

Pastikan kabel pengisi yang diterima sesuai konektor Type-2 dan periksa kondisinya saat serah terima. Simpan kabel dalam keadaan bersih dan kering di tempat yang mudah dijangkau di mobil. Tanyakan apa saja perlengkapan pengisian yang termasuk dalam paket pembelian.

## Catatan akhir sebelum memutuskan

Tuliskan jawaban Anda atas tiga hal: di mana saya akan mengisi sehari-hari, apa rencana cadangan saya, dan berapa daya listrik yang tersedia. Bila ketiganya belum jelas, selesaikan dahulu sebelum memesan.

## Pertanyaan yang sering diajukan

### Berapa lama mengisi EX5?

Brosur tidak mencantumkan waktu. Tanyakan kepada sales.

### Konektor apa yang dipakai?

Type-2 untuk AC dan CCS2 untuk DC menurut brosur.

### Apakah bisa dijadwalkan?

Brosur menyebut jadwal pengisian. Minta demonstrasi.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

EX5 mendukung AC hingga 11 kW dan DC hingga 100 kW, tetapi waktu nyata bergantung pasokan dan stasiun. Rencanakan pengisian rumah lebih dulu dan siapkan cadangan untuk perjalanan jauh.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
