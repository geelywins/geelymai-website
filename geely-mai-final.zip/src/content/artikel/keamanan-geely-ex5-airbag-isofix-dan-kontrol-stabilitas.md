---
title: "Keamanan Geely EX5: Airbag, ISOFIX, dan Kontrol Stabilitas"
description: "Keamanan Geely EX5 menurut brosur: ABS, ESC, TCS, kamera 360 derajat, ISOFIX, pre-tensioner sabuk, dan TPMS. Jumlah airbag dan rating belum kami miliki."
date: 2026-10-14
category: "Model Geely"
tags: ["keamanan geely ex5", "isofix geely ex5", "geely ex5", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Keamanan Geely EX5 menurut brosur resmi mencakup ABS, ESC, TCS, kamera 360 derajat, ISOFIX, dan sabuk pengaman dengan pre-tensioner, di antara fitur lain. Brosur tidak menyebut jumlah total airbag dan kami tidak memiliki rating keselamatan, sehingga keduanya sengaja tidak kami tuliskan. Artikel ini menjelaskan peran tiap fitur dengan bahasa sederhana.

## Keselamatan aktif dan pasif

Keselamatan aktif membantu mencegah kecelakaan, seperti rem dan kontrol stabilitas. Keselamatan pasif melindungi saat benturan terjadi, seperti sabuk dan airbag. Keduanya melengkapi, dan pengemudi yang waspada tetap lapisan terpenting.

Kami hanya menuliskan fitur yang tercantum di brosur. Bila Anda memerlukan konfirmasi untuk unit tertentu, minta daftar tertulis dari dealer. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Sistem rem dan kestabilan

Brosur menyebut ABS, ESC, TCS, BAS, EBD, dan ARP untuk anti-guling. ABS mencegah roda terkunci saat pengereman keras. ESC dan TCS membantu menjaga mobil tetap stabil saat berbelok atau di permukaan licin. Fitur ini bekerja otomatis, tetapi tidak membatalkan hukum fisika.

Brosur juga menyebut HDC untuk membantu turunan dan HAC untuk membantu di tanjakan, serta rem parkir elektrik dengan AutoHold. Fitur-fitur ini meringankan beban saat macet dan jalan menanjak.

## Airbag: apa yang kami ketahui

Brosur menyebut airbag depan, airbag samping depan, dan airbag tirai samping. Jumlah total tidak disebutkan, sehingga kami tidak menuliskan angka. Tanyakan kepada sales jumlah dan letak pasti tiap airbag, dan minta tertulis.

Ingat bahwa airbag bekerja bersama sabuk pengaman. Tanpa sabuk, efektivitas airbag menurun dan risiko cedera meningkat. Biasakan semua penumpang, termasuk yang duduk di belakang, memakai sabuk.

## Sabuk pengaman yang cerdas

Sabuk depan dilengkapi pre-tensioner dan force limiter, sedangkan jok belakang memiliki pre-tensioner. Pre-tensioner menarik sabuk lebih rapat saat benturan, dan force limiter membatasi tekanan agar tidak melukai dada. Ada pula pengingat sabuk untuk depan dan belakang.

Perhatikan pengingat itu. Sabuk yang tidak terpasang adalah kelalaian paling sederhana yang dapat dihindari. Ajarkan anak untuk memasang sabuk sendiri sejak dini.

## ISOFIX dan keselamatan anak

Brosur menyebut ISOFIX dan child anchor di jok belakang, serta kunci pengaman anak. Fitur ini memudahkan memasang kursi anak yang kokoh dan mencegah pintu belakang dibuka dari dalam.

Bawa kursi anak Anda saat mencoba dan pasang sendiri. Pastikan terpasang rapat, tidak bergoyang, dan sesuai usia serta bobot anak. Pembahasan ruang ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/).

## Kamera dan sensor parkir

Semua varian memiliki kamera 360 derajat dan sensor parkir belakang, sedangkan sensor parkir depan hanya pada Max. Fitur ini membantu menghindari benturan ringan saat bermanuver dan melihat area yang tidak terlihat dari kursi pengemudi.

Namun kamera adalah alat bantu. Tetap perhatikan spion dan sekitar, terutama bila ada anak kecil. Bersihkan lensa secara berkala agar gambar tetap jelas.

## Pemantauan ban

TPMS memantau tekanan ban dan memberi peringatan bila ada masalah. Brosur juga menyebut tire repair kit untuk penanganan awal bila ban bocor. Periksa tekanan ban secara manual berkala, karena TPMS bukan pengganti pemeriksaan rutin.

Ban dalam kondisi baik dan tekanan sesuai adalah fondasi semua fitur keselamatan lain. Ban aus mengurangi daya cengkeram dan jarak pengereman.

## Keamanan anti-pencurian dan kunci

Brosur menyebut immobiliser, alarm, kunci otomatis saat berjalan, dan tombol darurat untuk membuka bagasi dari dalam. Kunci otomatis saat berjalan mencegah pintu terbuka tanpa sengaja. Tombol darurat bagasi penting sebagai jalan keluar bila seseorang terjebak di dalamnya.

Pastikan anggota keluarga tahu fungsi ini. Pengetahuan sederhana tersebut bernilai besar dalam keadaan darurat.

## Bantuan pengemudi pada Max

Varian Max membawa rangkaian bantuan pengemudi, termasuk AEB dan peringatan tabrakan. Daftar lengkapnya dibahas di [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/). Brosur tidak menyebut istilah Level 2 untuk EX5, jadi kami tidak memakainya.

Semua bantuan ini mendukung pengemudi, bukan menggantikannya. Tetap fokus pada jalan dan siap mengambil alih.

## Hal yang kami sengaja tidak tuliskan

Kami tidak menuliskan rating keselamatan, jumlah airbag, atau hasil uji benturan, karena datanya tidak ada pada sumber kami. Bila itu penting bagi Anda, mintalah dokumen resmi dari dealer. Informasi model ada di halaman [Geely EX5](/model/geely-ex5/) dan promo di halaman [promo](/promo/).

## Kebiasaan yang menjaga fitur tetap bekerja

Fitur keselamatan bergantung pada sensor, kamera, dan sistem kelistrikan yang sehat. Ikuti jadwal servis, bersihkan lensa kamera, dan jangan menutup sensor dengan stiker. Pembahasan perawatan ada di [perawatan EX5: servis berkala dan biaya](/artikel/perawatan-geely-ex5-servis-berkala-dan-biaya/).

Setelah perbaikan bodi, pastikan sensor dipasang dan dikalibrasi di bengkel yang berwenang. Perbaikan sembarangan dapat membuat fitur bekerja tidak semestinya tanpa Anda sadari. Tanyakan prosedurnya kepada sales sebelum membutuhkannya.

## Keselamatan dalam perjalanan keluarga

Untuk perjalanan jauh, periksa tekanan ban, atur beban agar tidak melebihi kapasitas, dan pastikan semua penumpang terikat sabuk. Rencanakan istirahat berkala untuk mencegah kantuk. Bacaan lanjutan ada di [EX5 untuk perjalanan jauh dan mudik](/artikel/geely-ex5-untuk-perjalanan-jauh-dan-mudik/).

Bagi keluarga yang membawa anak, kombinasi ISOFIX, kunci pengaman anak, dan kebiasaan disiplin lebih berharga daripada fitur apa pun yang hanya dibaca di brosur. Ajak anak berlatih memasang sabuk sendiri agar kebiasaan itu terbentuk.

## Keselamatan khusus kendaraan listrik

Mobil listrik membawa baterai bertegangan tinggi. Jangan membongkar atau memodifikasi sistem kelistrikan sendiri, dan serahkan perbaikan kepada bengkel resmi. Bila terjadi benturan keras atau mobil terendam air, jangan mengisi daya dan hubungi bantuan. Pembahasan terkait ada di [mobil listrik saat banjir](/artikel/mobil-listrik-saat-banjir-aman-atau-tidak/).

## Pertanyaan yang sering diajukan

### Berapa airbag EX5?

Brosur tidak menyebut jumlah total. Tanyakan kepada sales.

### Apakah ada ISOFIX?

Ya, brosur menyebut ISOFIX dan child anchor di jok belakang.

### Apakah ada kamera 360 derajat?

Ya, pada semua varian menurut brosur.

### Apakah ada rating keselamatan?

Kami belum memiliki datanya.

## Kesimpulan

EX5 dibekali fitur keselamatan aktif dan pasif yang cukup lengkap menurut brosur, tetapi beberapa data penting belum tersedia. Minta dokumen resmi, uji langsung, dan tetap berkendara dengan waspada.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
