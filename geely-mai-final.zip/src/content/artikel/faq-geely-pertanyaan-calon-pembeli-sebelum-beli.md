---
title: "FAQ Geely: 20 Pertanyaan Calon Pembeli Sebelum Memutuskan"
description: "Jawaban singkat untuk pertanyaan calon pembeli Geely di Jakarta: model, pengisian, jarak, test drive, kredit, garansi, dan hal yang perlu dikonfirmasi tertulis."
date: 2026-10-14
category: "Panduan"
tags: ["faq geely", "pertanyaan beli geely", "geely jakarta", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah"]
draft: false
---

Berikut jawaban singkat untuk pertanyaan yang paling sering diajukan calon pembeli Geely di Jakarta. Kami menjawab sebatas data yang kami miliki dan jujur menyebut bila sesuatu perlu Anda konfirmasi tertulis ke dealer. Untuk pembahasan lebih dalam, tiap jawaban menaut ke artikel yang relevan.

## Tentang model

### Model Geely apa saja yang tersedia?

Dalam situs ini kami membahas Geely EX2 (mobil listrik kompak), Geely EX5 (SUV listrik), dan Geely Starray EM-i (SUV plug-in hybrid). Ketersediaan unit dan status pemesanan dapat berubah, jadi konfirmasi lewat halaman [kontak](/kontak/). Lihat daftar di halaman [model](/model/).

### Mana yang paling cocok untuk saya?

Tergantung kebutuhan. EX2 praktis untuk pemakaian kota, EX5 lega untuk keluarga, dan Starray cocok bagi yang masih ingin fleksibilitas bensin. Baca [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/) dan [EX5 vs Starray EM-i](/artikel/geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid/).

### Apa beda varian Pro dan Max?

Pada EX2 dan EX5, tenaga dan baterai sama. Max menambah fitur seperti bantuan pengemudi dan kenyamanan. Baca [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/) dan [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/).

## Tentang pengisian dan jarak

### Berapa jarak tempuhnya?

EX2 diklaim 395 km (NEDC), EX5 diklaim 495 km (Pro) dan 490 km (Max) pada NEDC, dan Starray EM-i diklaim 1.000+ km gabungan. Semuanya klaim laboratorium. Baca [NEDC vs WLTP](/artikel/nedc-vs-wltp-arti-jarak-tempuh-mobil-listrik/).

### Bagaimana cara mengisi dayanya?

Bisa di rumah dengan pengisian AC dan di stasiun dengan pengisian DC untuk perjalanan. Akses pengisian adalah syarat terpenting. Baca [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/).

### Bagaimana kalau tinggal di apartemen?

Tanyakan izin dan fasilitas kepada pengelola lebih dulu. Panduan ada di [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

### Berapa lama mengisi?

EX2 diklaim AC 10-100% sekitar 6,5 jam dan DC 30-80% sekitar 25 menit. Waktu EX5 tidak ada di brosur, jadi tanyakan kepada sales. Starray diklaim AC 25-100% kurang dari 3 jam dan DC 30-80% kurang dari 20 menit.

## Tentang biaya dan pembayaran

### Berapa harga dan promonya?

Harga dan promo berubah-ubah. Lihat artikel [harga Geely EX2](/artikel/harga-geely-ex2-terbaru-pro-dan-max-otr-jakarta/), [harga Geely EX5](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/), atau halaman [promo](/promo/), lalu minta penawaran tertulis.

### Bisa kredit?

Bisa melalui pembiayaan, dengan persetujuan ditentukan perusahaan pembiayaan. Pahami komponennya di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/) dan siapkan dokumen dari [syarat dan dokumen kredit](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/).

### Apakah ada biaya lain di luar harga mobil?

Ya, seperti pemasangan pengisi, asuransi, pajak, dan perawatan. Hitung dengan [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/).

## Tentang perawatan dan garansi

### Berapa garansi baterai dan mobil?

Kami tidak memiliki angka resmi untuk disebutkan. Mintalah dokumen garansi tertulis dari sales. Baca [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

### Apakah mobil listrik perlu servis?

Perlu, meski jenis pekerjaannya berbeda dari mobil bensin. Baca [perawatan mobil listrik](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/).

### Bagaimana asuransinya?

Bandingkan beberapa penawaran dan periksa cakupan baterai, kabel pengisi, dan risiko banjir. Baca [asuransi mobil listrik yang perlu dicek](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/).

## Tentang proses membeli

### Bagaimana cara test drive?

Hubungi kami, sebutkan model dan rute yang ingin dicoba, dan bawa SIM. Panduan ada di [cara test drive Geely](/artikel/cara-test-drive-geely/).

### Bagaimana alur pembelian?

Mulai dari konsultasi, test drive, penawaran, booking, pembiayaan, sampai serah terima. Baca [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/).

### Apa yang dicek saat serah terima?

Kondisi fisik, kelengkapan, fungsi fitur, dan dokumen. Baca [cek mobil baru saat serah terima](/artikel/cek-mobil-baru-saat-serah-terima-checklist-pdi/).

### Apakah boleh negosiasi?

Boleh secara wajar, dan semua kesepakatan harus tertulis. Baca [tips booking dan negosiasi](/artikel/tips-booking-dan-negosiasi-geely-ex2-max/).

## Tentang keselamatan dan penggunaan

### Bagaimana keselamatannya?

Setiap model memiliki fitur keselamatan berbeda. Kami tidak mencantumkan rating keselamatan karena datanya belum tersedia. Baca [keamanan EX2](/artikel/keamanan-geely-ex2-max-6-airbag-dan-fitur-pelindung/) dan [keamanan EX5](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/).

### Apakah aman saat banjir?

Kami tidak memiliki data uji. Hindari genangan dalam. Baca [mobil listrik saat banjir](/artikel/mobil-listrik-saat-banjir-aman-atau-tidak/).

### Apakah bebas ganjil genap?

Aturan dapat berubah. Cek aturan terbaru dari sumber resmi. Baca [mobil listrik dan ganjil genap Jakarta](/artikel/mobil-listrik-dan-ganjil-genap-jakarta/).

### Apakah baterai awet?

Tergantung jenis, suhu, dan kebiasaan pengisian. Baca [umur baterai mobil listrik LFP](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

## Cara menghubungi kami

Untuk pertanyaan yang belum terjawab, hubungi tim Geely MAI lewat halaman [kontak](/kontak/). Sebutkan model yang diminati dan kebutuhan utama Anda agar jawaban lebih relevan.

## Tentang situs dan data yang kami tulis

Artikel di situs ini disusun dari data resmi pabrikan dan data penjual per Oktober 2026. Angka jarak, pengisian, dan konsumsi adalah klaim pabrikan, bukan hasil uji jalan kami. Bila suatu informasi belum kami miliki, seperti garansi, jadwal servis, atau rating keselamatan, kami mengatakannya terus terang dan mengarahkan Anda untuk bertanya langsung.

Harga dan promo hanya kami tulis pada artikel kategori harga dan promo, selalu dengan tanggal. Di luar itu, kami tidak mencantumkan angka rupiah agar informasi tidak cepat usang. Selalu minta penawaran tertulis bertanggal sebelum memutuskan.

## Kebiasaan yang membantu semua calon pembeli

Tuliskan prioritas Anda, ukur kebutuhan harian, pastikan akses pengisian, dan minta jawaban penting secara tertulis. Libatkan keluarga dalam test drive dan jangan memutuskan karena tekanan waktu. Kebiasaan sederhana ini melindungi Anda dari keputusan yang disesali.

Bila ini mobil listrik pertama Anda, baca juga [tips memilih mobil listrik pertama](/artikel/tips-memilih-mobil-listrik-pertama/) dan [istilah mobil listrik](/artikel/istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen/). Bila Anda masih menimbang antara listrik dan hybrid, baca [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/).

## Pertanyaan yang sering diajukan

### Apakah jawaban di sini menggantikan dokumen resmi?

Tidak. Dokumen tertulis dari dealer dan pabrikan tetap menjadi rujukan utama.

### Apakah informasi di sini bisa berubah?

Ya. Harga, promo, dan ketersediaan unit dapat berubah. Konfirmasi lewat halaman [kontak](/kontak/).

### Apakah semua jawaban di sini pasti benar untuk unit saya?

Tidak selalu. Spesifikasi dapat berubah, jadi minta lembar spesifikasi terbaru yang tertulis.

### Bagaimana cara bertanya kepada tim?

Hubungi kami lewat halaman [kontak](/kontak/) dan sebutkan model serta kebutuhan Anda.

## Kesimpulan

Pertanyaan yang tepat lebih berharga daripada banyak informasi. Gunakan daftar ini sebagai titik awal, minta jawaban tertulis untuk hal penting, dan uji langsung lewat test drive.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
