---
title: "Harga EX5 Pro dan Max OTR Jakarta, Update Oktober 2026"
description: "Harga Geely EX5 per Oktober 2026 OTR Jakarta: Pro Rp 465 juta dan Max Rp 505 juta. Cara membaca selisih Rp 40 juta, hitung pokok pinjaman, dan minta penawaran."
date: 2026-10-14
category: "Harga & Promo"
tags: ["harga geely ex5", "mobil listrik geely", "ev geely jakarta", "geely ev", "geely indonesia", "suv listrik keluarga", "geely ex5", "harga mobil listrik geely"]
draft: false
---

Harga Geely EX5 per Oktober 2026 untuk wilayah Jakarta tercatat Rp 465.000.000 (Pro) dan Rp 505.000.000 (Max), keduanya OTR. Artikel ini membantu Anda membaca angka itu: apa yang sama pada kedua varian, apa yang dibeli dengan selisih Rp 40 juta, dan bagaimana meminta penawaran tertulis yang bisa Anda bandingkan.

*Harga dan promo dapat berubah tanpa pemberitahuan. Data per Oktober 2026; minta penawaran tertulis terbaru dari Geely MAI sebelum memutuskan.*

## Daftar harga per Oktober 2026

| Varian | Harga OTR Jakarta |
|---|---|
| Geely EX5 Pro | Rp 465.000.000 |
| Geely EX5 Max | Rp 505.000.000 |

Angka ini berasal dari data penjual per Oktober 2026 dan bukan jaminan harga pada hari Anda memesan. Anggap tabel sebagai titik awal diskusi, lalu minta konfirmasi tertulis bertanggal. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Apa arti OTR

OTR atau on the road berarti harga siap pakai di wilayah tertentu, sehingga sudah mencakup komponen pengurusan yang diperlukan. Komponen persisnya dapat berbeda antar penawaran, jadi minta rincian tertulis agar Anda tahu apa yang termasuk.

Karena OTR bergantung wilayah, harga Jakarta tidak otomatis berlaku di kota lain. Jika Anda berdomisili di luar Jakarta, tanyakan harga untuk wilayah Anda.

## Apa yang sama pada Pro dan Max

Menurut brosur resmi, kedua varian memakai baterai LFP 60,22 kWh, motor 160 kW, torsi 320 Nm, bagasi 461 liter, serta velg 18 inci. ISOFIX, kamera 360 derajat, dan sebagian besar fitur keselamatan juga ada pada keduanya.

Artinya, selisih harga bukan untuk tenaga atau kapasitas baterai tambahan. Spesifikasi lengkap ada di [spesifikasi EX5 Pro dan Max](/artikel/spesifikasi-lengkap-geely-ex5-pro-dan-max/).

## Apa yang dibeli dengan selisih Rp 40 juta

Selisihnya Rp 505.000.000 dikurangi Rp 465.000.000, yaitu Rp 40.000.000. Max menambah rangkaian ADAS, head-up display, sunroof panoramik, jok massage, memori jok, sensor parkir depan, dan audio 14 speaker.

Cara adil menimbangnya adalah membagi selisih dengan lama Anda berencana memakai mobil. Bila lima tahun, selisih sekitar Rp 8 juta per tahun, atau sekitar Rp 667 ribu per bulan sebagai ilustrasi aritmetika. Tanyakan apakah fitur Max bernilai sebanyak itu bagi Anda. Pembahasannya ada di [perbedaan EX5 Pro dan Max](/artikel/perbedaan-geely-ex5-pro-vs-max-mana-yang-worth-it/).

## Membayangkan uang muka dan pokok pinjaman

Sebagai latihan hitung, bila uang muka sekitar Rp 40 juta, pokok yang perlu dibiayai pada Pro sekitar Rp 425 juta dan pada Max sekitar Rp 465 juta. Ini bukan cicilan. Besar angsuran bergantung tenor, skema, dan persetujuan pembiayaan.

Gunakan angka ini hanya untuk membayangkan skala, lalu minta simulasi tertulis. Pahami komponen kredit di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Biaya di luar harga mobil

Selain harga mobil, siapkan anggaran untuk pemasangan pengisi daya di rumah, asuransi, pajak tahunan, dan perawatan. EX5 mendukung AC hingga 11 kW; pelajari kebutuhan listrik di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/).

Masukkan semua biaya itu ke satu tabel agar keputusan Anda berdasar gambaran utuh. Bandingkan juga dengan biaya mobil Anda sekarang. Perawatan dibahas di [perawatan EX5](/artikel/perawatan-geely-ex5-servis-berkala-dan-biaya/).

## Cara meminta penawaran tertulis

1. Tentukan varian yang paling mendekati kebutuhan Anda.
2. Hubungi kami lewat halaman [kontak](/kontak/) dan minta rincian harga OTR tertulis beserta tanggalnya.
3. Minta simulasi kredit sesuai uang muka dan tenor.
4. Jadwalkan test drive; panduannya ada di [cara test drive Geely](/artikel/cara-test-drive-geely/).
5. Simpan penawaran dan perhatikan masa berlakunya.

## Hal yang perlu dicek sebelum membayar

Pastikan warna dan ketersediaan unit, perkiraan waktu tunggu, perlengkapan bawaan termasuk kabel pengisi, serta ketentuan garansi. Kami tidak mencantumkan angka garansi karena belum ada data resminya; baca [harga jual kembali dan garansi EX5](/artikel/harga-jual-kembali-dan-garansi-geely-ex5/).

Tanyakan juga apa yang terjadi bila pengajuan kredit tidak disetujui dan bagaimana nasib tanda jadi Anda. Jawaban tertulis melindungi kedua pihak.

## Menilai harga dengan kepala dingin

Harga dan promo dapat berubah. Hindari memutuskan karena takut ketinggalan. Beri diri Anda satu atau dua hari setelah test drive dan setelah menerima simulasi. Tips tambahan ada di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/).

Informasi promo terkini ada di halaman [promo](/promo/). Informasi model ada di halaman [Geely EX5](/model/geely-ex5/).

## Membandingkan dengan pilihan lain

Bila Anda membandingkan dengan model lain, gunakan dasar yang sama: varian, kelengkapan, total pembayaran, dan biaya kepemilikan. Untuk opsi yang lebih kompak, lihat [harga Geely EX2](/artikel/harga-geely-ex2-terbaru-pro-dan-max-otr-jakarta/). Untuk opsi plug-in hybrid, lihat [harga Geely Starray EM-i](/artikel/harga-geely-starray-em-i-terbaru-otr-jakarta/).

Perbandingan bukan soal angka terkecil, melainkan kecocokan dengan kebutuhan Anda. Mobil yang tepat adalah yang akan Anda pakai dengan puas bertahun-tahun, bukan yang tampak termurah di tabel.

## Harga dan kesiapan pengisian di rumah

Sebelum memesan, pastikan rumah atau tempat parkir Anda siap. Pemasangan pengisi memerlukan daya listrik yang memadai dan izin pemilik tempat atau pengelola gedung. Biaya pemasangan berbeda tiap kondisi, jadi minta estimasi dari teknisi yang berkompeten.

Panduan teknis ada di [pasang charger mobil listrik di rumah](/artikel/pasang-charger-mobil-listrik-di-rumah-daya-pln-dan-instalasi/). Rencanakan paralel dengan proses pemesanan agar saat mobil tiba, Anda sudah dapat mengisi daya tanpa menunggu lama.

## Harga dan asuransi

Premi asuransi bergantung nilai kendaraan, jenis perlindungan, dan perusahaan asuransi. Kami tidak mencantumkan angka premi. Tanyakan beberapa penawaran dan perhatikan cakupan khusus kendaraan listrik, seperti baterai dan kabel pengisi. Pembahasannya ada di [asuransi mobil listrik yang perlu dicek](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/).

## Catatan untuk pembeli pertama mobil listrik

Jika ini mobil listrik pertama Anda, selain harga, pelajari dulu istilah dasar dan kebiasaan pengisian. Baca [istilah mobil listrik](/artikel/istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen/) agar Anda tidak bingung ketika sales menjelaskan spesifikasi.

## Pertanyaan yang sering diajukan

### Berapa harga Geely EX5 Pro?

Per Oktober 2026 tercatat Rp 465.000.000 OTR Jakarta. Minta penawaran tertulis terbaru.

### Berapa harga Geely EX5 Max?

Per Oktober 2026 tercatat Rp 505.000.000 OTR Jakarta.

### Apakah harga bisa berubah?

Ya, sewaktu-waktu. Konfirmasi tertulis bertanggal sebelum membayar.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Harga EX5 per Oktober 2026 adalah Rp 465 juta untuk Pro dan Rp 505 juta untuk Max (OTR Jakarta). Selisihnya membayar kelengkapan, bukan tenaga atau baterai. Minta penawaran tertulis dan putuskan dengan tenang.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk penawaran terbaru.
