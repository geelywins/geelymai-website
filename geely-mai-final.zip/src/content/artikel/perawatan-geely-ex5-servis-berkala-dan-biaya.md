---
title: "Perawatan Geely EX5: Servis Berkala dan Cara Memperkirakan Biaya"
description: "Perawatan Geely EX5: jadwal servis dan biaya belum kami miliki. Panduan kerangka pertanyaan, kebiasaan perawatan harian, dan cara menyusun anggaran perawatan."
date: 2026-10-14
category: "Perawatan"
tags: ["perawatan geely ex5", "servis berkala geely ex5", "geely ex5", "suv listrik keluarga", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Perawatan Geely EX5 umumnya lebih sederhana daripada mobil bensin dalam beberapa hal, tetapi jadwal servis dan biaya resminya belum kami miliki sehingga tidak kami tuliskan. Artikel ini memberi kerangka pertanyaan untuk sales, kebiasaan perawatan yang bisa Anda lakukan sendiri, dan cara menyusun anggaran perawatan dengan jujur.

## Mengapa kami tidak menyebut angka

Brosur EX5 tidak memuat jadwal servis atau tarif. Menebak angka berisiko menyesatkan Anda dan berpotensi merugikan. Karena itu kami hanya menyajikan hal yang dapat diverifikasi, lalu mengarahkan Anda untuk meminta jadwal resmi secara tertulis dari dealer.

Buku servis yang Anda terima saat serah terima adalah rujukan sah. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Apa yang tidak perlu dan yang tetap perlu

Mobil listrik tidak memiliki mesin pembakaran, sehingga tidak ada penggantian oli mesin atau busi. Namun rem, ban, suspensi, AC, cairan pendingin, dan sistem kelistrikan tetap memerlukan pemeriksaan. EX5 memiliki suspensi depan MacPherson dan belakang multi-link, rem cakram berventilasi di depan, serta velg 18 inci dengan ban 225/55 R18.

Karena komponen itu bekerja setiap hari, perawatan tetap penting. Pembahasan umum ada di [perawatan mobil listrik: apa yang berbeda dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/).

## Ban dan rem

Bobot EX5 yang berkisar 1.715 hingga 1.765 kg menurut brosur membuat ban bekerja cukup keras. Periksa tekanan dan kedalaman alur secara berkala, dan putar posisi ban sesuai anjuran. Ban dengan ukuran 225/55 R18 mungkin lebih mahal dari ban kecil, jadi tanyakan harga penggantian.

Rem regeneratif mengurangi keausan kampas, tetapi rem tetap perlu diperiksa. Rem parkir elektrik dengan AutoHold juga memerlukan pemeriksaan rutin. Tanyakan interval pemeriksaan rem kepada sales.

## Baterai dan pengisian

Baterai LFP 60,22 kWh adalah komponen paling mahal. Rawatlah dengan kebiasaan pengisian yang baik: hindari sering mengosongkan baterai dan gunakan pengisian AC sebagai kebiasaan utama. Pembahasan lengkap ada di [umur baterai mobil listrik LFP](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

Kami tidak memiliki rekomendasi resmi tentang batas pengisian harian untuk EX5, jadi ikuti buku manual. Garansi baterai perlu ditanyakan; baca [harga jual kembali dan garansi EX5](/artikel/harga-jual-kembali-dan-garansi-geely-ex5/).

## Perawatan sensor dan kamera

EX5 memiliki kamera 360 derajat, sensor parkir, dan pada Max serangkaian sensor ADAS. Bersihkan secara berkala, jangan menutup dengan stiker, dan jangan menyemprot air bertekanan tinggi dari jarak dekat. Setelah perbaikan bodi atau penggantian kaca, tanyakan apakah perlu kalibrasi.

Sistem ini membantu keselamatan Anda, jadi merawatnya adalah investasi. Pembahasan terkait ada di [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/).

## Filter udara dan AC

Brosur menyebut filter udara CN95 dan AC otomatis. Filter perlu diganti berkala agar kualitas udara kabin terjaga. Tanyakan interval dan biayanya. Bila kabin berbau atau pendinginan melemah, periksakan sebelum menjadi masalah besar.

Kebiasaan sederhana seperti menjaga kebersihan kabin dan tidak membiarkan makanan tumpah juga mencegah bau dan kerusakan.

## Menyusun anggaran perawatan

Tabel sederhana sudah cukup. Buat kolom: komponen, interval, perkiraan biaya (isi setelah Anda mendapat angka dari sales), dan catatan. Tambahkan pos untuk ban, asuransi, dan pajak tahunan.

Bandingkan dengan biaya perawatan mobil Anda sekarang selama setahun terakhir. Perbandingan dari catatan sendiri lebih bermakna daripada rata-rata umum. Panduannya ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/).

## Pertanyaan untuk sales

Tanyakan: berapa interval servis dan apa isinya, apakah wajib di bengkel resmi, ke mana saya harus membawa mobil, apakah ada layanan derek, dan apakah ada paket servis berkala. Minta jawaban tertulis. Tanyakan pula ketersediaan suku cadang dan perkiraan waktu perbaikan.

Bila lokasi bengkel jauh dari tempat tinggal Anda, pertimbangkan hal itu sebagai bagian dari keputusan. Kenyamanan layanan purna jual sering terasa lebih penting daripada selisih harga kecil.

## Kebiasaan harian yang membantu

Cuci mobil secara rutin, hindari parkir di bawah pohon berbuah atau tempat burung, dan periksa lampu serta wiper. Perhatikan setiap peringatan di panel instrumen 10,2 inci. Catat tanggal servis dan simpan semua bukti.

Catatan rapi membantu klaim garansi dan menambah kepercayaan calon pembeli bila Anda menjual mobil. Informasi model ada di halaman [Geely EX5](/model/geely-ex5/), dan promo terkini di halaman [promo](/promo/).

## Perawatan sebelum perjalanan jauh

Sebelum bepergian jauh, periksa tekanan ban, wiper, lampu, dan kabel pengisi. Pastikan tidak ada peringatan menyala di panel. Rencanakan titik pengisian di sepanjang rute dan simpan nomor layanan darurat dealer di ponsel.

Pemeriksaan sepuluh menit ini sering mencegah masalah merepotkan di jalan. Bila ragu terhadap kondisi mobil, singgah ke bengkel resmi sehari sebelum berangkat lebih baik daripada menunda hingga di perjalanan. Panduan perjalanan jauh ada di [EX5 untuk perjalanan jauh dan mudik](/artikel/geely-ex5-untuk-perjalanan-jauh-dan-mudik/).

## Saat mobil jarang dipakai

Mobil yang jarang dipakai tetap memerlukan perhatian pada baterai dan ban. Tanyakan kepada sales cara menyimpan mobil listrik dengan benar saat tidak dipakai beberapa pekan, termasuk tingkat pengisian yang dianjurkan. Kami tidak memiliki panduan resmi untuk EX5, sehingga tidak menyebut angka.

Jalankan mobil secara berkala agar ban tidak mengalami titik tekan tetap dan sistem tetap aktif. Cuci dan bersihkan kabin agar tidak berjamur, terutama di musim hujan. Kebiasaan sederhana ini memperpanjang usia pakai mobil.

## Perawatan di musim hujan

Musim hujan menguji wiper, ban, lampu, dan sealing pintu. Periksa kondisi wiper depan yang bersensor hujan dan wiper belakang, serta pastikan ban memiliki alur yang cukup. Genangan dalam harus dihindari; baca [mobil listrik saat banjir](/artikel/mobil-listrik-saat-banjir-aman-atau-tidak/) untuk pertimbangan keselamatan.

## Pertanyaan yang sering diajukan

### Berapa biaya servis EX5?

Kami belum memiliki angka resmi. Minta jadwal dan estimasi tertulis.

### Apakah perlu ganti oli?

Mobil listrik tidak memiliki oli mesin, tetapi komponen lain tetap diperiksa.

### Apakah harus servis di bengkel resmi?

Tanyakan ketentuan garansinya.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Perawatan EX5 berbeda dari mobil bensin, tetapi tetap perlu direncanakan. Minta jadwal dan biaya resmi secara tertulis, lalu rawat mobil dengan kebiasaan yang konsisten.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk pertanyaan seputar servis.
