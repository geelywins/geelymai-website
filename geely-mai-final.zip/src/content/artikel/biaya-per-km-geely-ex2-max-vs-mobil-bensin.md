---
title: "Biaya per Km Geely EX2 Max vs Mobil Bensin: Rumus yang Jujur"
description: "Biaya per km geely ex2 dibandingkan mobil bensin: rumus sederhana, data yang perlu Anda siapkan, dan kesalahan umum agar hitungan tidak menyesatkan."
date: 2026-10-14
category: "Kredit & Biaya"
tags: ["biaya per km geely ex2", "biaya per km mobil listrik", "geely ex2", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah"]
draft: true
---

Biaya per km Geely EX2 Max dibandingkan mobil bensin dapat Anda hitung sendiri dengan rumus sederhana: biaya energi dibagi jarak yang ditempuh, lalu ditambah biaya perawatan per km. Artikel ini memberi rumusnya, data yang perlu disiapkan, dan kesalahan umum yang membuat hitungan menyesatkan.

## Mengapa kami tidak menuliskan angka rupiah

Banyak artikel menyajikan angka seperti "hemat sekian rupiah per km". Angka semacam itu mudah basi dan sering mengabaikan perbedaan kondisi tiap orang. Tarif listrik berbeda, harga BBM berubah, dan kebiasaan mengemudi berlainan.

Karena itu, kami memberi kerangka, bukan angka. Dengan kerangka yang jelas, Anda bisa memasukkan data terbaru sendiri dan mendapat hasil yang relevan. Ini jauh lebih jujur daripada klaim penghematan yang tidak bisa Anda verifikasi.

## Rumus dasar biaya energi per km

Untuk mobil bensin, biaya energi per km adalah harga BBM per liter dibagi jarak per liter. Contoh pola: jika Anda tahu harga per liter dan berapa km yang ditempuh per liter, hasilnya biaya per km.

Untuk mobil listrik, biaya energi per km adalah tarif listrik per kWh dikalikan konsumsi kWh per km. Konsumsi bisa Anda ukur dari catatan pengisian: berapa kWh yang masuk, dibagi jarak yang ditempuh. Untuk EX2, kapasitas baterai 40,8 kWh dan klaim jarak 395 km (NEDC) hanyalah acuan awal, bukan konsumsi nyata.

## Data yang perlu Anda kumpulkan

Siapkan lima data: jarak tempuh bulanan, harga BBM yang biasa Anda beli, jarak per liter mobil Anda saat ini, tarif listrik tempat Anda mengisi, dan biaya perawatan rutin saat ini. Catat selama sebulan agar mewakili kebiasaan nyata.

Bila mengisi di rumah dan di tempat umum, pisahkan keduanya, sebab tarifnya bisa berbeda. Jangan lupa memasukkan biaya pengisian umum jika Anda memakainya. Panduan perhitungan yang lebih luas ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/).

## Biaya perawatan per km

Perawatan juga bagian dari biaya per km. Mobil listrik tidak memiliki oli mesin dan komponen pembakaran, sehingga beberapa pekerjaan servis berbeda. Namun ban, rem, dan komponen lain tetap memerlukan perhatian.

Kami tidak memiliki angka biaya servis resmi untuk dicantumkan, jadi tanyakan jadwal dan estimasi biaya kepada sales secara tertulis. Bandingkan dengan biaya servis mobil Anda sekarang. Uraian perbedaan perawatan ada di [perawatan mobil listrik: apa yang berbeda dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/).

## Biaya yang sering terlupa

Ada beberapa biaya yang sering terlewat: instalasi pengisi daya di rumah, penambahan daya listrik, asuransi, dan pajak tahunan. Pada sisi mobil bensin, ada biaya servis berkala dan penggantian suku cadang tertentu.

Untuk aturan pajak dan insentif, kami tidak menuliskan angka karena bisa berubah; cek aturan terbaru dari instansi terkait. Pembahasan umum ada di [pajak dan insentif mobil listrik untuk EX2 Max](/artikel/pajak-dan-insentif-mobil-listrik-untuk-geely-ex2-max/). Masukkan semua komponen ke hitungan agar hasilnya tidak berat sebelah.

## Contoh kerangka tabel yang bisa Anda isi

| Komponen | Mobil bensin saya | EX2 (perkiraan Anda) |
|---|---|---|
| Jarak per bulan | isi sendiri | isi sendiri |
| Biaya energi per bulan | isi sendiri | isi sendiri |
| Biaya perawatan per bulan | isi sendiri | isi sendiri |
| Biaya lain (asuransi, pajak) | isi sendiri | isi sendiri |
| Total per bulan | jumlahkan | jumlahkan |
| Biaya per km | total dibagi jarak | total dibagi jarak |

Isi kolom pertama dari catatan nyata Anda. Isi kolom kedua dengan perkiraan memakai tarif listrik Anda dan konsumsi yang Anda dapat dari test drive atau diskusi dengan sales. Dengan begitu, perbandingan lahir dari data Anda sendiri.

## Kesalahan umum yang menyesatkan

Kesalahan pertama adalah memakai klaim jarak pabrikan sebagai konsumsi nyata. Klaim NEDC dilakukan dalam kondisi standar, sedangkan jalan Jakarta penuh macet dan AC menyala. Kesalahan kedua adalah mengabaikan biaya awal, seperti instalasi pengisi daya.

Kesalahan ketiga adalah membandingkan mobil dengan kelas dan fitur yang berbeda. Bandingkan yang sepadan. Kesalahan keempat adalah terlalu optimistis tentang pola pengisian; jika Anda sering mengisi cepat di tempat umum, biaya energinya bisa berbeda dari pengisian rumah.

## Kapan hitungan ini paling berguna

Hitungan biaya per km paling berguna bila jarak harian Anda cukup panjang, karena selisih per km terakumulasi. Untuk pemakaian ringan, faktor lain seperti kenyamanan, kemudahan parkir, dan ketenangan kabin mungkin lebih menentukan.

Gunakan hasil hitungan sebagai salah satu pertimbangan, bukan satu-satunya. Pelajari juga spesifikasi lengkapnya di [spesifikasi Geely EX2 Max](/artikel/spesifikasi-lengkap-geely-ex2-max/) dan gambaran model di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Minta bantuan menghitung

Jika Anda kesulitan, tim kami dapat membantu menyusun kerangka hitungan dengan data Anda. Kami tidak akan menjanjikan hasil tertentu, melainkan membantu Anda memasukkan angka yang tepat. Lihat halaman [model EX2](/model/geely-ex2/) dan hubungi kami lewat halaman [kontak](/kontak/).

## Cara mencatat pemakaian selama sebulan

Mulailah dengan buku catatan atau aplikasi sederhana. Setiap kali Anda mengisi bahan bakar atau daya, catat tanggal, jumlah, biaya, dan angka odometer. Setelah sebulan, hitung selisih odometer sebagai jarak tempuh dan bagi biaya total dengan jarak itu.

Untuk mobil listrik yang diisi di rumah, Anda bisa memperkirakan kWh yang masuk dari indikator mobil atau dari tagihan listrik sebelum dan sesudah. Cara ini kasar tetapi cukup untuk gambaran. Semakin disiplin pencatatan Anda, semakin tepat perbandingannya.

## Peran gaya mengemudi

Gaya mengemudi sangat memengaruhi konsumsi, baik bensin maupun listrik. Akselerasi mendadak dan kecepatan tinggi meningkatkan pemakaian energi. Pada mobil listrik, rem regeneratif membantu memulihkan sebagian energi saat melambat, sehingga mengemudi halus cenderung menghasilkan hasil lebih baik.

Karena itu, jangan membandingkan hasil Anda dengan orang lain secara mentah. Dua pengemudi pada mobil yang sama bisa mendapat konsumsi berbeda. Gunakan data pribadi Anda sebagai patokan dan perbarui secara berkala.

## Pertanyaan yang sering diajukan

### Berapa biaya per km EX2?

Kami tidak menuliskan angka. Gunakan rumus dan tarif listrik Anda sendiri.

### Apakah mobil listrik selalu lebih hemat?

Tidak selalu. Hasilnya bergantung tarif, jarak, dan kebiasaan Anda.

### Apakah biaya servis lebih murah?

Beberapa komponen berbeda, tetapi kami tidak memiliki angka resmi. Tanyakan kepada sales.

### Apakah perlu memasukkan instalasi charger?

Ya, masukkan sebagai biaya awal dalam hitungan Anda.

## Kesimpulan

Biaya per km EX2 Max sebaiknya dihitung dengan data Anda sendiri, memakai rumus sederhana dan semua komponen biaya. Hindari klaim penghematan instan, dan uji pola pemakaian Anda lewat test drive.

Diskusikan hitungan Anda dengan tim Geely MAI melalui halaman [kontak](/kontak/) atau lihat halaman [promo](/promo/).
