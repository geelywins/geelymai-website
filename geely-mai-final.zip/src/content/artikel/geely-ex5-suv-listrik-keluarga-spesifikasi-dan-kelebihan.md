---
title: "Geely EX5: SUV Listrik Keluarga, Kelebihan dan Pertimbangan"
description: "Geely EX5 SUV listrik keluarga: baterai 60,22 kWh, motor 160 kW, bagasi 461 liter, ISOFIX, dan varian Pro dan Max. Kelebihan, pertimbangan, dan cara mencobanya."
date: 2026-10-14
category: "Model Geely"
tags: ["geely ex5", "suv listrik keluarga", "geely ex5 jakarta", "geely ex5 max", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Geely EX5 adalah SUV listrik lima penumpang dengan baterai LFP 60,22 kWh, motor 160 kW, dan bagasi 461 liter. Cocok bagi keluarga yang menginginkan ruang dan jangkauan lebih longgar. Artikel ini merangkum kelebihan dan pertimbangan EX5 berdasarkan brosur resmi, lalu membantu Anda menilai apakah SUV ini cocok untuk keluarga Anda.

## Gambaran singkat

EX5 berukuran panjang 4.615 mm, lebar 1.901 mm, tinggi 1.670 mm, dengan jarak sumbu roda 2.750 mm. Penggeraknya roda depan, dengan tiga mode berkendara: ECO, NORMAL, dan SPORT. Ada dua varian, Pro dan Max.

Brosur menyatakan data dapat berubah tanpa pemberitahuan, jadi anggap angka sebagai panduan dan minta konfirmasi tertulis. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/) dan informasi rinci di halaman [Geely EX5](/model/geely-ex5/).

## Kelebihan pertama: ruang untuk keluarga

Bagasi 461 liter saat kursi tegak dan 1.877 liter saat dilipat dengan pembagian 60/40. Jok belakang memiliki armrest tengah, lubang AC, dan dua port USB-C. ISOFIX dan child anchor tersedia di jok belakang.

Fitur ini membuat keluarga dengan anak kecil merasa lebih diperhatikan. Namun cobalah dengan stroller dan kursi anak Anda sendiri. Pembahasan ruang ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/).

## Kelebihan kedua: tenaga dan jangkauan

Motor 160 kW dengan torsi 320 Nm memberi akselerasi 0-100 km/jam 6,9 detik (Pro) dan 7,1 detik (Max). Klaim jarak NEDC 495 km dan 490 km, WLTP 430 km dan 425 km. Angka ini klaim laboratorium, tetapi menunjukkan ruang gerak yang lebih longgar bagi yang sering bepergian jauh.

Pembahasan jarak ada di [jarak tempuh EX5](/artikel/jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km/). Hitung kebutuhan Anda sendiri sebelum menganggap kapasitas ini perlu.

## Kelebihan ketiga: kelengkapan keselamatan

Semua varian dilengkapi ABS, ESC, TCS, kamera 360 derajat, TPMS, dan sabuk pengaman dengan pre-tensioner. Max menambah rangkaian ADAS seperti adaptive cruise control dan AEB. Jumlah total airbag tidak disebut brosur, sehingga kami tidak menuliskannya.

Pembahasan lengkap ada di [keamanan EX5](/artikel/keamanan-geely-ex5-airbag-isofix-dan-kontrol-stabilitas/) dan [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/).

## Kelebihan keempat: teknologi dan kenyamanan

Layar 15,4 inci, panel instrumen 10,2 inci, OTA, navigasi, dan V2L/V2V membuat EX5 terasa modern. Max menambah head-up display, sunroof panoramik, jok massage, dan audio 14 speaker.

Pembahasan ada di [aplikasi dan konektivitas EX5](/artikel/aplikasi-dan-konektivitas-geely-ex5-ota-navigasi-dan-flyme/) dan [kenyamanan EX5](/artikel/fitur-kenyamanan-geely-ex5-jok-ventilasi-massage-dan-hud/).

## Hal yang perlu dipertimbangkan

Pertama, ukuran lebih besar menuntut perhatian pada parkir dan manuver; radius putar minimum 5,4 meter. Kedua, waktu pengisian tidak tercantum di brosur, jadi tanyakan kepada sales. Ketiga, garansi dan jadwal servis belum kami miliki datanya.

Keempat, layar besar dengan banyak fungsi sentuh mungkin kurang cocok bagi yang menyukai tombol fisik. Kelima, nilai fitur Max bergantung kebiasaan Anda; hitung dengan jujur.

## Siapa yang cocok memilih EX5

EX5 cocok bagi keluarga yang memerlukan ruang lega, sering menempuh perjalanan antarkota, dan memiliki akses pengisian jelas. Pasangan yang menginginkan SUV dengan tenaga dan teknologi juga bisa mempertimbangkannya.

Jika Anda terutama berkendara di kota dengan parkir sempit, pertimbangkan juga [Geely EX2](/model/geely-ex2/). Perbandingannya ada di [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/).

## Siapa yang sebaiknya berpikir ulang

Jika Anda belum memiliki tempat mengisi daya sama sekali, EX5 menuntut penyesuaian besar. Jika Anda jarang membawa penumpang dan barang, ukuran SUV mungkin berlebihan. Jika ingin fleksibilitas bensin untuk perjalanan sangat jauh, lihat [Geely Starray EM-i](/model/geely-starray-em-i/) yang berjenis plug-in hybrid.

Pembahasan perbandingan dengan Starray ada di [EX5 vs Starray EM-i](/artikel/geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid/).

## Langkah berikutnya

Tulis kebutuhan keluarga Anda, ukur tempat parkir, dan periksa akses pengisian. Lalu jadwalkan test drive bersama seluruh keluarga. Persiapannya dibahas di [cara test drive Geely](/artikel/cara-test-drive-geely/).

Untuk harga dan promo terkini, lihat [harga Geely EX5](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/) dan halaman [promo](/promo/). Hubungi kami lewat halaman [kontak](/kontak/).

## Biaya kepemilikan yang perlu dihitung

Selain harga beli, hitung listrik pengisian, asuransi, pajak, ban, dan perawatan. SUV yang lebih besar dengan velg 18 inci mungkin memiliki biaya ban dan asuransi lebih besar daripada mobil kompak. Kami tidak mencantumkan angka di artikel ini; minta estimasi dari sales dan penyedia asuransi.

Panduan menghitung ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Gunakan tarif listrik rumah Anda sendiri agar hasilnya relevan, dan bandingkan dengan pengeluaran mobil Anda sekarang.

## Persiapan pengisian untuk keluarga

EX5 mendukung AC hingga 11 kW dan DC hingga 100 kW menurut brosur. Untuk pemakaian keluarga, pola paling praktis adalah mengisi di rumah semalam dan memakai DC hanya saat bepergian jauh. Tanyakan teknisi listrik tentang kemungkinan memasang pengisi di rumah Anda.

Bagi penghuni apartemen, tanyakan izin kepada pengelola lebih dulu. Panduan lengkap ada di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/) dan [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

## Perjalanan akhir pekan bersama keluarga

Dengan bagasi lega dan kabin nyaman, EX5 cocok untuk akhir pekan di luar kota. Rencanakan titik pengisian, bawa bekal, dan beri jeda untuk anak. Pembahasan perjalanan jauh ada di [EX5 untuk perjalanan jauh dan mudik](/artikel/geely-ex5-untuk-perjalanan-jauh-dan-mudik/).

Tentukan kebiasaan berkendara yang tenang. Mode ECO membantu efisiensi, sedangkan SPORT lebih responsif; pilih sesuai situasi dan jangan lupa bahwa penumpang kecil lebih nyaman dengan gerakan halus.

## Kesalahan yang sering terjadi saat memilih SUV listrik

Kesalahan umum adalah membeli ukuran terbesar demi rasa aman, lalu kesulitan memarkirnya sehari-hari. Kesalahan lain adalah mengabaikan akses pengisian. Ukur dulu tempat parkir dan pastikan Anda bisa mengisi daya dengan nyaman sebelum jatuh hati pada satu model.

## Pertanyaan yang sering diajukan

### Berapa jarak tempuh EX5?

NEDC 495 km (Pro) dan 490 km (Max); WLTP 430 km dan 425 km.

### Apakah ada ISOFIX?

Ya, brosur menyebut ISOFIX dan child anchor di jok belakang.

### Berapa kapasitas bagasi?

461 liter, hingga 1.877 liter saat dilipat.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

EX5 menawarkan ruang, tenaga, dan kelengkapan untuk keluarga, dengan beberapa data yang perlu Anda konfirmasi sendiri. Buktikan lewat test drive bersama seluruh keluarga.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
