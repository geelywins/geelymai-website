---
title: "Geely EX5 vs Starray EM-i: Listrik Murni atau Plug-in Hybrid?"
description: "Geely EX5 vs Starray EM-i: listrik murni 60,22 kWh melawan plug-in hybrid 18,4 kWh dan mesin bensin. Beda cara pakai, pengisian, bagasi, dan siapa yang cocok."
date: 2026-10-14
category: "Perbandingan"
tags: ["geely ex5 vs starray", "listrik murni atau hybrid", "geely ex5", "geely starray em-i", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Geely EX5 vs Starray EM-i bukan sekadar membandingkan dua SUV, melainkan dua cara memakai energi. EX5 adalah mobil listrik murni dengan baterai 60,22 kWh, sedangkan Starray EM-i adalah plug-in hybrid dengan baterai 18,4 kWh dan mesin bensin 1,5 liter. Artikel ini membantu Anda memilih sesuai pola hidup.

## Dua filosofi, satu keluarga SUV

Mobil listrik murni bergerak sepenuhnya dengan baterai. Plug-in hybrid memiliki baterai yang dapat diisi dari colokan dan juga mesin bensin yang dapat menjadi penggerak atau pengisi. Keduanya bisa diisi dari listrik, tetapi ketergantungan pada pengisian berbeda.

Pertanyaan utamanya: apakah hidup Anda memungkinkan mengisi daya secara konsisten, dan seberapa sering Anda menempuh jarak sangat jauh. Gambaran model ada di [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/) dan [Geely Starray EM-i Jakarta](/lp/geely-starray-em-i-jakarta/).

## Tabel perbandingan inti

| Aspek | EX5 | Starray EM-i |
|---|---|---|
| Jenis | Listrik murni | Plug-in hybrid |
| Baterai | LFP 60,22 kWh | LFP 18,4 kWh |
| Mesin bensin | Tidak ada | 1,5 liter, 73 kW |
| Motor listrik | 160 kW, 320 Nm | 160 kW, 262 Nm |
| 0-100 km/jam | 6,9 / 7,1 detik | 8,1 detik |
| Jarak klaim | NEDC 495 / 490 km | Gabungan 1.000+ km; listrik murni hingga 105 km |
| Bagasi | 461 - 1.877 liter | 528 - 2.065 liter |
| Dimensi | 4.615 x 1.901 x 1.670 mm | 4.740 x 1.905 x 1.685 mm |

Angka jarak adalah klaim NEDC, bukan hasil jalan. Data EX5 dari brosur dan data Starray dari e-flyer resmi.

## Cara mengisi energi

EX5 hanya diisi dari listrik: AC hingga 11 kW dan DC hingga 100 kW. Starray dapat diisi AC hingga 6,6 kW (25-100% kurang dari 3 jam) dan DC hingga 30 kW (30-80% kurang dari 20 menit), serta diisi bensin di pompa. Tangki Starray 51 liter.

Perbedaan ini penting. Jika Anda tidak yakin bisa mengisi daya secara konsisten, Starray memberi cadangan lewat bensin. Jika Anda yakin, EX5 menawarkan pengalaman listrik murni. Detail ada di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/) dan [cara kerja plug-in hybrid EM-i](/artikel/cara-kerja-plug-in-hybrid-geely-em-i-dan-cara-mengisi-daya/).

## Jarak dan kebebasan rute

Starray mengklaim jarak gabungan lebih dari 1.000 km dan listrik murni hingga 105 km pada NEDC. EX5 mengklaim 495 km (Pro) pada NEDC. Untuk perjalanan lintas pulau yang minim stasiun, kemampuan Starray mengisi bensin menenangkan.

Namun untuk pengguna kota yang jarak hariannya di bawah jangkauan listrik murni Starray, mobil ini bisa dipakai hampir seperti mobil listrik. Pembahasan konsumsi ada di [konsumsi BBM Starray EM-i](/artikel/konsumsi-bbm-geely-starray-em-i-dan-jarak-tempuh-1000-km/).

## Karakter berkendara

EX5 punya torsi 320 Nm dengan akselerasi 6,9 hingga 7,1 detik, lebih cepat daripada Starray yang 8,1 detik. Keheningan listrik murni juga lebih konsisten pada EX5, sedangkan Starray kadang menyalakan mesin sebagai bagian dari sistem hybrid.

Rasakan sendiri apakah suara dan transisi mesin Starray mengganggu Anda. Preferensi ini sangat pribadi dan tidak bisa ditentukan dari angka.

## Ruang dan kabin

Starray sedikit lebih besar, dengan bagasi 528 hingga 2.065 liter dibanding 461 hingga 1.877 liter pada EX5. Kedua mobil memiliki layar tengah 15,4 inci. Perbedaan ruang tidak besar, jadi nilai langsung dengan membawa barang Anda.

Pembahasan kabin EX5 ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/), dan Starray di [spesifikasi Starray EM-i](/artikel/spesifikasi-geely-starray-em-i-plug-in-hybrid/).

## Biaya energi dan perawatan

Biaya energi bergantung tarif listrik dan harga bensin, serta seberapa sering Anda mengisi dari colokan. Starray yang rajin diisi listrik akan jarang memakai bensin, sedangkan yang jarang diisi bergantung bensin. Kami tidak mencantumkan angka perbandingan.

Perawatan Starray mencakup mesin bensin, sedangkan EX5 tidak memiliki mesin pembakaran. Tanyakan jadwal servis masing-masing kepada sales. Hitung total biaya dengan [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/).

## Siapa yang cocok memilih EX5

EX5 cocok bagi Anda yang memiliki tempat mengisi daya jelas di rumah atau kantor, menyukai kesunyian dan tenaga listrik, serta jarang menempuh rute tanpa stasiun pengisian. Biaya perawatan yang berbeda dari mobil bensin juga menarik bagi sebagian orang.

Informasi model ada di halaman [Geely EX5](/model/geely-ex5/). Untuk harga lihat [harga Geely EX5](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/).

## Siapa yang cocok memilih Starray EM-i

Starray cocok bagi Anda yang ingin merasakan sebagian besar manfaat listrik tetapi masih membutuhkan fleksibilitas bensin, misalnya karena akses pengisian belum pasti atau sering menempuh rute jauh. Ia juga menarik bagi yang ragu beralih penuh ke listrik.

Informasi model ada di halaman [Geely Starray EM-i](/model/geely-starray-em-i/). Untuk harga lihat [harga Starray EM-i](/artikel/harga-geely-starray-em-i-terbaru-otr-jakarta/). Status pemesanan Starray bisa sudah berubah, jadi tanyakan kepada sales.

## Cara memutuskan

Tuliskan tiga pertanyaan: apakah saya bisa mengisi daya setiap hari, seberapa sering saya menempuh lebih dari 300 km sekali jalan, dan seberapa penting kesunyian bagi saya. Jawaban Anda akan condong ke salah satu mobil.

Lalu coba keduanya di hari yang sama. Atur jadwal lewat halaman [kontak](/kontak/) dan lihat penawaran di halaman [promo](/promo/). Panduan memilih juga ada di [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/).

## Kebiasaan yang membuat plug-in hybrid terasa benar

Manfaat Starray paling terasa bila baterainya rajin diisi. Jika Anda jarang mengisi dari colokan, mobil lebih sering memakai bensin dan keunggulan efisiensinya berkurang. Karena itu, jujurlah pada diri sendiri apakah Anda akan mengisi daya secara teratur.

Sebaliknya, EX5 menuntut kebiasaan mengisi daya yang lebih ketat. Keduanya meminta disiplin, hanya bentuknya yang berbeda: satu menuntut pengisian listrik, yang lain menuntut pengisian ganda.

## Pertanyaan yang sering diajukan

### Mana yang lebih jauh jarak totalnya?

Starray mengklaim gabungan 1.000+ km (NEDC), EX5 495 km (Pro).

### Mana yang lebih cepat?

EX5, yaitu 6,9 hingga 7,1 detik berbanding 8,1 detik pada Starray.

### Mana yang tidak memerlukan bensin?

EX5 listrik murni; Starray memakai bensin sebagai cadangan.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

EX5 unggul pada pengalaman listrik murni dan tenaga, sedangkan Starray EM-i unggul pada fleksibilitas jarak berkat mesin bensin. Pilih berdasarkan kesiapan mengisi daya dan pola perjalanan Anda.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mencoba keduanya.
