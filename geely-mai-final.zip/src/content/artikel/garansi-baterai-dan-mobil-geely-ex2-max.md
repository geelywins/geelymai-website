---
title: "Garansi Baterai dan Mobil Geely EX2 Max: Cara Menanyakannya"
description: "Garansi baterai geely ex2 belum kami cantumkan angkanya. Panduan pertanyaan, dokumen yang diminta, dan hal yang harus tertulis sebelum Anda membeli."
date: 2026-10-14
category: "Kredit & Biaya"
tags: ["garansi baterai geely ex2", "garansi mobil listrik", "geely ex2", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik kompak"]
draft: true
---

Garansi baterai Geely EX2 Max adalah hal yang wajar Anda tanyakan sebelum membeli, tetapi kami tidak mencantumkan angka tahun atau kilometer karena datanya belum ada pada sumber resmi kami. Artikel ini menyusun daftar pertanyaan dan dokumen yang perlu Anda minta secara tertulis dari dealer.

## Mengapa kami tidak menyebut angka garansi

Informasi garansi menyangkut hak dan kewajiban yang mengikat. Menyebut angka yang salah dapat merugikan Anda, dan kami tidak ingin menebak. Karena itu, kami hanya menuliskan data yang dapat kami verifikasi, dan mengarahkan Anda ke sumber resmi untuk hal yang belum kami pegang.

Sikap ini mungkin terasa kurang memuaskan, tetapi lebih jujur. Garansi yang valid adalah garansi yang tertulis pada dokumen resmi yang Anda terima, bukan pada artikel atau ucapan lisan siapa pun. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Garansi mobil dan garansi baterai itu berbeda

Pada banyak kendaraan listrik, garansi dibagi menjadi garansi kendaraan secara umum dan garansi komponen utama seperti baterai atau motor. Masing-masing bisa memiliki jangka waktu, batas jarak, dan syarat yang berlainan.

Karena itu, tanyakan keduanya secara terpisah. Jangan puas dengan jawaban "garansi lengkap" tanpa penjelasan. Mintalah rincian: komponen apa saja yang dicakup, berapa lama, dan apa yang membatalkannya. Pemahaman ini penting agar Anda tidak kaget saat membutuhkan klaim.

## Pertanyaan yang sebaiknya diajukan

Siapkan daftar berikut. Berapa lama garansi kendaraan dan garansi baterai? Apakah ada batas jarak tempuh? Komponen apa saja yang dicakup dan dikecualikan? Apakah ada syarat servis berkala di bengkel resmi agar garansi tetap berlaku?

Tanyakan juga: bagaimana prosedur klaim, ke mana harus datang, dan berapa lama prosesnya? Apakah garansi berpindah bila mobil dijual ke pihak lain? Catat jawaban beserta nama dan tanggalnya. Catatan ini akan sangat berguna bila terjadi perbedaan pemahaman.

## Dokumen yang perlu diminta

Mintalah dokumen garansi tertulis, yang biasanya berupa buku garansi atau lampiran resmi. Baca bagian pengecualian dengan teliti, sebab di sanalah biasanya terdapat hal yang sering luput: pemakaian komersial, modifikasi, atau kelalaian perawatan.

Simpan salinan dokumen di tempat aman dan foto setiap halaman penting. Bila ada hal yang tidak Anda pahami, minta penjelasan sebelum menandatangani. Jangan tertekan oleh waktu; hak Anda untuk memahami isi dokumen tidak berbatas oleh promo apa pun.

## Hubungan garansi dengan servis berkala

Garansi biasanya mensyaratkan servis berkala di bengkel resmi sesuai jadwal. Melewatkan servis bisa memengaruhi keberlakuan garansi. Karena itu, tanyakan jadwal servis dan catat tanggalnya sejak mobil dibeli.

Kami belum memiliki data jadwal dan biaya servis EX2 untuk dicantumkan. Pembahasan umum ada di [perawatan Geely EX2 Max: servis berkala dan biaya](/artikel/perawatan-geely-ex2-max-servis-berkala-dan-biaya/). Tanyakan jadwal resmi kepada sales dan simpan jawabannya.

## Baterai: apa yang perlu Anda ketahui

Baterai EX2 memakai teknologi LFP 40,8 kWh. Kapasitas baterai dapat menurun seiring waktu karena pemakaian, suhu, dan pola pengisian. Karena itu, penting mengetahui apakah garansi baterai mencakup penurunan kapasitas dan pada ambang berapa.

Pertanyaan ini sering menentukan bagi calon pembeli, tetapi jawabannya harus datang dari dokumen resmi. Pembahasan sifat baterai ada di [baterai LFP 40,8 kWh EX2 Max](/artikel/baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama/) dan perawatan umum di [umur baterai mobil listrik LFP dan cara merawatnya](/artikel/umur-baterai-mobil-listrik-lfp-dan-cara-merawatnya/).

## Garansi dan nilai jual kembali

Calon pembeli sering mengaitkan garansi dengan harga jual kembali. Memang, sisa garansi bisa menjadi pertimbangan pembeli berikutnya. Namun kami tidak memiliki data pasar untuk menyatakan pengaruhnya.

Pembahasan umum tentang nilai jual kembali ada di [nilai jual kembali mobil listrik: mitos dan faktanya](/artikel/nilai-jual-kembali-mobil-listrik-mitos-dan-faktanya/). Gunakan sebagai bahan berpikir, bukan sebagai jaminan angka.

## Tips agar tidak salah paham

Jangan mengandalkan janji lisan. Setiap hal yang dijanjikan harus tertulis. Jangan menandatangani dokumen yang kosong atau belum Anda baca. Bandingkan juga dokumen garansi antar merek bila Anda sedang menimbang beberapa pilihan.

Bila ada kata yang terdengar teknis, minta contoh. Misalnya, "pemakaian wajar" itu seperti apa? Jawaban konkret mencegah perselisihan di kemudian hari. Tim kami berusaha menjelaskan sejelas mungkin, dan bila belum tahu, kami akan mengonfirmasi dulu.

## Langkah selanjutnya

Siapkan daftar pertanyaan di atas dan bawa saat berkunjung. Sampaikan bahwa Anda ingin jawaban tertulis. Lihat halaman [Geely EX2](/model/geely-ex2/) untuk informasi model, dan hubungi kami lewat halaman [kontak](/kontak/) untuk membuat janji.

## Contoh percakapan yang baik dengan sales

Anda bisa membuka dengan kalimat sederhana: "Saya ingin tahu ketentuan garansi kendaraan dan baterai, mohon dijelaskan dan diberikan secara tertulis." Lalu lanjutkan dengan pertanyaan spesifik tentang jangka waktu, batas jarak, dan pengecualian. Bila jawabannya tidak jelas, minta sales mengonfirmasi ke pihak terkait dan menghubungi Anda kembali.

Sikap yang tenang dan terstruktur biasanya mendapat tanggapan yang lebih baik. Tidak perlu curiga berlebihan, cukup teliti. Dealer yang baik akan menghargai pembeli yang memahami haknya dan akan membantu menjelaskan sampai Anda paham.

## Tanda yang perlu diwaspadai

Waspadai jawaban yang terlalu umum, janji yang tidak mau dituliskan, atau tekanan untuk segera memutuskan sebelum Anda membaca dokumen. Waspadai pula klaim garansi yang terdengar jauh lebih menguntungkan dibanding yang lain tanpa dasar tertulis.

Bila menemukan hal seperti itu, tunda keputusan dan konfirmasi ulang. Mobil adalah pembelian besar, dan waktu beberapa hari untuk memastikan jauh lebih murah daripada penyesalan bertahun-tahun.

## Pertanyaan yang sering diajukan

### Berapa garansi baterai EX2 Max?

Kami tidak memiliki angka resmi. Mintalah dokumen garansi tertulis dari sales.

### Apakah garansi mencakup penurunan kapasitas baterai?

Tanyakan secara spesifik dan minta jawaban tertulis.

### Apakah servis harus di bengkel resmi?

Biasanya garansi mensyaratkannya. Konfirmasikan ketentuannya.

### Apakah garansi berpindah saat mobil dijual?

Tanyakan kepada sales dan minta penjelasan tertulis.

## Kesimpulan

Garansi baterai dan mobil EX2 Max perlu Anda pastikan lewat dokumen resmi, bukan lewat angka yang beredar. Siapkan pertanyaan, minta jawaban tertulis, dan simpan semua dokumen dengan baik.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) atau lihat penawaran di halaman [promo](/promo/).
