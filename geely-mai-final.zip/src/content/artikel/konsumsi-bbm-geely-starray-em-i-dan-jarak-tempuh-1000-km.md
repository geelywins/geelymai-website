---
title: "Konsumsi BBM Geely Starray EM-i dan Klaim Jarak 1.000 km"
description: "Konsumsi BBM Starray EM-i klaim NEDC 0,5 L/100 km baterai penuh dan 1,2 L/100 km rata-rata. Cara membaca angka, faktor yang memengaruhi, dan kebiasaan hemat."
date: 2026-10-14
category: "Model Geely"
tags: ["konsumsi bbm geely starray", "jarak tempuh 1000 km", "geely starray em-i", "suv hybrid geely", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Konsumsi BBM Geely Starray EM-i menurut klaim NEDC pada e-flyer resmi adalah 0,5 L/100 km saat baterai penuh, rata-rata tertimbang 1,2 L/100 km, dan 4,3 L/100 km saat baterai rendah, dengan jarak gabungan 1.000+ km. Artikel ini membantu Anda membaca angka tersebut secara wajar dan memahami faktor yang membuat hasil nyata berbeda.

## Angka klaim dari flyer

Flyer menyebut jarak gabungan 1.000+ km, jarak listrik murni hingga 105 km, konsumsi 0,5 L/100 km pada baterai penuh, rata-rata tertimbang 1,2 L/100 km (setara hingga 83 km/L), dan 4,3 L/100 km pada baterai rendah. Semua berdasar NEDC.

Flyer menegaskan angka konsumsi untuk perbandingan dan bisa berbeda di jalan nyata. Karena itu anggap angka ini sebagai pembanding antarmobil, bukan janji hasil harian. Gambaran model ada di [Geely Starray EM-i Jakarta](/lp/geely-starray-em-i-jakarta/).

## Mengapa ada tiga angka

Mobil plug-in hybrid bekerja berbeda tergantung kondisi baterai. Saat baterai penuh, motor listrik bekerja lebih banyak dan mesin bensin sedikit sekali, sehingga konsumsi sangat rendah. Saat baterai rendah, mesin lebih sering bekerja, sehingga konsumsi naik.

Rata-rata tertimbang adalah gabungan keduanya menurut prosedur pengujian. Hasil Anda sangat bergantung seberapa sering Anda mengisi baterai dari colokan. Pembahasan cara kerja ada di [cara kerja plug-in hybrid EM-i](/artikel/cara-kerja-plug-in-hybrid-geely-em-i-dan-cara-mengisi-daya/).

## Jarak listrik murni hingga 105 km

Klaim jarak listrik murni hingga 105 km (NEDC) berarti dalam kondisi ideal mobil dapat menempuh jarak itu tanpa mesin bensin. Bagi banyak pengguna kota, jarak harian berada di bawah angka tersebut, sehingga mobil bisa dipakai hampir seperti mobil listrik.

Di jalan nyata, kecepatan tinggi, AC, dan beban mengurangi jarak itu. Catat jarak harian Anda sebelum menilai apakah listrik murni akan menutup kebutuhan harian.

## Jarak gabungan 1.000+ km

Angka 1.000+ km berasal dari gabungan baterai dan tangki 51 liter. Ini menggambarkan jangkauan total tanpa perlu berhenti lama untuk mengisi. Bagi perjalanan jauh, itu keunggulan besar dibanding mobil listrik murni.

Namun jarak total yang besar tidak berarti Anda selalu hemat. Hasil tergantung kombinasi pengisian baterai dan bensin sepanjang perjalanan. Rencanakan pengisian bensin seperti biasa dan manfaatkan colokan saat tersedia.

## Faktor yang memengaruhi konsumsi nyata

Kecepatan tinggi menaikkan konsumsi karena hambatan udara. AC menambah beban. Muatan penuh menambah bobot. Gaya mengemudi agresif lebih boros daripada laju halus. Kondisi macet bisa menguntungkan atau merugikan tergantung seberapa sering mobil berhenti dan berjalan.

Yang paling berpengaruh adalah kebiasaan mengisi baterai. Mobil yang selalu berangkat dengan baterai penuh akan jauh lebih irit daripada yang selalu berangkat dengan baterai rendah.

## Kebiasaan yang membantu menghemat

Isi baterai dari colokan secara teratur, terutama semalam di rumah. Jaga kecepatan stabil, antisipasi lalu lintas, dan pakai mode sesuai kebutuhan. Pelajari bagaimana mode Pure, Hybrid, dan Power bekerja pada unit yang Anda coba.

Periksa tekanan ban dan kurangi beban yang tidak perlu. Kebiasaan kecil ini membuat perbedaan nyata seiring waktu, tanpa mengubah cara hidup Anda.

## Menghitung biaya energi Anda sendiri

Biaya sebenarnya adalah gabungan listrik dari colokan dan bensin dari pompa. Catat berapa kilometer per pekan yang ditempuh dengan listrik dan dengan bensin. Kalikan dengan tarif listrik rumah dan harga bensin yang Anda pakai.

Panduan lengkap ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Kami tidak mencantumkan angka rupiah karena harga energi berubah-ubah.

## Perbandingan dengan mobil listrik murni

Mobil listrik murni tidak memakai bensin sama sekali tetapi bergantung pengisian. Starray memberi fleksibilitas bensin untuk rute jauh. Perbandingan lengkap ada di [EX5 vs Starray EM-i](/artikel/geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid/).

Pilih sesuai pola hidup: jika Anda disiplin mengisi daya, keunggulan hybrid semakin terasa. Jika tidak, manfaatnya mengecil. Informasi model ada di halaman [Geely Starray EM-i](/model/geely-starray-em-i/).

## Uji saat test drive

Tanyakan kepada sales cara membaca tampilan konsumsi dan persentase baterai. Coba setiap mode dan perhatikan kapan mesin bensin menyala. Bila memungkinkan, ulangi rute harian Anda untuk membandingkan.

Atur jadwal lewat halaman [kontak](/kontak/) dan lihat penawaran di halaman [promo](/promo/). Ingat bahwa flyer bertuliskan "PRE-BOOK NOW", jadi status pemesanan perlu dikonfirmasi.

## Contoh tiga pola pemakaian

Pengguna kota yang mengisi baterai setiap malam dan menempuh jarak pendek mungkin hampir tidak memakai bensin pada hari biasa. Konsumsi bensinnya akan jauh lebih rendah dari rata-rata klaim, sedangkan listrik rumah menjadi biaya utamanya.

Pengguna yang jarang mengisi dari colokan akan lebih sering mengandalkan bensin, sehingga konsumsinya mendekati angka saat baterai rendah. Pengguna perjalanan jauh akan mengalami campuran: awal perjalanan lebih hemat, lalu sisa jarak lebih bergantung bensin.

Gambaran ini hanya cara berpikir, bukan hasil pengukuran. Kami tidak memiliki data jalan nyata, sehingga tidak menuliskan angka perkiraan untuk pola-pola itu.

## Kesalahan membaca angka konsumsi

Kesalahan pertama adalah menganggap 1,2 L/100 km sebagai angka yang selalu tercapai. Kesalahan kedua adalah membandingkan angka dengan mobil bensin biasa tanpa memperhitungkan biaya listrik pengisian. Kesalahan ketiga adalah lupa bahwa baterai kecil cepat habis pada kecepatan tinggi.

Hindari semuanya dengan mencatat konsumsi sendiri setelah beberapa minggu dan memasukkan biaya listrik ke hitungan. Dengan begitu perbandingan Anda adil dan hasilnya relevan untuk keputusan pembelian maupun kebiasaan harian.

## Catatan akhir

Bila efisiensi adalah alasan utama Anda melirik Starray, ukur dulu jarak harian dan akses colokan di rumah. Dua hal itu menentukan lebih banyak daripada angka klaim mana pun.

## Pertanyaan yang sering diajukan

### Berapa konsumsi BBM Starray EM-i?

Klaim NEDC rata-rata tertimbang 1,2 L/100 km. Hasil nyata bisa berbeda.

### Apakah benar bisa 1.000 km?

Klaim jarak gabungan NEDC adalah 1.000+ km.

### Berapa jarak listrik murni?

Klaim hingga 105 km (NEDC).

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Klaim konsumsi Starray EM-i menarik, namun hasil nyata sangat bergantung kebiasaan mengisi baterai dari colokan. Gunakan angka sebagai pembanding dan hitung dari kebiasaan Anda sendiri.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
