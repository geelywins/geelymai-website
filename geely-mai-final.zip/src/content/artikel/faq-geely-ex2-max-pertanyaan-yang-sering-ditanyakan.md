---
title: "FAQ Geely EX2 Max: Jawaban untuk Pertanyaan Calon Pembeli"
description: "FAQ Geely EX2 Max: jawaban jujur seputar baterai, jarak tempuh, pengisian, bagasi, keselamatan, dan varian, termasuk hal yang perlu Anda tanyakan ke sales."
date: 2026-10-14
category: "Model Geely"
tags: ["faq geely ex2 max", "geely ex2 max", "geely ex2", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik kompak"]
draft: true
---

FAQ Geely EX2 Max ini mengumpulkan pertanyaan yang paling sering diajukan calon pembeli, dari baterai dan jarak tempuh sampai bagasi dan keselamatan. Jawaban memakai data resmi yang kami pegang. Untuk hal yang belum ada datanya, kami menyebutnya terus terang dan menyarankan Anda bertanya langsung kepada sales.

## Cara membaca daftar ini

Pertanyaan kami kelompokkan menurut topik supaya mudah dicari. Setiap jawaban singkat dan diikuti tautan ke artikel yang lebih lengkap. Angka jarak, pengisian, dan akselerasi adalah klaim pabrikan, jadi hasil Anda dapat berbeda sesuai kondisi.

Bila Anda baru mengenal model ini, mulailah dari halaman [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/) untuk gambaran besar, lalu kembali ke sini untuk pertanyaan yang lebih rinci. Kami terus memperbarui daftar ini bila ada informasi baru yang terverifikasi.

## Pertanyaan seputar baterai dan jarak

**Berapa kapasitas baterainya?** Baterai LFP 40,8 kWh. **Berapa klaim jaraknya?** 395 km menurut metode NEDC. Angka ini diukur pada kondisi standar, sehingga pemakaian nyata di jalan padat atau dengan AC menyala bisa berbeda.

**Apakah baterainya aman?** LFP dikenal stabil secara termal, namun keselamatan juga ditentukan sistem lain. Kami tidak menjanjikan hasil tertentu. Penjelasan lengkap ada di [baterai LFP 40,8 kWh EX2 Max](/artikel/baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama/), dan pembahasan klaim jarak ada di [jarak tempuh EX2 Max: klaim vs pemakaian harian](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/).

## Pertanyaan seputar pengisian daya

**Berapa lama mengisi?** Klaim pabrikan: AC 10-100% sekitar 6,5 jam, dan DC 30-80% sekitar 25 menit. **Bisakah mengisi di rumah?** Bisa, asalkan Anda memiliki tempat dan instalasi yang sesuai. Konsultasikan kebutuhan daya kepada PLN dan teknisi.

Untuk panduan praktis, baca [cara mengisi daya Geely EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/) dan [pengisian cepat DC EX2 Max](/artikel/pengisian-cepat-dc-geely-ex2-max-30-80-persen-25-menit/). Jika Anda tinggal di apartemen, lihat [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

## Pertanyaan seputar ukuran dan ruang

**Berapa bagasinya?** 375 liter, hingga 1.320 liter dengan jok dilipat, plus frunk 70 liter. **Berapa penumpangnya?** Lima orang. **Berapa dimensinya?** Dimensi resmi belum tersedia pada data kami, jadi tanyakan kepada sales.

Cara terbaik menilai kecukupan ruang adalah mencobanya dengan barang bawaan Anda. Contoh pemakaian bagasi ada di [bagasi 375 liter dan frunk 70 liter EX2](/artikel/bagasi-375-liter-dan-frunk-70-liter-geely-ex2-muat-apa-saja/).

## Pertanyaan seputar tenaga dan berkendara

**Berapa tenaganya?** Motor 85 kW dengan torsi 150 Nm. **Seberapa cepat?** Perkiraan 0-100 km/jam sekitar 11,5 detik, sehingga cocok untuk berkendara harian yang tenang. **Bagaimana suspensinya?** Depan MacPherson dan belakang multi-link, dengan velg 16 inci.

Karakter berkendara di jalan padat dibahas di [EX2 Max di macet Jakarta](/artikel/geely-ex2-max-di-macet-jakarta/). Untuk pemula, baca [EX2 Max mudah dikendarai untuk pemula dan wanita](/artikel/geely-ex2-max-mudah-dikendarai-untuk-pemula-dan-wanita/).

## Pertanyaan seputar fitur dan teknologi

**Apa ukuran layarnya?** Layar tengah 14,6 inci dan panel instrumen 8,8 inci. **Apa saja fitur varian Max?** Varian Max menambah velg, jok, kamera 540 derajat, ADAS Level 2, V2L, dan kontrol lewat aplikasi dibandingkan Pro.

Rincian setiap fitur ada di artikel masing-masing, misalnya [kamera 540 derajat](/artikel/kamera-540-derajat-geely-ex2-max-membantu-parkir/) dan [fitur ADAS EX2 Max](/artikel/fitur-adas-geely-ex2-max-apa-saja-dan-cara-kerjanya/). Perbandingan lengkap varian ada di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Pertanyaan seputar keselamatan

**Berapa airbag-nya?** Enam airbag. **Apakah ada rating keselamatan?** Kami tidak memiliki data rating, sehingga tidak mencantumkannya. Bila rating penting bagi Anda, periksa sumber resmi dan tanyakan kepada sales.

Pembahasan fitur pelindung ada di [keamanan EX2 Max: 6 airbag dan fitur pelindung](/artikel/keamanan-geely-ex2-max-6-airbag-dan-fitur-pelindung/). Keselamatan juga bergantung pada kebiasaan mengemudi, jadi tetap patuhi aturan dan jangan terlalu mengandalkan fitur bantuan.

## Pertanyaan seputar garansi, pajak, dan harga

**Berapa garansinya?** Kami tidak memiliki angka garansi, jadi mintalah ketentuan tertulis dari sales. **Bagaimana pajak dan insentifnya?** Aturan bisa berubah; cek ketentuan terbaru dari instansi terkait. **Berapa harganya?** Harga dan promo berubah-ubah; lihat halaman [promo](/promo/) atau minta penawaran tertulis.

Artikel terkait: [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/) dan [pajak dan insentif mobil listrik](/artikel/pajak-dan-insentif-mobil-listrik-untuk-geely-ex2-max/). Kami memilih jujur menyebut keterbatasan data daripada memberi angka yang tidak bisa dipertanggungjawabkan.

## Pertanyaan seputar membeli dan mencoba

**Bagaimana cara test drive?** Hubungi kami lewat halaman [kontak](/kontak/), sebutkan model dan jam yang Anda inginkan. **Apakah bisa kredit?** Skema pembiayaan tersedia dan tetap mengikuti persetujuan lembaga pembiayaan; baca [simulasi cicilan EX2 Max](/artikel/simulasi-cicilan-geely-ex2-max-dp-dan-tenor/).

**Bagaimana alur membelinya?** Dari konsultasi sampai serah terima, dijelaskan di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/). Model dapat dilihat di halaman [Geely EX2](/model/geely-ex2/), dan dealer berada di [Geely MAI Jakarta](/lokasi/geely-mai-jakarta/).

## Hal yang sebaiknya Anda tanyakan sendiri

Beberapa hal tidak bisa kami jawab dari data yang ada: jadwal servis, biaya perawatan, ketentuan garansi, dan ketersediaan unit. Siapkan daftar pertanyaan dan minta jawaban tertulis. Catat tanggal dan nama orang yang menjawab untuk menghindari salah paham di kemudian hari.

Bila Anda merasa ada informasi yang tidak sejalan dengan yang tertulis di sini, tanyakan ulang. Kami lebih memilih Anda bertanya dua kali daripada memutuskan berdasarkan asumsi. Pertanyaan baru dari Anda juga membantu kami memperkaya daftar ini.

## Mitos dan kesalahpahaman yang sering muncul

Beberapa kesalahpahaman sering kami dengar. Ada yang mengira jarak klaim pasti tercapai di jalan, padahal itu hasil pengujian standar. Ada yang mengira mobil listrik tidak butuh perawatan sama sekali, padahal komponen seperti ban, rem, dan suspensi tetap perlu diperiksa. Ada pula yang mengira semua fitur ada di semua varian, padahal Pro dan Max berbeda perlengkapan.

Menghadapi kesalahpahaman semacam itu, sikap terbaik adalah memeriksa ulang ke sumber resmi dan mencoba sendiri. Jangan ragu menanyakan hal yang tampak sepele, sebab pertanyaan sederhana sering membuka informasi yang berguna. Kami lebih senang menjawab seratus pertanyaan daripada melihat Anda kecewa karena asumsi yang keliru.

## Cara memanfaatkan FAQ ini sebelum datang ke dealer

Cetak atau simpan daftar ini, lalu tandai pertanyaan yang paling penting bagi Anda. Tambahkan pertanyaan pribadi, seperti kondisi tempat parkir atau kebutuhan anggota keluarga. Dengan daftar yang disiapkan, kunjungan Anda lebih efisien dan Anda tidak lupa menanyakan hal penting.

## Pertanyaan yang sering diajukan

### Apakah EX2 Max cocok untuk pemula?

Banyak pemula cepat beradaptasi karena tanpa perpindahan gigi, tetapi cobalah langsung.

### Apakah klaim 395 km pasti tercapai?

Itu klaim NEDC. Pemakaian nyata bisa berbeda.

### Apakah harga ditulis di sini?

Tidak. Harga dan promo berubah, jadi minta penawaran tertulis.

### Bagaimana cara bertanya lebih lanjut?

Hubungi kami lewat halaman [kontak](/kontak/).

## Kesimpulan

FAQ ini merangkum jawaban yang paling sering dibutuhkan calon pembeli EX2 Max, dengan data resmi dan penjelasan jujur tentang batasnya. Gunakan sebagai titik awal, lalu uji sendiri lewat test drive.

Hubungi tim Geely MAI lewat halaman [kontak](/kontak/) untuk pertanyaan yang belum terjawab di sini.
