---
title: "Jarak Tempuh Geely EX2 395 km: Cara Membaca Angkanya"
description: "Jarak tempuh Geely EX2 diklaim 395 km (NEDC). Pahami artinya, mengapa hasil nyata berbeda, dan cara mencatat kebutuhan harian Anda sebelum memutuskan."
date: 2026-10-14
category: "Model Geely"
tags: ["jarak tempuh geely ex2", "jarak tempuh mobil listrik", "geely ex2 max", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik kompak"]
draft: true
---

Jarak tempuh Geely EX2 diklaim 395 km menurut siklus NEDC. Angka itu berguna sebagai pembanding, tetapi bukan janji untuk jalan Jakarta. Artikel ini membantu Anda membaca angka tersebut dengan benar, memahami faktor yang menggesernya, dan mengukur kebutuhan harian sendiri sebelum menilai apakah mobil ini cukup.

## Dari mana angka 395 km berasal

NEDC adalah prosedur pengujian laboratorium yang dijalankan dalam kondisi terkontrol: kecepatan mengikuti pola tertentu, suhu stabil, dan tidak ada hambatan lalu lintas. Hasilnya dipakai untuk membandingkan satu mobil dengan mobil lain pada standar yang sama.

Karena itu 395 km adalah klaim pabrikan, bukan hasil perjalanan nyata. Jalan raya punya tanjakan, lampu merah, hujan, dan penumpang yang berbeda-beda. Menganggap angka laboratorium sebagai jatah harian adalah kesalahan yang paling sering dilakukan calon pembeli. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/).

## Kapasitas baterai sebagai dasar hitungan

EX2 memakai baterai LFP 40,8 kWh. Jarak yang dapat ditempuh pada akhirnya adalah hasil pembagian energi tersimpan dengan energi yang dipakai per kilometer. Energi per kilometer itulah yang berubah-ubah mengikuti cara Anda berkendara dan kondisi jalan.

Dengan memahami dasar ini, Anda tidak perlu terpaku pada satu angka. Cukup ingat bahwa jarak adalah hasil dua hal: isi baterai dan kebiasaan pemakaian. Bila salah satu berubah, hasilnya ikut berubah. Pembahasan baterai ada di [baterai LFP 40,8 kWh EX2 Max](/artikel/baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama/).

## Faktor yang menggeser jarak nyata

Beberapa hal yang umumnya memengaruhi pemakaian energi mobil listrik:

- Kecepatan. Semakin tinggi kecepatan, hambatan udara bertambah dan energi terpakai lebih banyak.
- AC. Pendingin kabin memakai energi dari baterai yang sama dengan penggerak.
- Beban. Penumpang dan barang menambah bobot yang harus digerakkan.
- Gaya mengemudi. Akselerasi mendadak lebih boros dibanding laju halus.
- Kondisi jalan. Tanjakan menambah pemakaian, sedangkan turunan dan pengereman halus dapat mengembalikan sebagian energi.
- Tekanan ban. Ban kurang angin meningkatkan hambatan gelinding.

Kami tidak memiliki data pengukuran EX2 di jalan nyata, sehingga kami tidak menyebut angka pemakaian sebenarnya. Yang dapat kami berikan adalah kerangka untuk menilainya sendiri.

## Cara mencatat kebutuhan harian Anda

Sebelum membeli, catat jarak harian selama dua minggu. Gunakan odometer mobil Anda sekarang, atau aplikasi peta. Tuliskan jarak pergi-pulang kantor, antar anak, belanja, dan acara akhir pekan.

Setelah dua minggu, lihat tiga angka: rata-rata harian, hari terjauh, dan frekuensi hari terjauh itu. Bila rata-rata Anda jauh di bawah klaim dan hari terjauh masih dalam jangkauan wajar, kemungkinan EX2 cukup. Bila hari terjauh sering muncul, rencanakan pengisian tambahan.

## Menyisakan cadangan yang aman

Kebiasaan sehat pada mobil listrik adalah tidak mengosongkan baterai. Sisakan cadangan agar Anda punya pilihan bila terjebak macet atau rute berubah. Banyak pengguna menetapkan batas pribadi, misalnya mengisi ulang sebelum persentase turun terlalu rendah.

Batas ini bersifat pribadi, jadi tentukan sendiri berdasarkan kenyamanan Anda dan akses ke tempat pengisian. Prinsipnya sederhana: lebih baik mengisi lebih awal daripada khawatir di jalan.

## Membaca angka jarak di layar mobil

Layar mobil biasanya menampilkan perkiraan sisa jarak. Angka ini diperkirakan dari gaya mengemudi terakhir, sehingga bisa naik atau turun mendadak. Misalnya, setelah menuruni jalan layang, estimasi bisa terlihat lebih baik; setelah menyalakan AC penuh, estimasi bisa turun.

Perlakukan angka itu sebagai petunjuk, bukan fakta. Persentase baterai lebih stabil sebagai acuan. Biasakan memantau keduanya, dan percayai kebiasaan Anda setelah beberapa minggu memakai mobil.

## Tiga tipe pengguna dan kebutuhan jaraknya

Pengguna kota dengan perjalanan pendek biasanya memakai sebagian kecil dari kapasitas per hari dan cukup mengisi semalam di rumah. Pekerja dengan jarak tempuh sedang mungkin perlu mengisi lebih sering, tetapi tetap nyaman bila ada colokan di kantor.

Pengguna yang sering ke luar kota perlu merencanakan pemberhentian pengisian. Pengisian DC 30-80% sekitar 25 menit membantu, namun ketersediaan titik pengisian harus Anda cek sendiri sebelum berangkat. Pembahasan perjalanan jauh ada di [mudik dan perjalanan jauh dengan EX2 Max](/artikel/mudik-dan-perjalanan-jauh-dengan-geely-ex2-max/).

## Jarak tempuh dan rencana pengisian

Jarak yang cukup bukan hanya soal baterai besar, tetapi soal kemudahan mengisi. Klaim pengisian AC 10-100% sekitar 6,5 jam cocok untuk malam hari. Bila Anda punya tempat parkir dengan listrik yang memadai, kebutuhan harian hampir selalu terpenuhi tanpa repot.

Bagi yang tinggal di apartemen atau tidak punya garasi, tanyakan dulu kemungkinan memasang pengisi daya. Baca [cara mengisi daya Geely EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/) dan [mobil listrik untuk apartemen di Jakarta](/lp/mobil-listrik-apartemen-jakarta/).

## Uji sendiri saat test drive

Minta rute yang menyerupai perjalanan Anda, lalu perhatikan perubahan persentase baterai. Meski singkat, pengamatan ini memberi gambaran awal tentang kebiasaan mobil. Bandingkan dengan kebutuhan harian yang sudah Anda catat.

Persiapan test drive dibahas di [checklist test drive Geely EX2 Max](/artikel/test-drive-geely-ex2-max-checklist-yang-perlu-dicek/). Atur jadwal lewat halaman [kontak](/kontak/).

## Contoh menghitung kebutuhan satu minggu

Misalkan Anda mencatat jarak pulang-pergi kantor yang sama setiap hari kerja, ditambah satu perjalanan akhir pekan yang lebih jauh. Jumlahkan seluruhnya selama seminggu, lalu bagi dengan jumlah malam yang Anda punya untuk mengisi daya. Hasilnya menunjukkan seberapa sering Anda sebenarnya perlu mengisi.

Banyak pengguna kota menemukan bahwa mengisi dua atau tiga kali seminggu sudah cukup, karena baterai jarang turun terlalu rendah. Namun kami tidak memiliki data pemakaian nyata, jadi hitungan ini hanya contoh cara berpikir. Ganti angkanya dengan catatan Anda sendiri, lalu tanyakan detail model kepada sales di halaman [Geely EX2](/model/geely-ex2/).

## Kesalahan yang sering terjadi

Kesalahan pertama adalah membandingkan jarak klaim langsung dengan jarak bensin satu tangki. Keduanya berbeda cara pengukurannya. Kesalahan kedua adalah mengabaikan kebutuhan sesekali, seperti pulang kampung atau acara keluarga, padahal itu yang paling merepotkan bila tidak direncanakan.

Kesalahan ketiga adalah menunda mencari tempat pengisian sampai mobil sudah dibeli. Lakukan survei lebih dulu: di mana Anda bisa mengisi di rumah, kantor, dan sepanjang rute yang sering dilalui. Dengan begitu angka jarak tidak lagi menjadi sumber cemas, melainkan sekadar data untuk perencanaan.

## Pertanyaan yang sering diajukan

### Apakah 395 km pasti tercapai di Jakarta?

Tidak. Itu klaim siklus NEDC dan hasil nyata dipengaruhi banyak faktor.

### Berapa jarak harian rata-rata yang aman?

Tergantung kebiasaan Anda. Catat jarak harian dua minggu lalu bandingkan.

### Apakah AC memengaruhi jarak?

Ya, AC memakai energi dari baterai yang sama.

### Di mana melihat promo?

Lihat halaman [promo](/promo/) atau minta penawaran tertulis.

## Kesimpulan

Angka 395 km adalah pembanding, bukan janji. Ukur kebutuhan harian Anda, sisakan cadangan, dan pastikan ada tempat mengisi sebelum memutuskan.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mengatur test drive di rute Anda.
