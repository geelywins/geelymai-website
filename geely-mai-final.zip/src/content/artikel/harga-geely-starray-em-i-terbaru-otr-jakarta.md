---
title: "Harga Geely Starray EM-i Jakarta Oktober 2026: Rp 499 Juta"
description: "Harga Geely Starray EM-i per Oktober 2026 OTR Jakarta Rp 499 juta. Cara membaca angka, pokok pinjaman, biaya lain, dan status pre-book yang perlu dikonfirmasi."
date: 2026-10-14
category: "Harga & Promo"
tags: ["harga geely starray em-i", "otr geely starray jakarta", "harga suv hybrid geely", "geely starray em-i", "mobil listrik geely", "ev geely jakarta", "geely ev", "geely indonesia"]
draft: false
---

Harga Geely Starray EM-i per Oktober 2026 untuk wilayah Jakarta tercatat Rp 499.000.000 OTR. Artikel ini membantu Anda membaca angka tersebut, membayangkan skala uang muka dan pokok pinjaman, mengenali biaya lain, serta memahami mengapa status pemesanan perlu dikonfirmasi karena flyer resmi masih bertuliskan "PRE-BOOK NOW".

*Harga dan promo dapat berubah tanpa pemberitahuan. Data per Oktober 2026; minta penawaran tertulis terbaru dari Geely MAI sebelum memutuskan.*

## Harga per Oktober 2026

| Model | Harga OTR Jakarta |
|---|---|
| Geely Starray EM-i | Rp 499.000.000 |

Angka berasal dari data penjual per Oktober 2026 dan bukan jaminan harga pada hari Anda memesan. Anggap sebagai titik awal diskusi, lalu minta konfirmasi tertulis bertanggal. Gambaran model ada di [Geely Starray EM-i Jakarta](/lp/geely-starray-em-i-jakarta/).

## Apa arti OTR

OTR atau on the road berarti harga siap pakai di wilayah tertentu, sehingga sudah mencakup komponen pengurusan yang diperlukan. Komponen persisnya bisa berbeda antar penawaran, jadi minta rincian tertulis agar Anda tahu yang termasuk.

OTR bergantung wilayah. Bila Anda berdomisili di luar Jakarta, tanyakan harga untuk wilayah Anda dan jangan menyamakan begitu saja.

## Status pre-book yang perlu dikonfirmasi

E-flyer resmi Starray EM-i bertuliskan "PRE-BOOK NOW", yang menunjukkan fase pemesanan awal. Status itu bisa sudah berubah saat Anda membaca artikel ini, misalnya menjadi ketersediaan reguler atau perubahan waktu serah terima.

Karena itu, tanyakan kepada sales: apakah unit tersedia, berapa perkiraan waktu serah terima, dan apakah harga di atas masih berlaku. Minta jawaban tertulis, terutama bila ada tanda jadi.

## Apa yang Anda bayar

Harga mencakup SUV plug-in hybrid dengan baterai LFP 18,4 kWh, mesin 1,5 liter, motor 160 kW, bagasi 528 liter, layar 15,4 inci, dan ADAS Level 2 dengan 14 fungsi menurut flyer. Daftar lengkap ada di [spesifikasi Starray EM-i](/artikel/spesifikasi-geely-starray-em-i-plug-in-hybrid/).

Flyer tidak merinci varian atau paket, sehingga tanyakan apakah ada pilihan perlengkapan dan bagaimana pengaruhnya pada harga. Warna khusus seperti Supersonic Green dan Bright Blue merupakan paket tambahan dengan ketentuan tersendiri.

## Membayangkan uang muka dan pokok pinjaman

Sebagai latihan hitung, bila uang muka sekitar Rp 40 juta, pokok yang perlu dibiayai sekitar Rp 459 juta. Ini bukan cicilan. Besar angsuran bergantung tenor, skema, dan persetujuan pembiayaan.

Gunakan angka ini untuk membayangkan skala, lalu minta simulasi tertulis. Pahami komponen kredit di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Biaya di luar harga mobil

Siapkan anggaran untuk pemasangan pengisi daya di rumah bila ingin memanfaatkan pengisian AC, asuransi, pajak tahunan, bensin, dan perawatan. Pada mobil hybrid, biaya energi terdiri dari listrik dan bensin, sehingga hitungannya lebih kompleks.

Panduannya ada di [cara menghitung biaya operasional mobil listrik vs bensin](/artikel/cara-menghitung-biaya-operasional-mobil-listrik-vs-bensin/). Gunakan tarif listrik dan harga bensin yang Anda alami sendiri.

## Cara meminta penawaran tertulis

1. Hubungi kami lewat halaman [kontak](/kontak/) dan tanyakan status pemesanan terkini.
2. Minta rincian harga OTR tertulis beserta tanggalnya.
3. Minta simulasi kredit sesuai uang muka dan tenor.
4. Jadwalkan test drive bila unit tersedia; panduannya di [cara test drive Geely](/artikel/cara-test-drive-geely/).
5. Simpan penawaran dan perhatikan masa berlakunya.

## Hal yang perlu dicek sebelum membayar

Pastikan warna dan ketersediaan, perkiraan waktu serah terima, perlengkapan bawaan termasuk kabel pengisi, serta garansi. Kami tidak memiliki data garansi untuk disebutkan.

Tanyakan juga nasib tanda jadi bila pengajuan kredit ditolak atau jadwal serah terima berubah. Jawaban tertulis melindungi kedua pihak.

## Menilai harga dengan kepala dingin

Hindari memutuskan karena takut ketinggalan. Beri diri Anda waktu setelah test drive dan setelah menerima simulasi. Pertimbangkan apakah Anda benar-benar akan mengisi baterai secara teratur, sebab itu menentukan nilai efisiensi mobil ini.

Tips lain ada di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/). Promo terkini ada di halaman [promo](/promo/). Informasi model ada di halaman [Geely Starray EM-i](/model/geely-starray-em-i/).

## Membandingkan dengan listrik murni

Bila Anda membandingkan dengan mobil listrik murni, lihat [harga Geely EX5](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/) dan bacalah [EX5 vs Starray EM-i](/artikel/geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid/). Bandingkan dengan dasar yang sama: kelengkapan, total pembayaran, dan biaya kepemilikan.

Mobil yang tepat adalah yang sesuai pola hidup Anda, bukan sekadar yang harganya terlihat paling kecil.

## Harga dan kesiapan pengisian di rumah

Karena manfaat efisiensi Starray bergantung pengisian baterai, pastikan Anda bisa mengisi di rumah atau kantor. Biaya pemasangan pengisi berbeda tiap kondisi, jadi minta estimasi dari teknisi yang berkompeten. Rencanakan paralel dengan proses pemesanan agar saat mobil tiba, Anda sudah dapat mengisi daya.

Panduan teknis ada di [pasang charger mobil listrik di rumah](/artikel/pasang-charger-mobil-listrik-di-rumah-daya-pln-dan-instalasi/). Untuk penghuni apartemen, tanyakan izin kepada pengelola lebih dulu.

## Asuransi dan pajak

Premi asuransi bergantung nilai kendaraan, jenis perlindungan, dan perusahaan asuransi. Pajak kendaraan mengikuti aturan yang bisa berubah. Kami tidak mencantumkan angka untuk keduanya. Baca [asuransi mobil listrik yang perlu dicek](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/) dan [pajak mobil listrik](/artikel/pajak-dan-insentif-mobil-listrik-untuk-geely-ex2-max/) lalu cek aturan terbaru.

Masukkan semua biaya itu ke satu tabel agar gambaran total biaya kepemilikan tidak terpotong. Bandingkan juga dengan biaya mobil Anda sekarang sebagai acuan nyata.

## Bila Anda ragu antara hybrid dan listrik murni

Tanyakan pada diri sendiri tiga hal: apakah saya bisa mengisi daya setiap hari, seberapa sering saya menempuh rute yang jauh, dan seberapa nyaman saya dengan dua sistem penggerak. Jawabannya akan memandu Anda lebih baik daripada selisih harga. Kerangka berpikir lengkap ada di [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/).

Jangan memaksakan satu jenis hanya karena sedang populer. Pilihlah yang paling mudah Anda jalani dengan konsisten, sebab kebiasaan yang bisa dipertahankan menentukan kepuasan jangka panjang.

## Pertanyaan yang sering diajukan

### Berapa harga Starray EM-i?

Per Oktober 2026 tercatat Rp 499.000.000 OTR Jakarta. Minta penawaran tertulis terbaru.

### Apakah unit sudah tersedia?

Flyer bertuliskan PRE-BOOK NOW. Konfirmasi status dengan sales.

### Apakah harga bisa berubah?

Ya, sewaktu-waktu. Konfirmasi tertulis bertanggal.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Harga Starray EM-i per Oktober 2026 adalah Rp 499 juta OTR Jakarta, dengan status pemesanan yang perlu dikonfirmasi. Minta penawaran tertulis, hitung biaya lengkap, dan putuskan dengan tenang.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk penawaran terbaru.
