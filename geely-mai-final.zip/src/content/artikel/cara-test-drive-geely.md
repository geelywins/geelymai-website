---
title: "Cara Test Drive Geely: Persiapan, Rute, dan Hal yang Dicatat"
description: "Cara test drive Geely di Jakarta: persiapan dokumen, siapa yang diajak, rute yang diminta, fitur yang dicoba, dan cara mencatat kesan sebelum membuat keputusan."
date: 2026-10-14
category: "Tips Membeli"
tags: ["cara test drive geely", "test drive mobil listrik", "test drive geely jakarta", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah"]
draft: true
---

Test drive Geely sebaiknya diperlakukan sebagai proses menilai, bukan sekadar mencoba. Artikel ini memberi panduan umum untuk semua model Geely: apa yang disiapkan, siapa yang diajak, rute yang diminta, fitur yang dicoba, dan bagaimana mencatat kesan agar keputusan Anda tidak dipengaruhi suasana. Panduan khusus EX2 ada di artikel terpisah.

## Mengapa test drive menentukan

Brosur menjelaskan angka, tetapi tidak bisa menjelaskan rasa: kenyamanan jok, suara kabin, respons pedal, dan kemudahan antarmuka. Dua mobil dengan spesifikasi mirip dapat terasa sangat berbeda. Hanya percobaan langsung yang menjawabnya.

Karena itu, jangan memutuskan hanya dari brosur atau ulasan. Sempatkan waktu untuk benar-benar mencoba, dan siapkan diri agar sesi itu efektif. Gambaran umum ada di [mobil listrik pertama](/lp/mobil-listrik-pertama/).

## Persiapan sebelum datang

Hubungi dealer lebih dulu dan pastikan unit model dan varian yang Anda incar tersedia. Bawa SIM yang masih berlaku. Tentukan lima prioritas Anda, misalnya parkir mudah, kenyamanan, ruang, biaya, dan teknologi. Ajak orang yang akan sering memakai mobil.

Bila ada anak, bawa kursi anak. Bila Anda sering membawa barang tertentu, bawa contohnya. Jadwalkan lewat halaman [kontak](/kontak/) dan sebutkan kebutuhan Anda agar unit disiapkan.

## Memeriksa mobil saat diam

Duduklah di kursi pengemudi dan atur jok serta setir. Jangkau tombol penting. Nilai layar: apakah informasi mudah dibaca dan menu mudah dicari? Duduk juga di jok belakang dan periksa ruang kaki serta kepala.

Buka bagasi dan coba masukkan barang Anda. Lihat perlengkapan seperti ISOFIX, port pengisian, dan penyimpanan. Pengamatan saat diam sering mengungkap hal yang terlewat saat bergerak.

## Saat berkendara: yang dinilai

Rasakan akselerasi dari berhenti dan saat menyalip. Coba pengereman, termasuk sensasi rem regeneratif pada mobil listrik. Perhatikan kendali setir, kestabilan, dan suara dari roda serta angin. Nyalakan AC dan rasakan pendinginan.

Minta rute campuran: jalan halus, jalan bergelombang, polisi tidur, dan jalan lebih cepat bila memungkinkan. Duduk bergantian di depan dan belakang agar tahu perbedaan kenyamanannya.

## Menguji fitur yang menjadi alasan memilih

Jika Anda tertarik pada kamera, ADAS, V2L, atau aplikasi, jangan hanya mendengar penjelasan. Minta didemonstrasikan. Tanyakan batas tiap fitur dan cara mematikannya. Fitur yang tidak Anda coba tidak boleh menjadi alasan utama membeli.

Pembahasan fitur ada di [kamera 540 derajat EX2](/artikel/kamera-540-derajat-geely-ex2-max-membantu-parkir/) dan [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/).

## Pertanyaan yang diajukan ke sales

Tanyakan data yang belum jelas: garansi, jadwal servis, waktu pengisian, ketersediaan warna, dan waktu serah terima. Minta jawaban penting dituliskan. Bila sales perlu mengonfirmasi, minta ia menghubungi Anda kembali.

Siapkan juga pertanyaan tentang pembiayaan bila relevan. Dasar hitungan ada di [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Mencatat kesan secara jujur

Segera setelah selesai, tulis kesan Anda sebelum berbicara dengan sales. Beri nilai 1 sampai 5 untuk tiap prioritas, serta satu hal yang paling Anda sukai dan satu yang paling mengganggu. Catatan ini melindungi Anda dari tekanan atau euforia.

Ulangi test drive di hari atau jam berbeda bila memungkinkan, misalnya saat lalu lintas ramai. Kesan di jalan lengang bisa sangat berbeda dengan jam sibuk.

## Test drive lebih dari satu model

Jika Anda membandingkan beberapa model, coba semuanya di rute yang sama pada hari yang sama. Ingatan tentang rasa berkendara cepat memudar, dan perbandingan langsung jauh lebih adil. Gunakan catatan yang sama untuk semua unit.

Panduan membandingkan ada di [perbandingan EX2 vs EX5](/artikel/perbandingan-geely-ex2-vs-ex5-pilih-yang-mana/). Untuk EX2 secara khusus, lihat [checklist test drive EX2 Max](/artikel/test-drive-geely-ex2-max-checklist-yang-perlu-dicek/).

## Setelah test drive

Jangan terburu-buru memesan. Bandingkan catatan, bicarakan dengan keluarga, dan hitung total biaya. Minta penawaran tertulis dari halaman [promo](/promo/) bila siap melangkah. Alur pembelian dijelaskan di [alur membeli mobil Geely](/artikel/alur-membeli-mobil-geely-dari-booking-sampai-serah-terima/).

Bila masih ragu, itu wajar. Lebih baik bertanya lagi daripada menyesal. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/) dan [Geely EX5](/model/geely-ex5/).

## Kesalahan yang sering terjadi saat test drive

Kesalahan pertama adalah membiarkan sales menentukan seluruh rute. Rute yang terlalu mulus tidak mewakili pemakaian Anda. Kesalahan kedua adalah tidak membawa pendamping, padahal pendapat kedua sangat membantu. Kesalahan ketiga adalah memutuskan karena kesan tiga menit pertama.

Kesalahan lain adalah menunda pertanyaan sampai setelah pemesanan. Pada saat itu posisi tawar Anda berkurang. Ajukan semua keraguan di awal dan catat jawabannya.

## Contoh urutan 30 menit yang efisien

Lima menit pertama untuk memeriksa kabin dan bagasi. Sepuluh menit berikutnya berkendara di jalan biasa, merasakan tenaga, rem, dan kenyamanan. Lima menit untuk jalan lebih cepat bila memungkinkan, dan lima menit untuk mencoba parkir dengan bantuan fitur yang ada.

Lima menit terakhir untuk bertanya dan mencatat kesan. Bila waktu Anda lebih panjang, tambahkan sesi duduk di jok belakang selama rute. Sesi yang tertata membuat Anda pulang dengan informasi, bukan hanya kesan.

## Test drive untuk mobil listrik pertama

Jika ini kali pertama Anda mencoba mobil listrik, beri waktu untuk membiasakan diri dengan keheningan, respons pedal, dan rem regeneratif. Minta sales menjelaskan cara mengubah tingkat regenerasi bila tersedia. Banyak pengemudi merasa canggung di awal tetapi cepat terbiasa dalam beberapa hari.

Baca [istilah mobil listrik](/artikel/istilah-mobil-listrik-kwh-ac-dc-v2l-dan-regen/) sebelum datang supaya penjelasan sales mudah dipahami.

## Etika sesi coba

Hargai waktu semua pihak. Datanglah sesuai janji, ikuti arahan keselamatan, dan jaga unit seperti milik sendiri. Sampaikan terus terang bila Anda belum siap membeli; dealer yang baik menghargai kejujuran. Sikap saling menghormati membuat pertanyaan Anda dijawab lebih lengkap.

## Pertanyaan yang sering diajukan

### Apa yang harus dibawa?

SIM yang berlaku, daftar prioritas, dan bila perlu kursi anak atau barang bawaan.

### Berapa lama test drive?

Tanyakan kepada dealer, dan mintalah rute yang mewakili pemakaian Anda.

### Apakah boleh membawa keluarga?

Sebaiknya. Pendapat mereka penting untuk kenyamanan.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Test drive yang baik dimulai dari persiapan: prioritas tertulis, pendamping yang tepat, dan rute yang relevan. Catat kesan dengan jujur sebelum mengambil keputusan.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mengatur jadwal.
