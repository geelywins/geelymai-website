---
title: "Booking Geely EX2: Langkah Aman dan Cara Bernegosiasi Wajar"
description: "Tips booking Geely EX2: dokumen yang diminta, hal yang harus tertulis, cara menimbang penawaran, dan kesalahan umum agar proses pemesanan Anda aman."
date: 2026-10-14
category: "Tips Membeli"
tags: ["tips booking geely ex2", "booking mobil listrik", "geely ex2", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik murah"]
draft: false
---

Booking Geely EX2 adalah tahap ketika Anda mulai mengikat diri secara finansial, sehingga ketelitian di sini menghemat banyak masalah kemudian. Artikel ini menguraikan langkah yang aman, dokumen yang perlu ada, hal yang harus tertulis, serta cara bernegosiasi yang wajar tanpa saling menekan.

## Sebelum booking: pastikan kebutuhan Anda jelas

Booking yang baik berawal dari keputusan yang matang. Pastikan Anda sudah mencoba mobilnya, memahami perbedaan varian, dan memiliki rencana pengisian daya. Tanpa itu, booking hanya menunda kebingungan. Bila masih ragu, ambil waktu lagi; tidak ada promo yang sepadan dengan mobil yang tidak cocok.

Siapkan juga gambaran anggaran: berapa uang muka, berapa cicilan yang nyaman, dan berapa lama tenor. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/), dan pilihan varian dibahas di [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Apa itu booking dan apa isinya

Booking adalah pemesanan awal unit tertentu, biasanya disertai tanda jadi. Kami tidak mencantumkan nominal tanda jadi karena ketentuannya bisa berubah, dan Anda sebaiknya menanyakan langsung. Hal terpenting adalah mengetahui apa yang Anda dapatkan sebagai imbalannya: unit apa, varian apa, warna apa, dan perkiraan waktu pengiriman.

Pastikan semua rincian itu tertulis pada bukti pemesanan. Jangan menerima janji lisan tentang warna, waktu, atau hadiah tambahan tanpa dicatat.

## Hal yang harus tertulis

Minta bukti tertulis untuk: varian dan warna, harga yang disepakati beserta apa saja yang termasuk, besaran tanda jadi, perkiraan tanggal pengiriman, dan kebijakan bila Anda membatalkan. Tanyakan secara spesifik apakah tanda jadi dapat dikembalikan dan dalam kondisi apa.

Bila ada bonus atau aksesori yang dijanjikan, catat jenisnya. Simpan salinan semua dokumen dan foto bukti pembayaran. Dokumentasi yang rapi adalah perlindungan terbaik Anda.

## Cara membayar dengan aman

Lakukan pembayaran melalui rekening resmi yang tercantum pada dokumen dealer, dan minta bukti penerimaan. Hindari membayar tunai kepada perorangan tanpa tanda terima resmi. Verifikasi nomor rekening dengan menghubungi dealer lewat kanal resmi di halaman [kontak](/kontak/).

Waspadai pesan yang mengaku dari dealer dan meminta transfer mendadak. Jika ragu, hentikan dan konfirmasi ulang. Penipuan berkedok pemesanan mobil memang ada, dan kehati-hatian Anda adalah perlindungan paling efektif.

## Negosiasi yang wajar

Negosiasi bukan pertarungan. Tujuannya mencapai kesepakatan yang adil bagi kedua pihak. Mulailah dengan mengetahui apa yang Anda butuhkan, lalu tanyakan apa yang bisa ditawarkan dealer, termasuk promo, aksesori, atau fleksibilitas skema pembayaran.

Kami tidak menyebut angka diskon di sini karena promo selalu berubah; lihat halaman [promo](/promo/) untuk penawaran terkini. Jangan menekan sales dengan klaim yang tidak benar, dan jangan percaya bila ada tawaran yang terdengar terlalu bagus tanpa dokumen.

## Membandingkan penawaran secara adil

Bila Anda menerima beberapa penawaran, bandingkan dengan dasar yang sama: varian yang sama, apa saja yang termasuk, uang muka, tenor, dan total pembayaran. Penawaran dengan cicilan lebih kecil belum tentu lebih murah bila tenornya lebih panjang.

Buat tabel sederhana dan isi untuk tiap penawaran. Panduan hitungan ada di [simulasi cicilan EX2 Max](/artikel/simulasi-cicilan-geely-ex2-max-dp-dan-tenor/) dan [simulasi kredit mobil listrik](/artikel/simulasi-kredit-mobil-listrik-dp-tenor-dan-cicilan/).

## Pembiayaan dan persetujuan

Bila Anda mengajukan kredit, ingat bahwa persetujuan tetap ditentukan perusahaan pembiayaan, bukan dealer. Jangan menyetor jumlah besar sebelum memahami risiko jika pengajuan ditolak. Tanyakan ketentuan pengembalian dalam kondisi itu.

Siapkan dokumen lebih awal agar proses cepat; daftarnya ada di [syarat dan dokumen kredit mobil listrik](/artikel/syarat-dan-dokumen-kredit-mobil-listrik/). Jujur dalam pengisian data, karena ketidaksesuaian dapat menyebabkan penolakan.

## Asuransi, pengisi daya, dan hal sampingan

Sebelum serah terima, pikirkan asuransi dan pemasangan pengisi daya. Keduanya dapat memengaruhi kenyamanan dan biaya. Pembahasan ada di [asuransi mobil listrik](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/) dan [cara mengisi daya EX2 Max di rumah](/artikel/cara-mengisi-daya-geely-ex2-max-di-rumah/).

Jangan sampai mobil tiba tetapi tempat mengisi daya belum siap. Rencanakan instalasi paralel dengan proses pemesanan agar waktu tunggu tidak terbuang.

## Mempersiapkan serah terima

Menjelang pengiriman, tanyakan jadwal dan dokumen yang akan diterima. Siapkan waktu untuk memeriksa mobil secara teliti saat serah terima. Daftar cek ada di [cek mobil baru saat serah terima](/artikel/cek-mobil-baru-saat-serah-terima-checklist-pdi/).

Jangan menandatangani berita acara sebelum yakin tidak ada kerusakan atau kekurangan. Catat setiap temuan pada dokumen. Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

## Kesalahan umum saat booking

Kesalahan pertama adalah terburu-buru karena batas promo. Kesalahan kedua adalah tidak menanyakan kebijakan pembatalan. Kesalahan ketiga adalah menerima janji lisan. Kesalahan keempat adalah membandingkan penawaran dengan dasar berbeda.

Hindari semuanya dengan satu kebiasaan: tanyakan, catat, dan minta tertulis. Sales yang baik tidak akan keberatan.

## Waktu yang tepat untuk memesan

Tidak ada waktu yang pasti paling baik untuk memesan. Yang lebih penting adalah kesiapan Anda: dokumen lengkap, anggaran jelas, dan tempat mengisi daya terencana. Promo datang dan pergi, sehingga mengejarnya tanpa kesiapan sering berujung keputusan tergesa.

Namun, bila Anda sudah siap, tanyakan kapan periode promo berakhir dan apa konsekuensinya bila Anda memesan sedikit lebih lambat. Jawaban yang jelas membantu Anda menentukan apakah perlu bergerak cepat atau cukup menunggu beberapa hari untuk menimbang.

## Peran keluarga dalam keputusan

Pembelian mobil adalah keputusan bersama, terutama bila dipakai oleh lebih dari satu orang. Ajak pasangan atau anggota keluarga yang sering menggunakan mobil untuk datang pada sesi booking, atau setidaknya membaca dokumen penawaran. Hal ini mencegah salah paham mengenai varian, warna, atau skema pembayaran.

Catat pertanyaan masing-masing dan bahas sebelum menandatangani. Keputusan yang diambil bersama biasanya lebih tahan lama dan lebih sedikit disesali.

## Pertanyaan yang sering diajukan

### Apakah tanda jadi bisa dikembalikan?

Tergantung ketentuan dealer. Tanyakan dan minta tertulis.

### Apakah boleh bernegosiasi?

Boleh, secara wajar. Lihat promo terkini di halaman [promo](/promo/).

### Bagaimana menghindari penipuan?

Gunakan rekening resmi dan konfirmasi lewat kanal resmi dealer.

### Apa yang harus tertulis?

Varian, warna, harga, waktu pengiriman, dan kebijakan pembatalan.

## Kesimpulan

Booking yang aman bertumpu pada kebutuhan yang jelas, dokumen tertulis, pembayaran lewat jalur resmi, dan negosiasi yang wajar. Luangkan waktu untuk menimbang sebelum menyetor.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk memulai.
