---
title: "Spesifikasi Geely Starray EM-i: Tabel Plug-in Hybrid"
description: "Spesifikasi Geely Starray EM-i dari e-flyer resmi: mesin 1,5 liter, motor 160 kW, baterai 18,4 kWh, bagasi 528 liter, dan pengisian. Plug-in hybrid."
date: 2026-10-14
category: "Model Geely"
tags: ["spesifikasi geely starray em-i", "starray em-i plug-in hybrid", "geely starray", "suv hybrid geely", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: true
---

Spesifikasi Geely Starray EM-i pada artikel ini bersumber dari e-flyer resmi yang mencantumkan catatan bahwa gambar hanya ilustrasi dan angka konsumsi dipakai untuk perbandingan, serta bisa berbeda di jalan nyata. Starray EM-i adalah plug-in hybrid, bukan mobil listrik murni, sehingga cara membaca spesifikasinya sedikit berbeda.

## Ringkasan dalam tabel

| Aspek | Data |
|---|---|
| Jenis | Plug-in hybrid (PHEV), penggerak roda depan |
| Mode berkendara | Pure, Hybrid, Power |
| Dimensi | 4.740 x 1.905 x 1.685 mm |
| Bagasi | 528 liter (kursi tegak) hingga 2.065 liter (dilipat) |
| Mesin bensin | 1,5 liter 4 silinder NA: 73 kW, 125 Nm |
| Motor listrik | 160 kW, 262 Nm |
| Baterai | LFP 18,4 kWh |
| Tangki BBM | 51 liter |
| Kecepatan maksimum | 170 km/jam |
| 0-100 km/jam | 8,1 detik |

Gunakan tabel sebagai peta, lalu minta lembar spesifikasi terbaru. Gambaran model ada di [Geely Starray EM-i Jakarta](/lp/geely-starray-em-i-jakarta/).

## Memahami sistem plug-in hybrid

Starray memiliki mesin bensin dan motor listrik. Motor listrik berdaya 160 kW menjadi penggerak utama, sedangkan mesin bensin 73 kW membantu sebagai penggerak atau pembangkit sesuai kondisi. Baterai dapat diisi dari colokan.

Tiga mode, Pure, Hybrid, dan Power, mengatur cara kerja. Flyer tidak menjelaskan logika tiap mode secara rinci, sehingga tanyakan kepada sales dan minta demonstrasi. Penjelasan umum ada di [cara kerja plug-in hybrid EM-i](/artikel/cara-kerja-plug-in-hybrid-geely-em-i-dan-cara-mengisi-daya/).

## Dimensi dan ruang

Dengan panjang 4.740 mm, lebar 1.905 mm, dan tinggi 1.685 mm, Starray tergolong SUV menengah. Bagasi 528 liter saat kursi tegak dan 2.065 liter saat dilipat memberi ruang lega untuk keluarga.

Angka dimensi hanyalah gambaran. Duduk di semua posisi dan bawa barang Anda untuk menilai kecukupannya. Kami tidak memiliki data jarak sumbu roda dan ruang kabin lainnya.

## Tenaga dan performa

Perpaduan motor 160 kW dengan torsi 262 Nm dan mesin 73 kW memberi 0-100 km/jam dalam 8,1 detik menurut flyer, dengan kecepatan maksimum 170 km/jam. Akselerasinya cukup bertenaga untuk SUV keluarga, meski lebih santai daripada beberapa mobil listrik murni.

Rasakan sendiri respons saat menyalip dan transisi antara motor dan mesin. Pengalaman halus atau tidaknya bersifat subjektif dan tidak dapat dinilai dari tabel.

## Baterai dan pengisian

Baterai LFP berkapasitas 18,4 kWh jauh lebih kecil daripada mobil listrik murni, tetapi dapat diisi dari colokan. Pengisian DC maksimal 30 kW dengan klaim 30-80% kurang dari 20 menit, dan AC maksimal 6,6 kW dengan klaim 25-100% kurang dari 3 jam.

Itu klaim pabrikan, dan hasil nyata dipengaruhi peralatan serta kondisi. Panduan pengisian di rumah ada di [cara mengisi daya mobil listrik di rumah dan SPKLU](/artikel/cara-mengisi-daya-mobil-listrik-di-rumah-dan-spklu/).

## Jarak dan konsumsi

Klaim NEDC: jarak gabungan 1.000+ km, jarak listrik murni hingga 105 km, dan konsumsi BBM 0,5 L/100 km saat baterai penuh. Rata-rata tertimbang 1,2 L/100 km, dan 4,3 L/100 km saat baterai rendah. Angka ini hanya untuk perbandingan.

Penjelasan konsumsi ada di [konsumsi BBM Starray EM-i dan jarak 1.000 km](/artikel/konsumsi-bbm-geely-starray-em-i-dan-jarak-tempuh-1000-km/). Hasil nyata bergantung kebiasaan mengisi daya dan gaya berkendara.

## Fitur yang disebut pabrikan

Flyer menyebut layar tengah HD 15,4 inci, audio Flyme Sound 16 speaker termasuk 2 di headrest, serta ADAS Level 2 dengan 14 fungsi. Disebut pula arsitektur GEA dan klaim efisiensi termal mesin 46,5%, yang merupakan klaim pabrikan.

Daftar 14 fungsi ADAS tidak dirinci, jadi minta daftar tertulis. Jangan menganggap istilah teknologi sebagai jaminan hasil tertentu.

## Warna

Warna standar: Snowy White, Pearl Silver, Twilight Gray, dan Marble Black. Supersonic Green dan Bright Blue adalah warna khusus yang merupakan paket tambahan dengan ketentuan ditetapkan PT Geely Auto Indonesia. Tanyakan ketersediaan dan ketentuannya kepada sales.

Flyer juga bertuliskan "PRE-BOOK NOW", sehingga status pemesanan bisa sudah berubah. Konfirmasi langsung sebelum merencanakan pembelian.

## Yang tidak ada di flyer

Beberapa hal tidak tercantum, antara lain garansi, jadwal servis, jumlah airbag, dan waktu serah terima. Kami tidak menebaknya. Minta jawaban tertulis dari sales.

Untuk perbandingan dengan EX5, baca [EX5 vs Starray EM-i](/artikel/geely-ex5-vs-starray-em-i-listrik-murni-atau-plug-in-hybrid/). Informasi model ada di halaman [Geely Starray EM-i](/model/geely-starray-em-i/). Atur jadwal lewat halaman [kontak](/kontak/).

## Cara membaca spesifikasi plug-in hybrid

Pada mobil listrik murni, kapasitas baterai dan jarak adalah angka utama. Pada plug-in hybrid, Anda perlu membaca tiga hal sekaligus: kapasitas baterai kecil, mesin bensin sebagai cadangan, dan cara keduanya bekerja bersama. Jangan membandingkan kapasitas 18,4 kWh langsung dengan baterai besar milik mobil listrik murni.

Yang lebih relevan adalah jarak listrik murni harian Anda dan kenyamanan bensin untuk rute jauh. Gunakan tabel di atas sebagai awal, lalu uji hubungannya dengan kebiasaan Anda lewat test drive.

## Pertimbangan keluarga

Bagasi 528 liter dan jok belakang yang dapat dilipat membuat Starray praktis untuk keluarga. Tanyakan kepada sales apakah ada ISOFIX dan fitur keluarga lain, karena e-flyer tidak merincinya. Bawa kursi anak dan barang Anda saat mencoba.

Pembahasan keluarga pada SUV listrik lain ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/) sebagai pembanding konsep ruang. Ingat bahwa kedua mobil berbeda, jadi jangan menyalin asumsi antar model.

## Perawatan mobil hybrid

Plug-in hybrid memiliki mesin bensin dan sistem kelistrikan sehingga perawatannya mencakup keduanya. Kami belum memiliki jadwal servis resmi, jadi tanyakan kepada sales komponen apa saja yang masuk jadwal dan berapa intervalnya. Pembahasan umum ada di [perawatan mobil listrik: apa yang berbeda dari mobil bensin](/artikel/perawatan-mobil-listrik-apa-yang-berbeda-dari-mobil-bensin/).

## Pertanyaan yang sering diajukan

### Apakah Starray listrik murni?

Bukan. Ini plug-in hybrid dengan mesin bensin dan baterai yang dapat diisi.

### Berapa kapasitas baterai?

LFP 18,4 kWh menurut flyer.

### Berapa konsumsi BBM?

Klaim NEDC rata-rata tertimbang 1,2 L/100 km. Hasil nyata bisa berbeda.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Starray EM-i menggabungkan motor listrik 160 kW, mesin bensin 1,5 liter, dan baterai 18,4 kWh dalam SUV dengan bagasi lega. Klaim konsumsi menarik, tetapi hasil nyata bergantung kebiasaan mengisi daya.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
