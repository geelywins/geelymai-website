---
title: "Mobil Listrik Saat Banjir: Kebiasaan Aman yang Perlu Diketahui"
description: "Mobil listrik saat banjir di Jakarta: kebiasaan aman, hal yang jangan dilakukan, dan pertanyaan ke dealer soal ketahanan air tanpa klaim yang tak terbukti."
date: 2026-10-14
category: "Mobil Listrik"
tags: ["mobil listrik banjir", "mobil listrik genangan", "mobil listrik jakarta", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik geely", "mobil listrik murah"]
draft: false
---

Mobil listrik saat banjir menimbulkan kekhawatiran wajar bagi warga Jakarta. Kami tidak memiliki data uji ketahanan air untuk EX2, EX5, atau Starray EM-i, sehingga kami tidak menyatakan aman atau tidaknya mobil tertentu. Artikel ini berisi kebiasaan aman yang berlaku umum dan pertanyaan yang perlu Anda ajukan kepada dealer.

## Apa yang tidak kami klaim

Kami tidak menyebut kedalaman air yang aman, tingkat perlindungan baterai, atau hasil uji banjir karena datanya tidak ada pada sumber kami. Angka seperti itu menyangkut keselamatan, dan menebaknya bisa membahayakan Anda.

Yang dapat kami berikan adalah prinsip kehati-hatian yang berlaku bagi mobil apa pun, serta daftar pertanyaan untuk sales. Gambaran mobil listrik di Jakarta ada di [mobil listrik Jakarta](/lp/mobil-listrik-jakarta/).

## Prinsip utama: hindari genangan dalam

Cara paling aman adalah tidak menerobos air yang kedalamannya tidak diketahui. Genangan bisa menyembunyikan lubang, benda tajam, atau aliran deras. Bila ragu, putar balik atau cari rute lain. Tidak ada tujuan yang sebanding dengan risikonya.

Aturan ini berlaku untuk mobil bensin maupun listrik. Pada mobil listrik, ada pertimbangan tambahan karena sistem bertegangan tinggi, sehingga kehati-hatian lebih penting lagi.

## Bila terpaksa melewati genangan dangkal

Jika genangan terlihat dangkal dan Anda yakin aman, kurangi kecepatan secara signifikan dan jaga laju stabil agar tidak membuat gelombang yang masuk ke komponen. Jangan berhenti di tengah genangan. Setelah keluar, periksa rem dengan menginjaknya perlahan.

Perhatikan peringatan yang menyala di panel instrumen. Bila ada indikasi masalah, hentikan mobil di tempat aman dan hubungi layanan darurat dealer.

## Apa yang jangan dilakukan setelah terendam

Jika mobil sempat terendam cukup dalam, jangan menyalakan atau mengisi daya sebelum diperiksa teknisi resmi. Jangan membongkar sendiri komponen atau menyentuh kabel oranye bertegangan tinggi. Hubungi layanan darurat dan derek mobil sesuai petunjuk.

Mengisi daya pada kendaraan yang terendam berisiko. Tunggu hingga teknisi berwenang memastikan kondisinya.

## Parkir saat musim hujan

Pilihlah tempat parkir yang lebih tinggi dan tidak mudah tergenang. Hindari basement yang rawan banjir saat hujan deras. Periksa prakiraan cuaca dan, bila perlu, pindahkan mobil sebelum air naik.

Perhatikan juga lokasi pengisian. Hindari mengisi daya di area yang basah atau tergenang, dan pastikan konektor serta kabel dalam keadaan kering dan utuh.

## Pertanyaan yang perlu diajukan ke dealer

Tanyakan: apakah ada informasi resmi tentang ketahanan air pada model ini, kedalaman maksimum yang dianjurkan, apa yang harus dilakukan bila terendam, dan apakah kerusakan akibat banjir tercakup garansi atau asuransi. Minta jawaban tertulis.

Jawaban bisa berbeda antar model, jadi tanyakan untuk model yang Anda incar. Pembahasan asuransi ada di [asuransi mobil listrik yang perlu dicek](/artikel/asuransi-mobil-listrik-yang-perlu-dicek-sebelum-memilih/).

## Garansi dan asuransi untuk risiko banjir

Banyak garansi pabrikan tidak mencakup kerusakan akibat banjir, dan itu biasanya ditangani lewat asuransi. Namun cakupan asuransi bervariasi. Pastikan polis Anda mencakup risiko banjir untuk kendaraan listrik, termasuk komponen kelistrikannya.

Kami tidak memiliki data garansi untuk disebutkan. Minta dokumen tertulis dan baca bagian pengecualian dengan teliti. Pembahasan garansi ada di [garansi baterai dan mobil EX2 Max](/artikel/garansi-baterai-dan-mobil-geely-ex2-max/).

## Persiapan keluarga

Siapkan rencana darurat: nomor layanan dealer, nomor derek, dan lokasi aman terdekat. Ajarkan anggota keluarga untuk tidak masuk genangan. Simpan perlengkapan darurat di mobil seperti senter dan pemecah kaca bila Anda memilikinya.

Kebiasaan siap siaga ini berlaku di semua jenis mobil dan sering menjadi pembeda antara kejadian yang terkendali dan yang berbahaya.

## Bandingkan dengan kekhawatiran lain

Kekhawatiran banjir sering muncul bersama kekhawatiran lain tentang mobil listrik. Beberapa di antaranya dibahas di [mitos mobil listrik yang sering dipercaya](/artikel/mitos-mobil-listrik-yang-sering-dipercaya-dan-faktanya/). Informasi model ada di halaman [Geely EX2](/model/geely-ex2/).

Atur jadwal bertanya lewat halaman [kontak](/kontak/) dan lihat penawaran di halaman [promo](/promo/).

## Memeriksa mobil setelah musim hujan

Setelah musim hujan, periksa kondisi karet pintu, lantai kabin, dan kolong mobil. Bau apek, kelembapan, atau karat dini perlu diperiksa teknisi. Bawa mobil ke bengkel resmi bila ada tanda yang meragukan, meskipun mobil belum pernah terendam.

Periksa juga kondisi kabel pengisi dan konektor. Kabel yang retak atau konektor yang berkarat tidak boleh dipakai. Kebiasaan sederhana ini mencegah masalah kelistrikan yang sebenarnya dapat dihindari.

## Bila Anda mempertimbangkan membeli di daerah rawan banjir

Jika tempat tinggal Anda rawan banjir, pertimbangkan itu sejak awal. Pastikan Anda memiliki tempat parkir yang lebih tinggi atau rencana memindahkan mobil saat peringatan banjir. Hitung juga biaya asuransi yang mencakup banjir.

Jangan memaksa membeli bila risiko terlalu besar bagi lingkungan Anda. Keputusan yang jujur terhadap kondisi sekitar lebih penting daripada ketertarikan pada teknologi. Bila perlu, bandingkan dengan pilihan lain di [mobil listrik atau hybrid](/lp/mobil-listrik-atau-hybrid/).

## Kebiasaan berkendara saat hujan deras

Saat hujan deras, kurangi kecepatan, jaga jarak lebih jauh, dan nyalakan lampu. Jalan yang licin memperpanjang jarak pengereman. Hindari tepi jalan yang biasa tergenang dan berhati-hati di bawah jembatan layang atau underpass yang mudah menampung air.

Kebiasaan ini bukan khusus mobil listrik, tetapi sangat berguna. Pengemudi yang tenang dan sabar jauh lebih terlindungi daripada yang mengandalkan teknologi semata.

## Catatan untuk penghuni apartemen dan perumahan

Penghuni apartemen sebaiknya menanyakan kepada pengelola apakah area parkir bawah tanah pernah tergenang dan bagaimana prosedur evakuasi kendaraan. Penghuni perumahan dapat berdiskusi dengan tetangga tentang titik rawan genangan dan jalur alternatif. Informasi lokal seperti ini sering lebih berguna daripada panduan umum mana pun.

## Pertanyaan yang sering diajukan

### Apakah mobil listrik aman menerobos banjir?

Kami tidak memiliki data uji. Hindari genangan dalam seperti pada mobil mana pun.

### Apa yang harus dilakukan setelah terendam?

Jangan menyalakan atau mengisi daya. Hubungi layanan darurat dan teknisi resmi.

### Apakah banjir tercakup garansi?

Tanyakan kepada sales dan periksa polis asuransi Anda.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

Cara teraman menghadapi banjir adalah menghindarinya, memarkir di tempat tinggi, dan memastikan asuransi mencakup risiko banjir. Tanyakan informasi resmi kepada dealer dan jangan mengandalkan klaim yang tak terbukti.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk berkonsultasi.
