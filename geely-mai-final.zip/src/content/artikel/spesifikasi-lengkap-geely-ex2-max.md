---
title: "Spesifikasi Geely EX2 Max: Angka Resmi dan Cara Membacanya"
description: "Spesifikasi Geely EX2 Max lengkap: baterai LFP 40,8 kWh, motor 85 kW, klaim 395 km, layar 14,6 inci, dan bagasi 375 liter. Cara membaca tiap angkanya."
date: 2026-10-14
category: "Model Geely"
tags: ["spesifikasi geely ex2 max", "spesifikasi geely ex2", "geely ex2 max", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta", "mobil listrik kompak"]
draft: false
---

Spesifikasi Geely EX2 Max mencakup baterai LFP 40,8 kWh, motor 85 kW dengan torsi 150 Nm, klaim jarak 395 km (NEDC), serta layar tengah 14,6 inci. Artikel ini menyusun semua angka resminya dalam tabel, lalu menjelaskan apa arti tiap angka bagi pemakaian Anda sehari-hari.

## Cara memakai artikel ini

Daftar spesifikasi sering terasa seperti deretan angka tanpa makna. Supaya berguna, kami membaginya menjadi kelompok: tenaga, baterai dan pengisian, kabin, serta ruang dan keselamatan. Setiap kelompok diikuti penjelasan singkat tentang dampaknya di jalan.

Semua angka berasal dari data resmi yang kami pegang. Untuk jarak tempuh, pengisian, dan akselerasi, angka tersebut adalah klaim pabrikan dengan metode pengujian standar, sehingga hasil Anda bisa berbeda. Bila Anda sedang menimbang model, bacalah juga halaman [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/) sebagai gambaran besarnya.

## Tabel spesifikasi utama

| Kelompok | Data |
|---|---|
| Baterai | LFP 40,8 kWh |
| Motor | 85 kW |
| Torsi | 150 Nm |
| Klaim jarak | 395 km (NEDC) |
| Pengisian cepat DC | 30-80% sekitar 25 menit |
| Pengisian AC | 10-100% sekitar 6,5 jam |
| Layar tengah | 14,6 inci |
| Panel instrumen | 8,8 inci |
| Airbag | 6 |
| Suspensi | Depan MacPherson, belakang multi-link |
| Velg | 16 inci |
| Bagasi | 375 liter, hingga 1.320 liter, plus frunk 70 liter |
| Kapasitas | 5 penumpang |
| 0-100 km/jam | Sekitar 11,5 detik (perkiraan) |

Dimensi bodi EX2 belum tersedia pada data resmi kami. Karena itu, kami tidak menuliskan panjang, lebar, atau tinggi, dan menyarankan Anda menanyakannya kepada sales atau melihat langsung mobilnya.

## Tenaga: 85 kW dan torsi 150 Nm

Motor 85 kW dengan torsi 150 Nm adalah karakter utama EX2. Pada mobil listrik, torsi hadir sejak putaran pertama, sehingga akselerasi dari berhenti terasa responsif. Waktu 0-100 km/jam sekitar 11,5 detik adalah perkiraan, dan angka ini menempatkan EX2 sebagai mobil harian yang tenang, bukan mobil performa.

Bagi pemakaian kota, tenaga tersebut cukup untuk menyalip dengan percaya diri. Untuk perjalanan jalan tol, respons tetap memadai, tetapi mobil ini jelas dirancang untuk kenyamanan dan efisiensi. Anda bisa membaca pengalaman di jalan padat pada [EX2 Max di macet Jakarta](/artikel/geely-ex2-max-di-macet-jakarta/).

## Baterai dan pengisian

Baterai LFP 40,8 kWh dipasangkan dengan klaim jarak 395 km menurut metode NEDC. Metode ini dilakukan di kondisi terkendali, jadi anggaplah sebagai pembanding antarmobil, bukan janji. Cara membaca selisih antara klaim dan pemakaian nyata dibahas di [jarak tempuh EX2 Max: klaim vs pemakaian harian](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/).

Untuk pengisian, AC 10-100% memakan sekitar 6,5 jam, cocok untuk semalam di rumah. DC 30-80% memakan sekitar 25 menit, berguna ketika Anda perlu tambahan energi di perjalanan. Teknologi LFP dikenal stabil, dan pembahasannya ada di [baterai LFP 40,8 kWh: aman dan tahan lama](/artikel/baterai-lfp-40-8-kwh-geely-ex2-max-aman-dan-tahan-lama/).

## Kabin dan teknologi

Layar tengah 14,6 inci menjadi pusat kendali, sementara panel instrumen 8,8 inci menampilkan data berkendara. Ukuran layar yang besar menyederhanakan tampilan dashboard, namun menuntut kebiasaan baru bagi yang terbiasa dengan tombol fisik. Detail tampilan dan pencahayaan kabin ada di [ambient light dan layar 14,6 inci EX2 Max](/artikel/ambient-light-256-warna-dan-layar-14-6-inci-geely-ex2-max/).

Varian Max menambah perlengkapan yang tidak ada di Pro, seperti kamera 540 derajat, ADAS Level 2, V2L, dan kontrol lewat aplikasi. Bagi Anda yang ragu memilih varian, pelajari [perbedaan EX2 Pro dan Max](/artikel/perbedaan-geely-ex2-pro-vs-ex2-max-mana-yang-worth-it/).

## Ruang, bagasi, dan frunk

Bagasi 375 liter dapat membesar sampai 1.320 liter bila jok belakang dilipat. Di depan, frunk 70 liter menjadi ruang tambahan yang berguna untuk kabel pengisi, payung, atau barang kecil. Kombinasi ini membuat EX2 lebih praktis dari ukurannya yang ringkas.

Untuk kebutuhan nyata, bawalah barang yang biasa Anda angkut saat berkunjung ke dealer. Contoh isi bagasinya ada di [bagasi 375 liter dan frunk 70 liter EX2](/artikel/bagasi-375-liter-dan-frunk-70-liter-geely-ex2-muat-apa-saja/).

## Keselamatan dan kenyamanan berkendara

EX2 dilengkapi 6 airbag, suspensi depan MacPherson dan belakang multi-link, serta velg 16 inci. Suspensi multi-link di belakang umumnya ditujukan untuk kenyamanan dan kestabilan. Pembahasan lanjutan ada di [keamanan EX2 Max: 6 airbag dan fitur pelindung](/artikel/keamanan-geely-ex2-max-6-airbag-dan-fitur-pelindung/) serta [velg 16 inci dan kenyamanan berkendara](/artikel/velg-16-inci-dan-kenyamanan-berkendara-geely-ex2-max/).

Kami tidak mencantumkan rating keselamatan atau angka garansi karena datanya belum kami miliki. Untuk informasi tersebut, tanyakan kepada tim sales dan minta jawaban tertulis.

## Cara menggunakan data ini untuk memutuskan

Mulailah dari kebutuhan, lalu cocokkan dengan angka. Jika jarak harian Anda pendek dan Anda bisa mengisi di rumah, klaim 395 km memberi kelonggaran besar. Jika Anda sering membawa barang, periksa bagasi. Jika Anda mengutamakan kemudahan parkir, perhatikan fitur kamera pada varian Max.

Setelah itu, uji langsung. Panduan persiapannya ada di [checklist test drive Geely EX2 Max](/artikel/test-drive-geely-ex2-max-checklist-yang-perlu-dicek/). Informasi lokasi dan model ada di halaman [Geely EX2](/model/geely-ex2/), dan Anda bisa menghubungi kami lewat halaman [kontak](/kontak/).

## Kesalahan umum saat membaca spesifikasi

Kesalahan pertama adalah membandingkan angka dari metode pengujian yang berbeda. Klaim jarak NEDC tidak bisa dibandingkan langsung dengan WLTP atau dengan hasil uji pihak lain, sebab kondisi pengujiannya berlainan. Kesalahan kedua adalah menganggap angka tertinggi otomatis terbaik; baterai terbesar belum tentu berguna bila Anda hanya menempuh jarak pendek.

Kesalahan ketiga adalah melupakan kondisi nyata. Panas Jakarta, AC yang menyala, penumpang penuh, dan kemacetan, semuanya memengaruhi pemakaian energi. Jadi, jadikan spesifikasi sebagai titik awal diskusi, bukan akhir. Bandingkan dengan kebiasaan Anda sendiri, lalu uji langsung.

## Contoh membaca spesifikasi untuk dua jenis pengguna

Bayangkan pengguna pertama, seorang pekerja kantoran dengan jarak harian pendek dan garasi di rumah. Baginya, klaim 395 km sudah sangat longgar, pengisian AC semalam lebih dari cukup, dan fitur seperti kamera 540 derajat mungkin menjadi nilai tambah untuk parkir.

Pengguna kedua sering membawa barang dan anak. Baginya, bagasi 375 liter plus frunk 70 liter menjadi pertimbangan utama, dan ia perlu mengecek kenyamanan jok belakang secara langsung. Dua orang dengan spesifikasi yang sama bisa menarik kesimpulan berbeda, dan itu wajar karena kebutuhannya berbeda.

## Pertanyaan yang sering diajukan

### Berapa kapasitas baterai Geely EX2 Max?

Baterai LFP 40,8 kWh dengan klaim jarak 395 km menurut metode NEDC.

### Berapa lama mengisi daya EX2 Max?

Klaim pabrikan: AC 10-100% sekitar 6,5 jam, dan DC 30-80% sekitar 25 menit.

### Berapa bagasi EX2 Max?

375 liter, hingga 1.320 liter dengan jok dilipat, ditambah frunk 70 liter.

### Apakah dimensi EX2 tersedia di sini?

Belum. Tanyakan kepada sales untuk dimensi resminya.

## Kesimpulan

Spesifikasi Geely EX2 Max menggambarkan mobil listrik kompak yang tenang, ringkas, dan punya data pengisian jelas. Baca angka-angkanya sebagai pembanding, lalu pastikan cocok lewat test drive.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) atau lihat penawaran di halaman [promo](/promo/).
