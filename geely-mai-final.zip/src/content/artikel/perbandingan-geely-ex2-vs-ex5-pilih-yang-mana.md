---
title: "Geely EX2 vs EX5: Pilih yang Mana Berdasarkan Kebutuhan"
description: "Perbandingan Geely EX2 vs EX5: baterai 40,8 vs 60,22 kWh, jarak NEDC 395 vs 495 km, bagasi, tenaga, dan fitur. Panduan memilih sesuai kebutuhan Anda."
date: 2026-10-14
category: "Perbandingan"
tags: ["geely ex2 vs ex5", "perbandingan geely ex2 ex5", "geely ex2", "geely ex5", "mobil listrik geely", "geely ev", "geely indonesia", "ev geely jakarta"]
draft: false
---

Geely EX2 vs EX5 sebenarnya bukan soal mana yang lebih baik, melainkan mana yang lebih sesuai. EX2 adalah mobil listrik kompak dengan baterai 40,8 kWh, sedangkan EX5 adalah SUV listrik dengan baterai 60,22 kWh. Artikel ini membandingkan keduanya pada aspek yang paling memengaruhi keputusan, berdasarkan data resmi yang kami miliki.

## Karakter kedua mobil

EX2 diposisikan untuk pemakaian harian di kota: ringkas, tenang, dan mudah dikendalikan. EX5 adalah SUV listrik berukuran lebih besar untuk keluarga yang menginginkan ruang dan jangkauan lebih longgar. Perbedaan karakter ini lebih penting daripada selisih angka tunggal mana pun.

Sebelum membandingkan, tentukan dulu kebutuhan utama Anda: ruang, jarak, atau kemudahan di kota. Gambaran model ada di [Geely EX2 Jakarta](/lp/geely-ex2-jakarta/) dan [Geely EX5 Jakarta](/lp/geely-ex5-jakarta/).

## Tabel perbandingan inti

| Aspek | EX2 | EX5 |
|---|---|---|
| Baterai | LFP 40,8 kWh | LFP 60,22 kWh |
| Klaim jarak NEDC | 395 km | 495 km (Pro), 490 km (Max) |
| Motor | 85 kW, 150 Nm | 160 kW, 320 Nm |
| 0-100 km/jam | sekitar 11,5 detik (perkiraan) | 6,9 detik (Pro), 7,1 detik (Max) |
| Bagasi | 375 liter (hingga 1.320) + frunk 70 liter | 461 liter (hingga 1.877) |
| Velg | 16 inci | 18 inci |
| Layar tengah | 14,6 inci | 15,4 inci |

Angka jarak adalah klaim laboratorium, bukan hasil jalan. Data EX5 berasal dari brosur resmi yang menyatakan spesifikasi dapat berubah.

## Jarak dan baterai

EX5 memiliki baterai lebih besar dan klaim jarak lebih panjang. Bagi yang sering bepergian jauh, itu memberi kelonggaran. Namun bagi pengguna kota dengan jarak harian pendek, kapasitas EX2 sering sudah memadai. Jangan membeli baterai besar untuk kebutuhan yang jarang muncul.

Hitung kebiasaan Anda dahulu. Pembahasan jarak ada di [jarak tempuh EX2](/artikel/jarak-tempuh-geely-ex2-max-klaim-vs-pemakaian-harian/) dan [jarak tempuh EX5: NEDC dan WLTP](/artikel/jarak-tempuh-geely-ex5-nedc-495-km-dan-wltp-430-km/).

## Tenaga dan karakter berkendara

Motor EX5 jauh lebih bertenaga, dengan torsi 320 Nm dibanding 150 Nm pada EX2. Akselerasi 0-100 km/jam EX5 tercatat 6,9 hingga 7,1 detik, sedangkan EX2 sekitar 11,5 detik menurut perkiraan. Perbedaan ini terasa saat menyalip dan di jalan tol.

Namun tenaga lebih besar bukan selalu kebutuhan. Bagi pengemudi yang mengutamakan ketenangan dan efisiensi, karakter EX2 sudah sesuai. Rasakan sendiri saat test drive.

## Ruang dan bagasi

EX5 memiliki bagasi 461 liter yang membesar hingga 1.877 liter, sedangkan EX2 375 liter hingga 1.320 liter plus frunk 70 liter. Dimensi EX5 tercatat panjang 4.615 mm dan lebar 1.901 mm, sementara dimensi resmi EX2 belum tersedia pada data kami.

Bila Anda sering membawa stroller, koper, atau banyak penumpang dewasa, EX5 lebih longgar. Untuk keluarga kecil dan barang secukupnya, EX2 bisa cukup. Pembahasannya ada di [kabin dan bagasi EX5](/artikel/kabin-dan-bagasi-geely-ex5-461-liter/).

## Pengisian daya

EX5 mendukung AC hingga 11 kW dan DC hingga 100 kW menurut brosur, tanpa waktu pengisian yang dicantumkan. EX2 memiliki klaim AC 10-100% sekitar 6,5 jam dan DC 30-80% sekitar 25 menit. Kedua mobil memerlukan perencanaan tempat mengisi.

Karena data waktu pengisian tidak setara, jangan membandingkannya secara langsung. Tanyakan kepada sales waktu pengisian EX5 pada daya yang akan Anda pakai. Panduan ada di [pengisian daya EX5](/artikel/pengisian-daya-geely-ex5-ac-11-kw-dan-dc-100-kw/).

## Fitur dan keselamatan

Kedua mobil punya varian Pro dan Max, dan Max pada keduanya menambah bantuan pengemudi serta kenyamanan. EX2 Max membawa ADAS Level 2 dan kamera 540 derajat, sedangkan EX5 Max membawa rangkaian bantuan pengemudi seperti adaptive cruise control dan peringatan titik buta menurut brosur.

Bacalah rincian di [fitur ADAS EX2 Max](/artikel/fitur-adas-geely-ex2-max-apa-saja-dan-cara-kerjanya/) dan [fitur ADAS EX5 Max](/artikel/fitur-adas-geely-ex5-max-bantuan-berkendara/). Fitur bagus hanya bila Anda memakainya.

## Harga dan biaya

Kami tidak mencantumkan harga di artikel perbandingan ini. Lihat [harga Geely EX2](/artikel/harga-geely-ex2-terbaru-pro-dan-max-otr-jakarta/) dan [harga Geely EX5](/artikel/harga-geely-ex5-terbaru-pro-dan-max-otr-jakarta/), lalu minta penawaran tertulis. Hitung juga biaya listrik, asuransi, pajak, dan perawatan.

Mobil yang lebih besar umumnya membawa biaya lebih besar pada beberapa pos. Jadikan total biaya kepemilikan sebagai dasar perbandingan, bukan hanya harga beli.

## Cara memutuskan

Tuliskan lima prioritas Anda dan beri skor pada kedua mobil. Libatkan keluarga yang akan menggunakan mobil. Coba keduanya berurutan di rute yang sama. Keputusan yang baik lahir dari kecocokan dengan hidup Anda.

Panduan memilih mobil listrik pertama ada di [tips memilih mobil listrik pertama](/artikel/tips-memilih-mobil-listrik-pertama/). Informasi model ada di halaman [Geely EX2](/model/geely-ex2/) dan [Geely EX5](/model/geely-ex5/).

## Tiga contoh situasi dan kecenderungan pilihan

Situasi pertama: pasangan muda bekerja di kota, jarak harian pendek, parkir terbatas. Mobil kompak biasanya lebih praktis, sehingga EX2 layak diprioritaskan. Situasi kedua: keluarga dengan dua anak yang sering berlibur akhir pekan membawa banyak barang. Ruang dan jangkauan EX5 lebih menenangkan.

Situasi ketiga: pengguna yang memerlukan mobil kedua murah biaya operasional. EX2 cenderung lebih masuk akal. Ini hanya kecenderungan; kebutuhan nyata Anda dapat mengubah kesimpulan, dan itulah mengapa test drive keduanya penting.

## Pertimbangan parkir dan manuver

Ukuran besar EX5 memberi ruang dan kesan kokoh, tetapi menuntut kehati-hatian di tempat parkir sempit. Dimensinya 4.615 mm panjang dan 1.901 mm lebar, dengan radius putar minimum 5,4 meter menurut brosur. Ukur tempat parkir dan gang rumah Anda sebelum memutuskan.

EX2 yang kompak biasanya lebih leluasa di tempat seperti itu, dan varian Max dibantu kamera 540 derajat. Bila rumah atau kantor Anda memiliki akses sempit, pertimbangan ini bisa lebih menentukan daripada selisih tenaga.

## Pertanyaan yang sering diajukan

### Mana yang lebih jauh jangkauannya?

EX5 menurut klaim NEDC, yaitu 495 km (Pro) dan 490 km (Max) dibanding 395 km pada EX2.

### Mana yang lebih cocok untuk keluarga?

EX5 lebih lega, tetapi EX2 bisa cukup untuk keluarga kecil. Uji sendiri.

### Apakah keduanya punya V2L?

EX5 memiliki V2L menurut brosur, dan EX2 Max juga memiliki V2L menurut data kami.

### Di mana melihat promo?

Lihat halaman [promo](/promo/).

## Kesimpulan

EX2 unggul pada kemudahan dan kompaknya di kota, sedangkan EX5 unggul pada ruang, tenaga, dan jangkauan. Pilihlah sesuai kebutuhan nyata Anda dan buktikan lewat test drive.

Hubungi tim Geely MAI melalui halaman [kontak](/kontak/) untuk mencoba keduanya.
